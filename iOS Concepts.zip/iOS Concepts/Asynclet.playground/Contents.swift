import UIKit


struct Weather {
    
    var id: Int
    var description : String
}

struct News {
    
    var id: Int
    var description : String
}

struct Update {
    
    var isUpdateAvailable: Bool
}

func getNews() -> [News] {
    
    return [News(id: 45, description: "Test News")]
}


func getWeather() -> [Weather] {
    
    return [Weather(id: 456, description: "Test Weather")]
}

func hasAppUpdate() -> Update {
    
    return Update(isUpdateAvailable: true)
}

func getAppData() -> ([News], [Weather], Update) {
    
    Task {
        
        async let news =  getNews()
        async let weather =  getWeather()
        async let hasUpdate =  hasAppUpdate()
        
        return await (news, weather, hasUpdate)
    }
}

getAppData()
