public struct SwiftPackager {
    public private(set) var text = "Hello, World!"

    public init() {
    }
    
    public func testMethod() -> String {
        
        return "Hello Swift Package Manager 2.0.0 --->"
    }
}
