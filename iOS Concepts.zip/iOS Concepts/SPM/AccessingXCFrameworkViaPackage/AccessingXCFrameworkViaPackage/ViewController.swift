//
//  ViewController.swift
//  AccessingXCFrameworkViaPackage
//
//  Created by Venkat on 22/09/22.
//

import UIKit
import SwiftXCFramework

class ViewController: UIViewController {

    var basket = Basket(_capacity: 4)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        basket.add(.orange)
        basket.add(.orange)
        basket.add(.orange)
        basket.add(.orange)
        basket.add(.orange)
        basket.add(.orange)
    }


}

