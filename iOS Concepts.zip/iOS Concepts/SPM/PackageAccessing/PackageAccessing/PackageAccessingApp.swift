//
//  PackageAccessingApp.swift
//  PackageAccessing
//
//  Created by Venkat on 22/09/22.
//

import SwiftUI

@main
struct PackageAccessingApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
