//
//  ViewController.swift
//  XCFrameworkAccessing
//
//  Created by Venkat on 22/09/22.
//

import UIKit
import SwiftXCFramework

class ViewController: UIViewController {
    
    let fruitBasket = Basket(_capacity: 2)
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        fruitBasket.add(.Apple)
        fruitBasket.add(.Banana)
        fruitBasket.add(.orange)
    }

}

