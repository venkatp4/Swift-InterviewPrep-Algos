//
//  Fruit.swift
//  SwiftXCFramework
//
//  Created by Venkat on 22/09/22.
//

import Foundation

public enum Fruit: String {
    
    case Banana
    case orange
    case Apple
}
