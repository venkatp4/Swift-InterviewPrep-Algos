//
//  Basket.swift
//  SwiftXCFramework
//
//  Created by Venkat on 22/09/22.
//

import Foundation

public class Basket {
    
    private var capacity : Int?
    
    private var fruits = [Fruit]()
    
   public init(_capacity: Int) {
        
        self.capacity = _capacity
    }
    
    private var count: Int {
        
        fruits.count
    }
    
    public func add(_ fruit: Fruit) {
        
        if(count < capacity ?? 0) {
        
            fruits.append(fruit)
        } else {
            
            debugPrint("Sorry, Basket is full....")
        }
        
    }
}
