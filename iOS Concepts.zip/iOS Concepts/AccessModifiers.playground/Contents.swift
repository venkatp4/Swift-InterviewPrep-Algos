import UIKit

//:- Access Specifiers

public class A {
    
    fileprivate func A1() {
        
    }
    private func A2() {
        
    }
    public func A3() {
        
    }
    internal func A4() {
        
    }
    open func A5() {
        
    }
    
}

open class AA {
    
    fileprivate func A1() {
        
    }
    private func A2() {
        
    }
    public func A3() {
        
    }
    internal func A4() {
        
    }
    open func A5() {
        
    }
    
}

internal class AAA {
    
    fileprivate func A1() {
        
    }
    private func A2() {
        
    }
    public func A3() {
        
    }
    internal func A4() {
        
    }
    open func A5() {
        
    }
    
}

private class AAAA {
    
    fileprivate func A1() {
        
    }
    private func A2() {
        
    }
    public func A3() {
        
    }
    internal func A4() {
        
    }
    open func A5() {
        
    }
    
}

fileprivate class AAAAA {
    
    fileprivate func A1() {
        
    }
    private func A2() {
        
    }
    public func A3() {
        
    }
    internal func A4() {
        
    }
    open func A5() {
        
    }
    
}

fileprivate class B : AAAAA {
    
    override func A1() {
        
    }
    
    override func A3() {
        
    }
    
    override func A4() {
        
    }
    
    override func A5() {
        
    }
    
}
