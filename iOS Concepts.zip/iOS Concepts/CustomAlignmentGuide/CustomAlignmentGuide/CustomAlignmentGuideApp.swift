//
//  CustomAlignmentGuideApp.swift
//  CustomAlignmentGuide
//
//  Created by Venkat on 19/09/22.
//

import SwiftUI

@main
struct CustomAlignmentGuideApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
