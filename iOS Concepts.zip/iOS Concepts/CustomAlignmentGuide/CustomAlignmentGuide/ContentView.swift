//
//  ContentView.swift
//  CustomAlignmentGuide
//
//  Created by Venkat on 19/09/22.
//

import SwiftUI

extension VerticalAlignment {
    
    enum CenterAlignmentGuide : AlignmentID {
        
        static func defaultValue(in context: ViewDimensions) -> CGFloat {
            
            context[.top]
        }
    }
    static let centerAlignmentGuide = VerticalAlignment(CenterAlignmentGuide.self)
}

struct ContentView: View {
    var body: some View {
        
        HStack(alignment: .centerAlignmentGuide) {
            
            VStack {
                
                Text("@:TwoStraws").alignmentGuide(.centerAlignmentGuide) { d in
                    d[VerticalAlignment.center]
                }
                Image("profile")
                    .resizable()
                    .frame(maxWidth: 64, maxHeight: 64)
            }
            
            VStack {
                
                Text("Full Name")
                Text("Venkateswarlu Phanitapu").font(.largeTitle).alignmentGuide(.centerAlignmentGuide) { d in
                    d[VerticalAlignment.bottom]
                }
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
