import UIKit
import Combine
import Darwin
import PlaygroundSupport
import Foundation

//:- Collect

func example(of: String, closure:()-> Void) {
    
    debugPrint("-- \(of) --")
    closure()
}

example(of: "Collection Operator") {

    var subscription = Set<AnyCancellable>()
    
    let publisher = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10].publisher
    
    publisher
    .collect(5)
    .sink { completion in
        
        debugPrint(completion)
    } receiveValue: { val in
        
        debugPrint(val)
    }
    .store(in: &subscription)
}

example(of: "Map Operator") {

    var subscription = Set<AnyCancellable>()
    
    let numberFomatter = NumberFormatter()
    numberFomatter.numberStyle = .spellOut
    
    let publisher = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10].publisher
    
    publisher
        .map({
            
            numberFomatter.string(for: NSNumber(integerLiteral: $0)) ?? ""
        })
    .sink { completion in
        
        debugPrint(completion)
    } receiveValue: { val in
        
        debugPrint(val)
    }
    .store(in: &subscription)
}

example(of: "Map Key Paths") {
    
    var subscriptions = Set<AnyCancellable>()
    
    let publisher = PassthroughSubject<(Int, Int), Never>()
    
    publisher.sink { completion in
        
        debugPrint(completion)
    } receiveValue: { (x, y) in
        
        debugPrint(x * y)
    }
    .store(in: &subscriptions)

    publisher.send((19, 178))
}

example(of: "TryMap") {
    
    var subscriptions = Set<AnyCancellable>()
    
    let publisher = PassthroughSubject<String, Never>()
    
    publisher
        .tryMap({
            
            try FileManager.default.contentsOfDirectory(atPath: $0)
        })
    .sink { completion in
        
        debugPrint(completion)
    } receiveValue: { result in
        
        debugPrint(result)
    }
    .store(in: &subscriptions)

    publisher.send("Apple123.txt")
}

example(of: "replace Nil") {
    
    var subscriptions = Set<AnyCancellable>()
    
    let publisher = ["One", "Two", nil, "Five", nil].publisher
    
    publisher
    .replaceNil(with: "")
    .sink { completion in
        
        debugPrint(completion)
    } receiveValue: { result in
        
        debugPrint(result ?? "")
    }
    .store(in: &subscriptions)

}

example(of: "replace Empty with") {
    var subscriptions = Set<AnyCancellable>()
    var publisher = Empty<String, Never>()
    
    publisher
        .replaceEmpty(with: "1222")
        .sink { com in
        debugPrint(com)
    } receiveValue: { val in
        debugPrint(val)
    }
    .store(in: &subscriptions)
    
}


/**********************Filter Operators*****************************/

example(of: "filter") {
    
    var subscriptions = Set<AnyCancellable>()
    let publisher = [1, 2, 3, 5, 9, 1009, 586].publisher
    publisher
        .filter({ $0.isMultiple(of: 3)})
    .sink { com in
        debugPrint(com)
    } receiveValue: { val in
        debugPrint(val)
    }
    .store(in: &subscriptions)

}

example(of: "removeDuplicates") {
    
    var subscriptions = Set<AnyCancellable>()
    let publisher = [1, 2, 2, 3, 5, 9, 586, 1009, 586].publisher
    publisher
        .removeDuplicates()
    .sink { com in
        debugPrint(com)
    } receiveValue: { val in
        debugPrint(val)
    }
    .store(in: &subscriptions)

}
example(of: "CompactMap") {
    
    var subscriptions = Set<AnyCancellable>()
    let publisher = [1, 2, 2, 3, nil, 9, nil, 1009, nil].publisher
    publisher
        .compactMap({ $0 ?? 0 })
    .sink { com in
        debugPrint(com)
    } receiveValue: { val in
        debugPrint(val)
    }
    .store(in: &subscriptions)

}
example(of: "ignoreOutput") {
    
    var subscriptions = Set<AnyCancellable>()
    let publisher = (0...100).publisher
    publisher
        .ignoreOutput()
    .sink { com in
        debugPrint(com)
    } receiveValue: { val in
        debugPrint(val)
    }
    .store(in: &subscriptions)

}
example(of: "firstWhere") {
    
    var subscriptions = Set<AnyCancellable>()
    let publisher = (0...50).publisher
    publisher
        .first(where: { $0 > 40 })
    .sink { com in
        debugPrint(com)
    } receiveValue: { val in
        debugPrint(val)
    }
    .store(in: &subscriptions)

}
example(of: "last Where") {
    
    var subscriptions = Set<AnyCancellable>()
    let publisher = PassthroughSubject<Int, Never>()
    publisher
        .last(where: { $0  > 25 })
    .sink { com in
        debugPrint(com)
    } receiveValue: { val in
        debugPrint(val)
    }
    .store(in: &subscriptions)
    publisher.send(12)
    publisher.send(56)
    publisher.send(78)
    publisher.send(completion: .finished)
}


example(of: "dropFirst") {
    
    var subscriptions = Set<AnyCancellable>()
    let publisher = PassthroughSubject<Int, Never>()
    publisher
    .dropFirst(2)
    .sink { com in
        debugPrint(com)
    } receiveValue: { val in
        debugPrint(val)
    }
    .store(in: &subscriptions)
    publisher.send(12)
    publisher.send(56)
    publisher.send(78)
    publisher.send(completion: .finished)
}
example(of: "dropWhile") {
    
    var subscriptions = Set<AnyCancellable>()
    let publisher = (1...20).publisher
    publisher
        .drop(while: {
             $0 <= 19
        })
    .sink { com in
        debugPrint(com)
    } receiveValue: { val in
        debugPrint(val)
    }
    .store(in: &subscriptions)
    
}

example(of: "Drop Until OutPut from") {
    
    var subscriptions = Set<AnyCancellable>()
    
    let firstpublisher = PassthroughSubject<Int, Never>()
    let secondpublisher = PassthroughSubject<Int, Never>()
    
    secondpublisher
        .drop(untilOutputFrom: firstpublisher)
        .sink {
        
        debugPrint($0)
    } receiveValue: {
        
        debugPrint($0)
    }
    .store(in: &subscriptions)

    (0...10).forEach { val in
        
        secondpublisher.send(val)
        
        if(val == 7) {
            
            firstpublisher.send(val)
        }
    }
    secondpublisher.send(completion: .finished)
    firstpublisher.send(completion: .finished)

}
example(of: "Prefix") {
    
    var subscriptions = Set<AnyCancellable>()
    let publisher = (1...200).publisher
    publisher
        .prefix(5)
    .sink { com in
        debugPrint(com)
    } receiveValue: { val in
        debugPrint(val)
    }
    .store(in: &subscriptions)
    
}
example(of: "PrefixWhile") {
    
    var subscriptions = Set<AnyCancellable>()
    let publisher = (1...20).publisher
    publisher
        .prefix(while: {
            $0 < 9
        })
    .sink { com in
        debugPrint(com)
    } receiveValue: { val in
        debugPrint(val)
    }
    .store(in: &subscriptions)
    
}
example(of: "Prefix Until OutPut from") {
    
    var subscriptions = Set<AnyCancellable>()
    
    let firstpublisher = PassthroughSubject<Int, Never>()
    let secondpublisher = PassthroughSubject<Int, Never>()
    
    secondpublisher
        .prefix(untilOutputFrom: firstpublisher)
        .sink {
        
        debugPrint($0)
    } receiveValue: {
        
        debugPrint($0)
    }
    .store(in: &subscriptions)

    (0...10).forEach { val in
        
        secondpublisher.send(val)
        
        if(val == 7) {
            
            firstpublisher.send(val)
        }
    }
    secondpublisher.send(completion: .finished)
    firstpublisher.send(completion: .finished)

}

/**********************Combining Operators*****************************/

example(of: "Prepend Oputput") {
    
    let publisher = [10, 20].publisher
    
    publisher
        .prepend(1, 2)
        .prepend(4)
        .sink { com in
        debugPrint(com)
    } receiveValue: { val in
        debugPrint(val)
    }
}
example(of: "Prepend Sequence") {
    
    let publisher = [10, 20].publisher
    
    publisher
        .prepend(Set(100...200))
        .sink { com in
        debugPrint(com)
    } receiveValue: { val in
        debugPrint(val)
    }
}

example(of: "Prepend Stride") {
    
    let publisher = (0...20).publisher
    
    publisher
        .prepend(stride(from: 10, through: 20, by: 2))
        .sink { com in
        debugPrint(com)
    } receiveValue: { val in
        debugPrint(val)
    }
}
example(of: "prepend publisher with PassthroughSubject") {
    
    var subscriptions = Set<AnyCancellable>()
    let publisher1 = [120, 140].publisher
    let publisher2 = PassthroughSubject<Int, Never>()
    
    publisher2
    .prepend(publisher1)
    .prepend([1000, 50000])
    .prefix
    .sink { com in
        debugPrint(com)
    } receiveValue: { val in
        debugPrint(val)
    }
    .store(in: &subscriptions)
    publisher2.send(4560078)
    publisher2.send(completion: .finished)
}

example(of: "merge(with:)") {
    
    var subscriptions = Set<AnyCancellable>()
    
    let publisher1 = PassthroughSubject<Int, Never>()
    
    let publisher2 = CurrentValueSubject<Int, Never>(10)
    
    publisher1.merge(with: publisher2)
    .sink {
        debugPrint($0)
    } receiveValue: {
        debugPrint($0)
    }.store(in: &subscriptions)
        
    publisher1.send(1)
    publisher1.send(2)
    publisher2.send(3)
    publisher1.send(4)
    publisher2.send(5)
    publisher2.send(completion: .finished)
    publisher1.send(completion: .finished)
}
example(of: "zip") {

    var subscriptions = Set<AnyCancellable>()

    let intPublisher = PassthroughSubject<Int, Never>()

    let stringPublisher = PassthroughSubject<String, Never>()

    intPublisher.zip(stringPublisher)
        .sink {

        debugPrint($0)
    } receiveValue: {

        debugPrint("p1: \($0) and p2: \($1)")
    }.store(in: &subscriptions)

    intPublisher.send(1)
    intPublisher.send(2)

    stringPublisher.send("One")
    stringPublisher.send("Two")

    intPublisher.send(3)
    stringPublisher.send("Three")

    intPublisher.send(completion: .finished)

    stringPublisher.send(completion: .finished)
}

example(of: "combineLatest") {
    
    var subscriptions = Set<AnyCancellable>()
    
    let intPublisher = PassthroughSubject<Int, Never>()
    
    let stringPublisher = PassthroughSubject<String, Never>()
    
    intPublisher
        .combineLatest(stringPublisher)
        .sink {
        
        debugPrint($0)
    } receiveValue: {
        
        debugPrint("p1: \($0) and p2: \($1)")
    }.store(in: &subscriptions)
    
    intPublisher.send(0)
    intPublisher.send(1)
    stringPublisher.send("One")
    intPublisher.send(2)
    stringPublisher.send("Two")
    intPublisher.send(3)
    intPublisher.send(4)
    stringPublisher.send("Three")
    stringPublisher.send("Four")
    stringPublisher.send("Five")

    
    intPublisher.send(completion: .finished)
    stringPublisher.send(completion: .finished)
}


