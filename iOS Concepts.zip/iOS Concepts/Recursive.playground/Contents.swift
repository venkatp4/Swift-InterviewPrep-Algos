import UIKit

func countDown(number: Int) -> Int
{
    
    if(number == 0) {
        
        return number
    } else {
        
        return number + countDown(number: number - 1)
    }
}

countDown(number: 5)

func factorialNumber(number: Int) -> Int {
    
    if (number == 0)
    {
        return 1
    } else {
        
        return number * factorialNumber(number: number - 1)
    }
}

factorialNumber(number: 10)
