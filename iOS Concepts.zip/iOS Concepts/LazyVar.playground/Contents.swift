import UIKit

struct User {
    
    var name : String
    
    init(_name: String) {
        
        self.name = _name
    }
    
    lazy var greet: String = {
        
       print("lazy....")
        return "Hello \(self.name)"
    }()
}

var user = User(_name: "Venkat")
user.greet
user.name = "Phanitapu"
user.greet

//**********************************************

struct Employee {
    
    var name : String
    var age: Int
}

struct ViewModel {
    
    var employee: [Employee]
    
    init(_employee : [Employee]) {
        
        self.employee = _employee
    }
    
    lazy var oldestEmployee: Employee? = {
        
        return employee.max(by: {$0.age < $1.age})
    }()
}

var objViewModel = ViewModel(_employee: [Employee(name: "Venkat", age: 35), Employee(name: "Rajesh", age: 37), Employee(name: "Suresh", age: 45)])
objViewModel.oldestEmployee
objViewModel.employee.append(Employee(name: "Ramesh", age: 55))
objViewModel.oldestEmployee
