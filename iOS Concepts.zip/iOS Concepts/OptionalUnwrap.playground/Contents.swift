import UIKit

func getMeaningOfLife() -> Int? {
    
    return nil
}

/** iflet **/

func printMeaningOfLife() {
    
    
    if let value = getMeaningOfLife() {
        
        debugPrint(value)
    }
}
printMeaningOfLife()


/** guardlet **/

func printMeaningOfLifeWithGuard() {
    
    guard let value = getMeaningOfLife() else {
        
        debugPrint("value is nil")
        return
    }
    
    debugPrint(value)
}

printMeaningOfLifeWithGuard()


var name: String? = "Venkat"

if let name = name {
    
    print("iflet \(name)")
}
func test() {
    guard let name = name else { return }
    print("guardlet \(name)")
}
test()
