import UIKit
import Darwin

let averageTask = Task { () -> Double in
    
    
        let url = URL(string: "https://hws.dev/readings.json")
        
        guard url != nil else {return 0}
        
        do {
            debugPrint("task started....")
            sleep(5)
            
            let (data, _) = try await URLSession.shared.data(from: url!)
            if(Task.isCancelled) { return 0 }

            let result = try? JSONDecoder().decode([Double].self, from: data)
            let sum = result?.reduce(0, +)
            let average = (sum ?? 0.0) / Double(result?.count ?? Int(0.0))
            debugPrint("average \(average)")
            return average
        
        }catch {
            
            debugPrint(error.localizedDescription)
            return 0
        }
}


averageTask

averageTask.cancel()
