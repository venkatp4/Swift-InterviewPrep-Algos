import UIKit
import Foundation

func getWeatherData() async throws -> [Double] {
    
    (1...100).map { _ in Double.random(in: 10...30) }
}

func getAverage(value: [Double]) async -> Double {
    
    let result = value.reduce(0, +)
    let average = result / Double(value.count)
    return average
}

func uploadDataToServer(average: Double) async -> Bool {
    
    return true
}

func processWeatherData() async throws -> Bool {
    
    let result = try! await getWeatherData()
    let average = await getAverage(value: result)
    let isSuccess = await uploadDataToServer(average: average)
    return isSuccess
}

    Task {
        
        if let response = try? await processWeatherData() {
            
            debugPrint(response)
        } else {
            
            debugPrint("Failed to fetch the data")
        }
    }


struct NewsItem: Decodable {
    let id: Int
    let title: String
    let url: URL
}

func fetchUpdates() async -> [NewsItem] {
   
    do {
        guard let url = URL(string: "https://hws.dev/headlines.json") else { return [] }
        
        let (data, _) = try await URLSession.shared.data(from: url)
        return try JSONDecoder().decode([NewsItem].self, from: data)
    }catch {
      
        return [NewsItem(id: 1, title: "Test Title", url: URL(string: "https://www.")!)]
    }
}
Task{
    
    await fetchUpdates()
}


enum NetworkError: Error {
    case url
    case server
    }


struct User: Decodable {
  
    let userId : Int
    let id : Int
    let title : String
    let completed : Bool
}

func makeAPICall() async -> Result<User, Error> {
    
    let path = URL(string:"https://jsonplaceholder.typicode.com/todos/1")!

    do {
    
        let (data, _) = try await URLSession.shared.data(from: path, delegate: nil)
        let decodeData = try JSONDecoder().decode(User.self, from: data)
        return .success(decodeData)

    }catch {
            
        return .failure(NetworkError.url)
    }
}

Task {
    
    let result = await makeAPICall()
    switch result {
        
    case .success(let result):
        
        debugPrint(result.title)
        break
    case .failure(let error as NSError):
        
        debugPrint(error)
        break
    }
}
