//
//  ViewThatFitsApp.swift
//  ViewThatFits
//
//  Created by Venkat on 11/10/22.
//

import SwiftUI

@main
struct ViewThatFitsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
