//
//  ContentView.swift
//  ViewThatFits
//
//  Created by Venkat on 11/10/22.
//

import SwiftUI
import Combine

class ViewModel: ObservableObject {
    
    @Published var messages :[Messages] =
    [
        Messages(id: 1, body: "Starting with iOS 16, SwiftUI provides a new layout container", desc: "Learn to build adaptive layouts with SwiftUI's ViewThatFits container."),
        Messages(id: 2, body: "ViewThatFits which helps us build adaptive ", desc: "The content of the HStack is designed to always fit, since the text is now allowed to be truncated, so the container picks that view and shows the truncated text alongside with a button to the user."),
        Messages(id: 3, body: "The ViewThatFits container allows us ", desc: "When the longer second message comes in - which doesn't fit - the ViewThatFits container goes to the next view we provided, the HStack."),
        Messages(id: 4, body: "provide multiple views while automatically picking the first one which fits into available space.", desc: "Note that by applying the fixedSize modifier, we tell the Text view not to get wrapped or truncated."),
        Messages(id: 5, body: "Imagine we get a list of messages we", desc: "As a first step, the ViewThatFits container checks, if the Text view fits into its parent container. Since the first message fits, it just stops here in shows the message."),
        Messages(id: 6, body: "want to display under each other. If a message fits in one line,", desc: "As shown in the example above, we provide the ViewThatFits container with two views, a Text view and an HStack which contains a Text and a Button view:"),
        Messages(id: 7, body: "we just show it. If it doesn't fit", desc: "The ViewThatFits container will automatically pick the right one for us."),
        Messages(id: 8, body: "we want to show only a part of that message and a button to open the full message. Something like this", desc: "We just need to provide two different views, one that only contains the text and one that contains the text and the button."),
        Messages(id: 9, body: "As we can see above, the first message fits into the available space", desc: "To achieve this result, the ViewThatFits comes in handy."),
        Messages(id: 10, body: "so we don't need the button", desc: "The second line only shows a part of the message with a button to show the full message.")
    ]
}

struct ContentView: View {
    
    @ObservedObject var viewModel = ViewModel()
    
    var body: some View {
        
        List {
            
            ForEach(viewModel.messages, id:\.id) { item in
                  
                        
                            Text(item.body)
                                .padding()
            }
        }
        
    }
}


struct Messages: Identifiable, Equatable {
    
    let id: Int
    let body : String
    let desc : String
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .previewInterfaceOrientation(.portraitUpsideDown)
    }
}
