import UIKit

struct Employee {
    
    var name: String
    var age: Int
    var salary: Double
}

struct EmployeeViewModel {
    
    var employee : [Employee]
    
    init(_employee: [Employee]) {
        
        self.employee = _employee
    }
    
    lazy var empWithAgeHigh: Employee? = {
        
        return employee.max(by: {$0.age < $1.age})
    }()
  
}

var viewModel = EmployeeViewModel(_employee: [Employee(name: "Venkat", age: 34, salary: 50606606), Employee(name: "Rajesh", age: 35, salary: 5675766), Employee(name: "Ramesh", age: 55, salary: 45646455)])


debugPrint(viewModel.empWithAgeHigh as? Employee)

viewModel.employee.append(Employee(name: "Raju", age: 56, salary: 56546566))

debugPrint(viewModel.empWithAgeHigh)
