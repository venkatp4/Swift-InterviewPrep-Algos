import UIKit

class Employee {
    
    var name : String
    var age: Int?
    var city: String?
    
    //Desigated Initializers can make sure that all the stored properties mentioned in struct or class gets initialized

    init() {
        
        self.name = "Venkat"
    }
    
   
    //Convinience Initializer
    
    convenience init(_age: Int, _city: String) {
        
        self.init()
        self.age = _age
        self.city = _city
        self.name = "Phanitapu"
    }

}
let objEmp = Employee(_age: 35, _city: "Bangalore")


class Failable {
    
    var name: String
    var age: Int
    
    //Failable Initializer, incase return nil during initialization
    init?(_name: String, _age: Int) {
        
        if(_age > 35) {
            return nil
        }
        self.name = _name
        self.age = _age
    }
}
let objFailable = Failable(_name: "Venkat", _age: 36)
