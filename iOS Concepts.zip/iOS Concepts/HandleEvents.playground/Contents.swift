import UIKit
import Combine

let publisher = (0...100).publisher

var subscription = Set<AnyCancellable>()

publisher
    .handleEvents(receiveSubscription: { subscription in
        
        debugPrint("subscription \(subscription.combineIdentifier)")
    }, receiveOutput: { val in
        debugPrint("output \(val)")
    }, receiveCompletion: { comletion in
        debugPrint("comletion \(comletion)")
    }, receiveCancel: {
        debugPrint("cancelled")
    }, receiveRequest: { request in
        debugPrint("request \(request)")
    })
    .sink { val in

        debugPrint("val received \(val)")
    }
    .store(in: &subscription)
