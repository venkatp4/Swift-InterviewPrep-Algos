//
//  ContentView.swift
//  LightDarkMode
//
//  Created by Venkat on 14/10/22.
//

import SwiftUI

struct ContentView: View {
    
    var body: some View {
        
        ZStack {
            Color(UIColor.systemBackground)
                .padding()
                
            Text("Hello World").foregroundColor(.red)
        }.ignoresSafeArea()
    }
}


struct PreviewLandscape<Content:View> : View
{
    var height = UIScreen.main.bounds.height
    var width = UIScreen.main.bounds.width
    var content:()->Content
    
    var body: some View {
        
        content().previewLayout(PreviewLayout.fixed(width: height, height: width))
    }
}

struct LightandDark<Content: View>: View {
    
    var content:() -> Content
    
    var body: some View {
     
        ForEach(ColorScheme.allCases, id:\.self) { colorscheme in
            
            content().environment(\.colorScheme, colorscheme).previewDisplayName("\(colorscheme)")
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        
        LightandDark{
            
            PreviewLandscape {
                
                ContentView()
            }
        }
    }
}
