//
//  LightDarkModeApp.swift
//  LightDarkMode
//
//  Created by Venkat on 14/10/22.
//

import SwiftUI

@main
struct LightDarkModeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
