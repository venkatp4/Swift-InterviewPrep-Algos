import UIKit


@propertyWrapper
struct EmailPropertyWrapper {
    
    var _value: String
    var wrappedValue : String {
        
        get {
            
           return isValidEmail(_value) ? _value : String()
        }
        set {
            _value = newValue
        }
    }
    
    func isValidEmail(_ email: String) -> Bool {
        
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"

        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: email)
    }
}

struct Employee {
    
    var name: String
    @EmailPropertyWrapper var email: String
    
    func validateEmail() {
        
        if(email.isEmpty) {
            
            debugPrint("email is invalid")
        } else {
            
            debugPrint("email is valid")
        }
    }
}

let emp = Employee(name: "Venkat", email: EmailPropertyWrapper(_value: "panidapu.mca@gmail.com"))
emp.validateEmail()
