import UIKit

@objc protocol Engine : AnyObject {
    
    func startEngine()
    @objc optional func stopEngine()
}

class BikeEngine: Engine {
    
    func startEngine() {
        
        debugPrint("Bike being Start...")
        sleep(1)
        debugPrint("Bike Started...")
    }
    
    func stopEngine() {
        
        debugPrint("Bike being Stop...")
        sleep(1)
        debugPrint("Bike Stopped...")
    }
    
}

class CarEngine: Engine {
    
    func startEngine() {
        
        debugPrint("Car being Start...")
        sleep(1)
        debugPrint("Car Started...")
    }
    
    func stopEngine() {
        
        debugPrint("Car being Stop...")
        sleep(1)
        debugPrint("Car Stopped...")
    }
    
}

class Vehicle {
    
    var engine: Engine?
    var name: String
    
    init(_engine: Engine?, _name: String) {
        
        self.engine = _engine
        self.name = _name
    }
    
    func start() {
        
        engine?.startEngine()
    }
    
    func stop() {
        
        engine?.stopEngine?()
    }
}

let objBike = Vehicle(_engine: BikeEngine(), _name: "Y FZ-S")
objBike.start()


let objCar = Vehicle(_engine: CarEngine(), _name: "Benz-Q")
objCar.start()
objCar.stop()
