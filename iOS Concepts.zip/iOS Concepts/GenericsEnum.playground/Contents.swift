import UIKit

enum ServerResponse<T> {
    
    case nilData
    case emptyResponse
    case serverFailure
    case response(T)
}

class Product {
    
    var name: String?
    var id: Int?
    var price: Double?
    
    init(_name: String?, _id: Int?, _price: Double?) {
        
        self.name = _name
        self.id = _id
        self.price = _price
    }
}

var computer = Product(_name: "Compupter", _id: 343534, _price: 45544545.99)

var response = ServerResponse.response(computer)

switch(response) {
    
case .nilData :
    debugPrint("nildata")
case .emptyResponse:
    debugPrint("emptyResponse")
case .serverFailure:
    debugPrint("serverFailure")
case .response(let product):
    debugPrint("serverFailure \(product.name ?? "")")
}
