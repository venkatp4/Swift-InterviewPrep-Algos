//
//  Todo.swift
//  CleanArchitecture
//
//  Created by Venkat on 28/09/22.
//

import Foundation

struct Todo: Identifiable, Decodable {
    
    let id: Int
    let title: String
    let isCompleted: Bool
}
