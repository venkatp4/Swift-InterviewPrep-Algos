//
//  TodoDataSource.swift
//  CleanArchitecture
//
//  Created by Venkat on 28/09/22.
//

import Foundation

protocol TodoDataSource {
    
    func getTodos() async throws -> [Todo]
}
