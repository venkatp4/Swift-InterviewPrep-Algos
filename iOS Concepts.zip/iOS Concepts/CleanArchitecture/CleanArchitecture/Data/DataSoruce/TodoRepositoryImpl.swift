//
//  TodoRepositoryImpl.swift
//  CleanArchitecture
//
//  Created by Venkat on 28/09/22.
//

import Foundation

struct TodoRepositoryImpl: TodoRepository {
    
    var dataSource: TodoDataSource
    
    func getTodos() async throws -> [Todo] {
        
        let todos = try await dataSource.getTodos()
        return todos
    }
}
