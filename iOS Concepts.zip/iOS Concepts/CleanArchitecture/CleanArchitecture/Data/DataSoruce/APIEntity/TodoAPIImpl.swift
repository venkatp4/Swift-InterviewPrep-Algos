//
//  TodoAPIImpl.swift
//  CleanArchitecture
//
//  Created by Venkat on 28/09/22.
//

import Foundation

enum APIServiceError: Error{
    
    case badUrl, requestError, decodingError, statusNotOK
}

struct TodoAPIImpl: TodoDataSource{
    
       
    func getTodos() async throws -> [Todo] {
        
        guard let url = URL(string:  "\(Constants.BASE_URL)/todos") else{
            throw APIServiceError.badUrl
        }
        
        guard let (data, response) = try? await URLSession.shared.data(from: url) else{
            throw APIServiceError.requestError
        }
        
        guard let response = response as? HTTPURLResponse, response.statusCode == 200 else{
            throw APIServiceError.statusNotOK
        }
        
        guard let result = try? JSONDecoder().decode([TodoAPIEntity].self, from: data) else {
            throw APIServiceError.decodingError
        }
        
        return result.map({ item in
            Todo(
                id: item.id,
                title: item.title,
                isCompleted: item.completed
            )
        })
    }
}
