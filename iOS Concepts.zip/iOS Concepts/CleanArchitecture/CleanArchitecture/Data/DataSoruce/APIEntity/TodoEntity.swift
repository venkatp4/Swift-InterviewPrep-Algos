//
//  TodoEntity.swift
//  CleanArchitecture
//
//  Created by Venkat on 28/09/22.
//

import Foundation

struct TodoAPIEntity: Decodable {
 
    let id: Int
    let title: String
    let completed: Bool
}
