//
//  GetTodosUseCase.swift
//  CleanArchitecture
//
//  Created by Venkat on 28/09/22.
//

import Foundation
import SwiftUI

enum UseCaseError: Error {
    
    case networkingError, decodingError
    
    
    var errorMessage : String {
        
        switch self {
        case .networkingError:
            return "Internet Connection Failure"
        case .decodingError:
            return "Parsing Failure"
        }
    }
}
let errorCase = UseCaseError.self

protocol GetTodos {
    
    func execute() async -> Result<[Todo], UseCaseError>
}
struct GetTodosUseCase: GetTodos {
    
    var repo: TodoRepository
    
    func execute() async -> Result<[Todo], UseCaseError> {
        
        do {
            
            let todos = try await repo.getTodos()
            
            return Result.success(todos)
        
        } catch (let error) {
            
            switch error {
                
            case APIServiceError.decodingError:
                
                return Result.failure(errorCase.decodingError)
            
            case APIServiceError.requestError:
                return Result.failure(errorCase.networkingError)
            default:
             
                return Result.failure(errorCase.networkingError)
            }
        }
    }
    
}
