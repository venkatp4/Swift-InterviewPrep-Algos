//
//  TodoRepository.swift
//  CleanArchitecture
//
//  Created by Venkat on 28/09/22.
//

import Foundation

protocol TodoRepository {
    
    func getTodos() async throws -> [Todo]
}
