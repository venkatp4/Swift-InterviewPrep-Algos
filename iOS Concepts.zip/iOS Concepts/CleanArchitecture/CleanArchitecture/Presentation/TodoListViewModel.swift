//
//  TodoListViewModel.swift
//  CleanArchitecture
//
//  Created by Venkat on 28/09/22.
//

import Foundation

@MainActor

class TodoListViewModel: ObservableObject {

    var getTodosUseCase = GetTodosUseCase(repo: TodoRepositoryImpl(dataSource: TodoAPIImpl()))
    @Published var todos:[Todo] = []
    @Published var errorMessage : String = ""
    @Published var hasError : Bool = false
    
    
    func getTodos() async {
        
        let result = await getTodosUseCase.execute()
        
        switch result {
            
        case .success(let todo):
            self.todos = todo
        case .failure(let error):
            
            self.todos = []
            errorMessage = error.errorMessage
            hasError = true
        }
    }
}
