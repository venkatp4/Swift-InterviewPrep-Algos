//
//  Constants.swift
//  CleanArchitecture
//
//  Created by Venkat on 28/09/22.
//

import Foundation

struct Constants {
    
    static let BASE_URL = "https://jsonplaceholder.typicode.com"
}
