//
//  CleanArchitectureApp.swift
//  CleanArchitecture
//
//  Created by Venkat on 28/09/22.
//

import SwiftUI

@main
struct CleanArchitectureApp: App {
    var body: some Scene {
        WindowGroup {
            
            TodoListView()
        }
    }
}
