import UIKit
import Foundation
import Combine


// MARK: - Post
struct Post: Decodable {
    let userID, id: Int
    let title, body: String

    enum CodingKeys: String, CodingKey {
        case userID = "userId"
        case id, title, body
    }
}
typealias Posts = [Post]


// MARK: - PostDetails
struct PostDetails: Decodable {
    let userID, id: Int
    let title, body: String

    enum CodingKeys: String, CodingKey {
        case userID = "userId"
        case id, title, body
    }
}

// MARK: - PostComment
struct PostComment: Decodable {
    let postID, id: Int
    let name, email, body: String

    enum CodingKeys: String, CodingKey {
        case postID = "postId"
        case id, name, email, body
    }
}
typealias PostComments = [PostComment]



func getPosts() throws -> AnyPublisher<Posts, Error> {
    
    guard let url = URL(string: "https://jsonplaceholder.typicode.com/posts") else {
        
        throw URLError(.badServerResponse)
    }
    return URLSession.shared.dataTaskPublisher(for: url)
        .tryMap({
            $0.data
        })
        .decode(type: Posts.self, decoder: JSONDecoder())
        .eraseToAnyPublisher()
}


func getPostByUserId(post: Post) throws -> AnyPublisher<PostDetails, Error> {
    
    guard let url = URL(string: "https://jsonplaceholder.typicode.com/posts/\(post.userID)") else {
        
        throw URLError(.badServerResponse)
    }
    return URLSession.shared.dataTaskPublisher(for: url)
        .tryMap({
            $0.data
        })
        .decode(type: PostDetails.self, decoder: JSONDecoder())
        .eraseToAnyPublisher()
}

func getPostCommentsByUserId(post: Post) throws -> AnyPublisher<PostComments, Error> {
    
    guard let url = URL(string: "https://jsonplaceholder.typicode.com/posts/\(post.userID)/comments") else {
        
        throw URLError(.badServerResponse)
    }
    return URLSession.shared.dataTaskPublisher(for: url)
        .tryMap({
            $0.data
        })
        .decode(type: PostComments.self, decoder: JSONDecoder())
        .eraseToAnyPublisher()
}

// MARK: - Dependant API calls using flatMap

func getPostDetails() -> AnyPublisher<PostDetails, Error> {
    
    try! getPosts().flatMap { post in
        
        try! getPostByUserId(post: (post.first)!)
    }.eraseToAnyPublisher()
}

// MARK: - Concurrent API calls using Zip

func getPostDetailsWithMultiResponse() -> AnyPublisher<(PostDetails, PostComments), Error> {
    
    try! getPosts().flatMap({ post in
     
        Publishers.Zip(try! getPostByUserId(post: (post.first)!), try! getPostCommentsByUserId(post: (post.first)!))
    }).eraseToAnyPublisher()
}


var subscriptions = Set<AnyCancellable>()
try? getPostDetails()
    .sink(receiveCompletion: { comp in
        debugPrint(comp)
    }, receiveValue: { postDetails in
        
        debugPrint(postDetails)
    })
    .store(in: &subscriptions)


var subscriptions1 = Set<AnyCancellable>()
try! getPostDetailsWithMultiResponse()
    .sink(receiveCompletion: { completion in
        
        debugPrint(completion)
    }, receiveValue: { (postDetails, postComments) in
        
        debugPrint("postDetails \(postDetails)")
        debugPrint("postComments \(postComments)")
    })
    .store(in: &subscriptions1)
