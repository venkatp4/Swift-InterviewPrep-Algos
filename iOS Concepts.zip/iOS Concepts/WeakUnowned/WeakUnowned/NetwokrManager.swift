//
//  NetwokrManager.swift
//  WeakUnowned
//
//  Created by Venkat on 22/08/22.
//

import Foundation

class NetworkManager {
    
    static let shared = NetworkManager()
    
    private init() {}
    
    
    func callAPI(url: NSURL, completion: @escaping(_ success: Bool?)-> Void) {
        
        
        DispatchQueue.global().asyncAfter(deadline: .now() + 5) {
        
            completion(true)
        }
    }
}
