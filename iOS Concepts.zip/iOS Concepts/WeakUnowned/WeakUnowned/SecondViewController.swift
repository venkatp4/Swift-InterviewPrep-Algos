//
//  SecondViewController.swift
//  WeakUnowned
//
//  Created by Venkat on 22/08/22.
//

import UIKit

class SecondViewController: UIViewController {

    var viewController: UIViewController?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        initUI()
    }
    
    func initUI() {
        
            
        NetworkManager.shared.callAPI(url: NSURL(string: "https://www.google.com")!) { [weak self] success in
            
        
            guard let self = self, let success = success else {
                return
            }


            self.printFunction(succ: success)
//            self.viewController = self
        }
    }
    
    func printFunction(succ: Bool) {
        
        debugPrint("response from API is \(succ)")
    }
    deinit {
        
        debugPrint("deinitialized from Second Class")
    }
}

