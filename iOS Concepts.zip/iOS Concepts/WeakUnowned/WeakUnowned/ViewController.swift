//
//  ViewController.swift
//  WeakUnowned
//
//  Created by Venkat on 22/08/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    deinit {
        
        debugPrint("deinitialized from First Class")
    }
    
}

