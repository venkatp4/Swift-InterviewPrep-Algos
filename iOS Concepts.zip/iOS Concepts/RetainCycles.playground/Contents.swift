import UIKit

class Person {
    
    var name: String
    
    init(_name: String) {
        
        self.name = _name
    }
    
    deinit {
        
        debugPrint("Person class is deinitialized")
    }
}

class Department {
    
    var number: Int
    
    weak var employee : Person?
    
    init(_number: Int) {
        
        self.number = _number
    }
    
    deinit {
        
        debugPrint("Department class is deinitialized")
    }
}

var venkat: Person? = Person(_name: "Venkat")
var itServices: Department? = Department(_number: 2009)
itServices?.employee = venkat

venkat = nil
//itServices = nil
