import UIKit

class Person {
    
    var name: String = "Venkat"
    var email: String = "panidapu.mca@gmail.com"
}

func closureCapture() {
    
    var val = 100
    var p = Person()
    
    let closure = { [val, p] in
        
        print("\(val)  \(p.name)")
    }
    
    closure()
    
    val = 200
    p.name = "Venkatesh"
    closure()
    
    val = 300
    p.name = "venkateswarlu"
    
    closure()
}

closureCapture()
