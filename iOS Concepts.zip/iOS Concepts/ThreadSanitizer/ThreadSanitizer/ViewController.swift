//
//  ViewController.swift
//  ThreadSanitizer
//
//  Created by Venkat on 19/08/22.
//

import UIKit

class ViewController: UIViewController {

    private var name: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setName()
    }

    func setName() {
        self.name = ""
        
        DispatchQueue.global().async(qos:.userInitiated) {
        
            self.name = "Venkateswarlu Phanitapu"
            debugPrint("name inside thread \(String(describing: self.name))")
        }
        
        DispatchQueue.global().async(qos:.userInitiated) {
            
            debugPrint("name inside main thread \(String(describing: self.name))")
        }
    }

}

