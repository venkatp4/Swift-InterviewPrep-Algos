import UIKit

/**Shorthand Closure**/

let shortHandClosure:(Int, Int)-> Int = {
    
    return $0 + $1
}

shortHandClosure(10, 19)


let inferredClosure = { (a: Int, b: Int) -> Int in
    
    return a * b
}

inferredClosure(12, 19)

func returnClosure() -> (Int, Int) -> Int {
    
    return shortHandClosure
}

returnClosure()(190, 899)

func CompletionHandler(success: Bool) -> Bool {
    
    debugPrint("success.... \(success)")
    
    return success
}

func downloadFileatUrl(url: NSURL, completion:(_ success: Bool)-> Bool) {
    
    debugPrint("file being downloaded...!")
    
    completion(true)
    
    debugPrint("file downloaded...!")
}

downloadFileatUrl(url: NSURL(string: "https://github.com/keysSecured/index[0]")!, completion: CompletionHandler)

