//
//  ViewController.swift
//  WillSetDidSet
//
//  Created by Venkat on 28/10/22.
//

import UIKit

struct Person {
    
    var id: Int?
    var name: String?
}
class ViewController: UIViewController {

    var person: Person? {
        
        didSet {
            
            let personObj = person
            print("DidSet \(personObj?.name ?? "") and oldValue \(oldValue?.name ?? "")")
        }
        willSet(newValue) {
            
            let personObj = newValue
            print("WillSet \(personObj?.name ?? "")")
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        
        person = Person(id: 1234, name: "Venkateswarlu Phanitapu")
        person = Person(id: 1234, name: "Venkateswarlu")
     
    }

}

