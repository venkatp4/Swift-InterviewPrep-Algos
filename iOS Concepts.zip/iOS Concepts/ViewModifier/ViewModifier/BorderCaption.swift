//
//  BorderCaption.swift
//  ViewModifier
//
//  Created by Venkat on 08/10/22.
//

import SwiftUI

struct BorderCaption: ViewModifier {
    
    func body(content: Content) -> some View {
        
        content
            .font(.caption2)
            .padding()
            .overlay {
                RoundedRectangle(cornerRadius: 10)
                    .stroke(lineWidth: 1)
            }
            .foregroundColor(.blue)
    }
}

extension View {
    
    func providesBorderCaption() -> some View {
        
        modifier(BorderCaption())
    }
}
