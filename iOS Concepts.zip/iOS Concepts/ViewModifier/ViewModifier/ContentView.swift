//
//  ContentView.swift
//  ViewModifier
//
//  Created by Venkat on 08/10/22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        
        
        Text("Hello, world!").providesBorderCaption()
            
        Button {
            
        } label: {
            
            Text("Buy me a Coffee")
        }
        .providesBorderCaption()

    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
