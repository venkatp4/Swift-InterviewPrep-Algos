//
//  ViewModifierApp.swift
//  ViewModifier
//
//  Created by Venkat on 08/10/22.
//

import SwiftUI

@main
struct ViewModifierApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
