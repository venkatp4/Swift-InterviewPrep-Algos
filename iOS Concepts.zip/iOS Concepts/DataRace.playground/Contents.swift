import UIKit

class ATM {
    
    var balanceAmount: Double = 19008
    var lock = NSLock()
    
    let concurrentQueue = DispatchQueue(label: "concurrentQueue", attributes: .concurrent)
    
     func withdrawal(of amount: Double?) {
        
//        lock.lock()
        
        concurrentQueue.async(flags: .barrier) {
            
            guard amount != nil, amount != 0 else {
                
                return
            }
            
            if let amt = amount, amt < self.balanceAmount {
                
                self.balanceAmount -= amt
                
                debugPrint("Amount withdrawn of \(amt) and balance Amount in account is \(self.balanceAmount)")
                
            } else {
                
                debugPrint("Withdrawal of selected amount \(amount!) is not possible as your account balance running low \(self.balanceAmount)")
            }
        }

//        lock.unlock()
    }
}

let atm = ATM()
DispatchQueue.global().async(qos: .userInteractive) {
    atm.withdrawal(of: 1309.00)
}
DispatchQueue.global().async(qos: .userInitiated) {

    atm.withdrawal(of: 100.00)
}
DispatchQueue.global().async(qos: .background) {

    atm.withdrawal(of: 209.00)
}
DispatchQueue.global().async(qos: .default) {

    atm.withdrawal(of: 190.00)
}
DispatchQueue.global().async(qos: .utility) {

    atm.withdrawal(of: 117089.00)
}
