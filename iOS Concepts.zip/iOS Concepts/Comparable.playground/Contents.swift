import UIKit

protocol x : Equatable {
    
    var name: String {get set}
    var age : Int {get set}
    var salary : Double {get set}
    
}

extension x {
    
    static func >(lhs:Self, rhs: Self) -> Bool {
        
        return lhs.age > rhs.age
    }
    
    static func < (lhs:Self, rhs: Self) -> Bool {
        
        return lhs.name < rhs.name
    }
}
struct Employee: x {
    
    var name: String
    var age : Int
    var salary : Double
    
}

let venkat = Employee(name: "Venkat", age: 34, salary: 454566.00)

let rajesh = Employee(name: "Rajesh", age: 35, salary: 454569.00)

if(venkat == rajesh) {
    
    debugPrint("equal")
} else {
    
    debugPrint("not equal")
}

if(rajesh > venkat) {
    
    debugPrint("asscend")
} else {
    
    debugPrint("dessscend")
}

