import UIKit

var group = DispatchGroup()

var resultArray : [Int] = []

//for i in 0...12 {
//
//    group.enter()
//
//        DispatchQueue.global().async {
//
//            resultArray.append(i)
//            debugPrint("i value is \(i)")
//
//            group.leave()
//
//        }
//}

//for j in 12...20 {
//
//    group.enter()
//
//        DispatchQueue.global().async {
//
//            resultArray.append(j)
//            debugPrint("j value is \(j)")
//
//            group.leave()
//
//        }
//}

group.enter()
DispatchQueue.global().asyncAfter(deadline: .now() + 10) {
    
    debugPrint("task2 completed")
    resultArray.append(2000)
    group.leave()
}

group.enter()
DispatchQueue.global().asyncAfter(deadline: .now() + 5) {
    
    debugPrint("task1 completed")
    resultArray.append(1000)
    group.leave()
}

group.notify(queue: .global()) {
    
    debugPrint("task completed, \(resultArray)")
}
