import UIKit
import Combine
import Foundation

//:- Closure

func additionClosure(val1: Int, val2: Int, closure:(_ result: Int)->Void) {
    
    let result = val1 + val2
    closure(result)
}

additionClosure(val1: 1988, val2: 1876) { result in
    
    debugPrint("result value \(result)")
}

//:- Combine Solution in place of Closure

struct PassThroughSubject {

    let publisher = PassthroughSubject<Int, Never>()

    func sendValuesViaCombine(val1: Int, val2: Int) {
        
        let result = val1 + val2
        
        publisher.send(result)
        publisher.send(completion: .finished)
    }
}
var obj = PassThroughSubject()

obj.publisher.sink { completion in
    
    debugPrint("completion")
} receiveValue: { val in
    
    debugPrint("value from PassThroughSubject \(val)")
}
obj.sendValuesViaCombine(val1: 10068, val2: 45698456)


class CurrentvalueSubject {

let publisher = CurrentValueSubject<Int, Never>(9)

    var switchVal: Int =  0 {

        didSet(newValue) {

            switchVal += newValue

            debugPrint("Switch Val Received \(switchVal)")
        }
    }
 
    
    func sendValuesViaCombine(val1: Int, val2: Int) {
        
        let result = val1 + val2
        
        publisher.send(result)
        publisher.send(completion: .finished)
    }
}
var obj1 = CurrentvalueSubject()

obj1.publisher.sink { completion in
    
    debugPrint("completion")
} receiveValue: { val in
    
    debugPrint("value from CurrentvalueSubject \(val)")
}
obj1.sendValuesViaCombine(val1: 10068, val2: 45698456)

var publisherForSwitch = [1065750, 45646, 11].publisher
publisherForSwitch.assign(to: \.switchVal, on: obj1)
