import UIKit

class Person {
    
    var name: String
    
     var apartment : Apartment?
    
    init(_name: String) {
        
        self.name = _name
    }
    
    deinit {
        
        debugPrint("deinitialized from Person class")
    }
}

class Apartment {
    
    var number : Int
    weak var person: Person?
    
    init(_number: Int) {
        
        self.number = _number
    }
    
    deinit {
        
        debugPrint("deinitialized from Apartment class")
    }
}


var vekat: Person? = Person(_name: "Venkat")
var aparment: Apartment? = Apartment(_number: 105)
vekat?.apartment = aparment
aparment?.person = vekat
vekat = nil
aparment = nil
