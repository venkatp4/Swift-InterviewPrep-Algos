//
//  ViewController.swift
//  ClosureCallBack
//
//  Created by Venkat on 09/09/22.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var userNameLbl: UILabel!
    @IBOutlet weak var passwordLbl: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }

    @IBAction func buttonTapped(_ sender: Any) {
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "SecondViewController") as? SecondViewController
        vc?.completionHandler = { [weak self] dict in
            
            guard let self = self else { return }
            self.userNameLbl.text = dict["username"] as? String
            self.passwordLbl.text = dict["password"] as? String
        }
        
        self.navigationController?.pushViewController(vc ?? SecondViewController(), animated: true)
    }
    
}

