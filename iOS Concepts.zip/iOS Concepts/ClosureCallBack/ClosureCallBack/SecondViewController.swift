//
//  SecondViewController.swift
//  ClosureCallBack
//
//  Created by Venkat on 09/09/22.
//

import UIKit

class SecondViewController: UIViewController {

    var completionHandler: (([String:Any])->Void)?

    @IBOutlet weak var userNameTF: UITextField!
    @IBOutlet weak var passwordTF: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func saveButtonTapped(_ sender: Any) {
        
        let userName = userNameTF.text
        let password = passwordTF.text
        
        let dict = ["username": userName, "password": password]
        completionHandler!(dict as [String : Any])
        self.navigationController?.popViewController(animated: true)
    }
}
