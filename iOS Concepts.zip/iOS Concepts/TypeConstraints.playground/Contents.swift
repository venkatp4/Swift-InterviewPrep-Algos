import UIKit
import Foundation

extension Array where Element == Double {
    
    func sum() -> Element {
        
        return self.reduce(0, +)
    }
}

[5.9, 8.9].sum()

//*****************************************************

protocol TypeConstraint {
    
    associatedtype AssociatedType
}

extension TypeConstraint where AssociatedType == Int {
    
    
    func doSomething() -> AssociatedType {
        
        debugPrint("calling doSomething method....")
        return 19900
    }
}

class abc : TypeConstraint {
    typealias AssociatedType = Int
 
}

let objAbc = abc()
objAbc.doSomething()

func printArray<T>(collection:[T]) {
    
    for item in collection {
        
        debugPrint("item \(item)")
    }
}
printArray(collection: [4, 0, 9, 7, 6, 1])

func printHashMapValues<k, v>(key: k, value: v) -> Dictionary<k, v> {
    
    return [key: value]
}

printHashMapValues(key: "1", value: true)

