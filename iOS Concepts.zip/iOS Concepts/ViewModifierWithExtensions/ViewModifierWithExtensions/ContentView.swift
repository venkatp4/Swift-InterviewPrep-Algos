//
//  ContentView.swift
//  ViewModifierWithExtensions
//
//  Created by Venkat on 08/10/22.
//

import SwiftUI

struct ContentView: View {
    
    @State private var userNameplaceholder : String = "UserName"
    @State private var pwdplaceholder : String = "Password"

    @State private var uNTxt : String = ""
    @State private var pwdTxt : String = ""

    
    var body: some View {
        
        
        VStack {
            
            Text("Hello, world!")
                .modifier(TextViewModifier(textType: .primary))
            
            Text("Hello, world!")
                .modifier(TextViewModifier(textType: .secondary))
            
            TextFieldModifer(userNameplaceholder, text: $uNTxt, vm: styleModifier())
            TextFieldModifer(pwdplaceholder, text: $pwdTxt, vm: styleModifier())

            customView("Test View", .orange,  TextViewstyleModifier())
            
        }.padding()
    
    }
}

struct styleModifier : ViewModifier {
    
    func body(content: Content) -> some View {
        
        content
            .padding()
            .overlay(
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(Color.green, lineWidth: 1)
                )
    }
}


struct TextViewModifier: ViewModifier {
    
    enum TextType {
        
        case primary
        case secondary
        
        
        var font: Font {
            
            switch self {
                
            case .primary:
                return .largeTitle
                
            case .secondary:
                return .subheadline
            }
        }
        
        var backgroundColor: Color {
            
            switch self {
            case .primary:
                return .red
            case .secondary:
                return .green
            }
        }
        
        var foregroundcolor: Color {
            
            switch self {
            case .primary:
                  return .red
            case .secondary:
                return .green
            }
        }
        
        var foregroundColor: Color {
            
            switch self {
            case .primary:
                return .white
            case .secondary:
                return .black
            }
        }
        
    }
    
    var textType : TextType
    
    func body(content: Content) -> some View {
        
        content
            .padding()
            .background(textType.backgroundColor)
            .foregroundColor(textType.foregroundColor)
            .font(textType.font)
        
    }
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

