//
//  ViewModifierWithExtensionsApp.swift
//  ViewModifierWithExtensions
//
//  Created by Venkat on 08/10/22.
//

import SwiftUI

@main
struct ViewModifierWithExtensionsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
