//
//  TextFieldModifer.swift
//  ViewModifierWithExtensions
//
//  Created by Venkat on 08/10/22.
//

import SwiftUI

struct TextFieldModifer<V>: View where V: ViewModifier {
    
    private let placeholder: String
    @Binding private var text : String
    private let vm: V
    
    init(_ placeholder: String, text: Binding<String>, vm: V) {
        
        self.placeholder = placeholder
        self._text = text
        self.vm = vm
    }
    var body: some View {
        
        TextField(placeholder, text: $text)
            .modifier(vm)
    }
}

struct customView<V>: View where V: ViewModifier {
    
    private let textBody: String
    private let color: Color
    private let vm: V

    init(_ textBody: String, _ color: Color, _ vm: V) {
        
        self.textBody = textBody
        self.color = color
        self.vm = vm
    }
    var body: some View {
        
        Text(textBody)
            .modifier(self.vm)
            .foregroundColor(color)
    }
}

struct TextViewstyleModifier : ViewModifier {
    
    func body(content: Content) -> some View {
        
        content
            .padding()
            .foregroundColor(.black)
            .background(.green)
    }
}
