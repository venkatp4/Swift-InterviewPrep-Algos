import UIKit

var concurrentQueue = DispatchQueue(label: "concurrentQueue", attributes: .concurrent)
var semaPhore = DispatchSemaphore(value: 4)

for i in 0...100 {
        
    concurrentQueue.async {
        semaPhore.wait()
        let songName = "songName\(i+1)"
        debugPrint("\(songName) being downloaded...!")
        sleep(2)
        debugPrint("\(songName) has been downloaded...!")
        semaPhore.signal()
    }
}
