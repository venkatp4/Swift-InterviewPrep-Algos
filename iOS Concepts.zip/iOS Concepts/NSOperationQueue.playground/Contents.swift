import UIKit
import Foundation

let operationQueue = OperationQueue()

//DispatchQueue.global().async {

let operation1 = BlockOperation {
    
    for i in 0...50 {
        
        debugPrint("i \(i)")
        debugPrint(Thread.current)
    }
}

let operation2 = BlockOperation {
    
    for j in 0...500 {
        
        debugPrint("j \(j)")
        debugPrint(Thread.current)
    }
}

let operation3 = BlockOperation {
    
    for m in 0...50 {
        
        debugPrint("m \(m)")
        debugPrint(Thread.current)
    }
}

let operation4 = BlockOperation {
    
    for n in 0...50 {
        
        debugPrint("n \(n)")
        debugPrint(Thread.current)
    }
}

operationQueue.maxConcurrentOperationCount = 4

operation2.addDependency(operation1)
operation2.addDependency(operation3)
operation2.addDependency(operation4)

//DispatchQueue.global().asyncAfter(deadline: .now() + 0.005) {
//
//    operation2.cancel()
//}


operationQueue.addOperations([operation1, operation2, operation3, operation4], waitUntilFinished: true)

    debugPrint("all tasks have been completed....")


//}
