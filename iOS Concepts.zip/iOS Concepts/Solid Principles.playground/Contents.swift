import UIKit
import Foundation

// Single Responsibility Principle

class Handler_Wrong_Approach {
    
    func handle() {
        
        let data = createRequest(ofRequest: NSURLRequest())
        let _array: [String] = parseData(data: data)
        saveDataToDatabase(array: _array)
    }
    
    func createRequest(ofRequest: NSURLRequest) -> Data {
        
        // requested for data
        return Data()
    }
    
    func parseData(data: Data) -> [String] {
        
        // data has been returned from API and parsed
        return [String]()
    }
    
    func saveDataToDatabase(array: [String]) {
        
        // files have been saved to Database
    }
}


class Handler_Correct_Approach {
    
    let netWorkHandler: NetworkHandler
    let parseHandler: ParseHandler
    let dataHandler: DatabaseHandler
    
    init(_netWorkHandler: NetworkHandler, _parseHandler: ParseHandler, _dataHandler: DatabaseHandler) {
        
        self.netWorkHandler = _netWorkHandler
        self.parseHandler = _parseHandler
        self.dataHandler = _dataHandler
    }
    
    func handler() {
        
        let data = netWorkHandler.createRequest(ofRequest: NSURLRequest())
        let _array: [String] = parseHandler.parseData(data: data)
        dataHandler.saveDataToDatabase(array: _array)
    }
}

class NetworkHandler {
    
    func createRequest(ofRequest: NSURLRequest) -> Data {
        
        // requested for data
        return Data()
    }

}

class ParseHandler {
    
    func parseData(data: Data) -> [String] {
        
        // data has been returned from API and parsed
        return [String]()
    }
}

class DatabaseHandler {
    
    func saveDataToDatabase(array: [String]) {
        
        // files have been saved to Database
    }
}

// Open-closed principle

class Car { //_Wrong_Approach
    
    var name : String?
    var color : String?
    init(_name: String?, _color: String?) {
        
        self.name = _name
        self.color = _color
    }
    func describe() {
        
    debugPrint("car is \(self.name ?? "") and color is \(self.color ?? "")")
    }
}

class Bike { //_Wrong_Approach
    
    var name : String?
    var color : String?
    init(_name: String?, _color: String?) {
        
        self.name = _name
        self.color = _color
    }
    func describe() {
        
    debugPrint("bike is \(self.name ?? "") and color is \(self.color ?? "")")
    }
}

class Logger {
    
    func printDetails() {
        
        let printableObj = [Car(_name: "BenzQ", _color: "White"), Car(_name: "Baleno", _color: "White")]
        
        printableObj.forEach { car in
            
            debugPrint("car is \(car.name ?? "") and color is \(car.color ?? "")")
        }
        
        let printableObj1 = [Bike(_name: "YFZ-s", _color: "Red-White"), Bike(_name: "Honda", _color: "White")]
        
        printableObj1.forEach { bike in
            
            debugPrint("bike is \(bike.name ?? "") and color is \(bike.color ?? "")")
        }
    }
}
let objLogger = Logger()
objLogger.printDetails()


// //_Wrong_Approach

protocol Vehicle {
 
    func printDetails()
}

class Cars: Vehicle {
    
    var name : String?
    var color : String?
    
    init(_name: String?, _color: String?) {
        
        self.name = _name
        self.color = _color
    }
    
    func printDetails() {
        
        debugPrint("car is \(self.name ?? "") and color is \(self.color ?? "")")
    }
}

class Bikes: Vehicle {
    
    var name : String?
    var color : String?
    
    init(_name: String?, _color: String?) {
        
        self.name = _name
        self.color = _color
    }
    
    func printDetails() {
        
        debugPrint("car is \(self.name ?? "") and color is \(self.color ?? "")")
    }
}
class Logger1 {
    
    func printable() {
        
        let vehicles : [Vehicle] = [Cars(_name: "BenzQ", _color: "White"), Cars(_name: "Baleno", _color: "White"),
                                    Bikes(_name: "YFZ-s", _color: "Red-White"), Bikes(_name: "Honda", _color: "White")]
        
        vehicles.forEach { vehicle in
            
            debugPrint(vehicle.printDetails())
        }
    }
}
let objLogger1 = Logger1()
objLogger1.printable()

// Liskov substitution principle

class Rectangle {  // Wrong-Approach
    
    var length: Double
    var width : Double
    
    init(_length: Double, _width: Double) {
        
        self.length = _length
        self.width = _width
    }
    
    func area() -> Double {
        
        return length * width
    }
}

class Square : Rectangle {
    
    override var length: Double {
        
        didSet {
            
            width = length
        }
    }
}

let objRectangle = Rectangle(_length: 12, _width: 12)
objRectangle.area()

let objSquare = Square(_length: 12, _width: 13)
objSquare.length = 10
objSquare.area()


// Correct-Approach

protocol Shape {
  
    var area: Double {get}
}
class RectangleBox: Shape {
    
    var length: Double
    
    var width: Double
    
    init(_length: Double, _width: Double) {
        
        self.length = _length
        self.width = _width
    }
    
    var area: Double {
        
        return length * width
    }
    
}
class SquareBox: Shape {
        
    var _width: Double = 0.0
    init(width: Double) {
        
        self._width = width
    }
    var area: Double {
        
        return pow(_width, 2)
    }
    
}
let objRBox = RectangleBox(_length: 12, _width: 15)
objRBox.area
let objSBox = SquareBox(width: 19)
objSBox.area

// Interface Segregation principle

protocol Tappable { // Wrong_Approach
    
    func SingleTap()
    func doubleTap()
    func longTap()
}
class SingleTapButton: Tappable {
    func SingleTap() {
        
    }
    
    func doubleTap() {
        //
    }
    
    func longTap() {
        //
    }
}

class DualTapButton: Tappable {
    func SingleTap() {
        //
    }
    
    func doubleTap() {
        
    }
    
    func longTap() {
        //
    }
}

// Correct_Approach

protocol SingleTappable {
    
    func SingleTap()
}
protocol DualTappable {
    
    func DualTap()
}
protocol LongTappable {
    
    func longTap()
}

class SingleButtonClick : SingleTappable {
    func SingleTap() {
        //
    }
    
    
    
}
class MultiTouchButtonClick : SingleTappable,DualTappable {
    func SingleTap() {
        //
    }
    
    func DualTap() {
        //
    }
    
   
}

class LongTouchButtonClick:  SingleTappable, DualTappable, LongTappable {
    
    
    func SingleTap() {
        //
    }
    
    func DualTap() {
        //
    }
    
    func longTap() {
        //
    }
}
// Dependency Inversion principle

class FileSystemManager { // Wrong-Approach
    
    func save(string: String) -> Bool {
        
        return true
        //data being stored in file system
    }
}

class DBSystemManager { // Wrong-Approach
    
    func save(string: String) -> Bool {
        
        return true
        //data being stored in Database
    }
}

class Store {
    
    let fileManager = FileSystemManager()
    
    func saveFiles() {
        
        fileManager.save(string: "")
    }
}

// Correct-Approach

protocol Storage {
    
    func saveFiles(string: String)-> Bool
}

class FileManager : Storage {
    
    func saveFiles(string: String) -> Bool {
        
        //data being stored in file system
        return true
    }
}
class DBManager : Storage {
    
    func saveFiles(string: String) -> Bool {
        
        //data being stored in Database system
        return true
    }
}

class StorageManager {
    
    let storage: Storage
    
    init(_storage: Storage) {
        
        self.storage = _storage
    }
    
    func saveFile() {
        
        storage.saveFiles(string: "")
    }
}

let objSM = StorageManager(_storage: FileManager())
objSM.saveFile()

let objDB = StorageManager(_storage: DBManager())
objDB.saveFile()
