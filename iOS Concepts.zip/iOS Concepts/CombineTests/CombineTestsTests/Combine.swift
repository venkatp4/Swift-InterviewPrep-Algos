//
//  Combine.swift
//  CombineTestsTests
//
//  Created by Venkat on 12/09/22.
//

import XCTest
import Combine


struct ViewModel {
    
    private var subjectPublisher = CurrentValueSubject<Int, Never>(0)
    
    var currentPublisher : AnyPublisher<String, Never> {
        
        subjectPublisher.map { value in
            
            return "\(value)"
        }
        .eraseToAnyPublisher()
    }
    
    func send(value: Int) {
        
        subjectPublisher.send(value)
    }

}
class Combine: XCTestCase {

    func testSubjectPublisher() {
        
        let viewModel = ViewModel()
        
        let valueSpy = ValueSpy(_publisher: viewModel.currentPublisher)
        
        
        viewModel.send(value: 10)
        
        XCTAssertEqual(valueSpy.values, ["0", "10"])
        
        viewModel.send(value: 1009)
        
        XCTAssertEqual(valueSpy.values, ["0", "10", "1009"])
    }
   
}

private class ValueSpy {
    
    private (set) var values = [String]()
    private var cancellable = Set<AnyCancellable>()
    
    init(_publisher: AnyPublisher<String, Never>) {
        
        _publisher.sink { [weak self] value in
            
            debugPrint(value)
            
            self?.values.append(value)
        }
        .store(in: &cancellable)
    }
}

