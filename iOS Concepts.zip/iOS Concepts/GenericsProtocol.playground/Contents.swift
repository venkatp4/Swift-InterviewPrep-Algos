import UIKit

protocol IndustryName {
    
    var name: String {get set}
}

struct Industry<Industry: IndustryName> {
    
    var industry : Industry
    
    init(_industry: Industry) {
        
        self.industry = _industry
    }
}

struct InformationTechnology: IndustryName {
    var name: String
        
}

var itObject = InformationTechnology(name: "Information Technology")
var industryObject = Industry(_industry: itObject)
industryObject.industry.name
