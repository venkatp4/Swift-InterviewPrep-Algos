//
//  ViewController.swift
//  KMMImport
//
//  Created by Venkat on 25/08/22.
//

import UIKit
import shared

class ViewController: UIViewController {
    @IBOutlet weak var textView: UITextView!
    
    var testMethod : String  {
        
        Device().testMethod()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        textView.text = testMethod
    }


}

