//
//  AsyncImageApp.swift
//  AsyncImage
//
//  Created by Venkat on 17/10/22.
//

import SwiftUI

@main
struct AsyncImageApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
