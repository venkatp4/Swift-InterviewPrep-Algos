//
//  ContentView.swift
//  AsyncImage
//
//  Created by Venkat on 17/10/22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        
    
        
        AsyncImage(url: URL(string: "https://www.hackingwithswift.com/img/paul-2.png"), scale: 2) { image in
            
            image.resizable()
            
        }placeholder: {
            
            Color.red
        }
        .frame(width: 128, height: 128)
        .clipShape(RoundedRectangle(cornerRadius: 64))
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
