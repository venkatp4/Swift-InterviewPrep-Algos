//
//  CheckedContinuationApp.swift
//  CheckedContinuation
//
//  Created by Venkat on 20/09/22.
//

import SwiftUI

@main
struct CheckedContinuationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
