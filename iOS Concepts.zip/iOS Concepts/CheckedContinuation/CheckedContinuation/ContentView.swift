//
//  ContentView.swift
//  CheckedContinuation
//
//  Created by Venkat on 20/09/22.
//

import SwiftUI

class NetworkManager {
    
    private init() {}
    
    static let shared = NetworkManager()
    
    func getImage(url: URL) async throws -> Data {
        
        do {
            
            let (data, _) = try await URLSession.shared.data(from: url)
            return data
        }
        catch {
            
            throw error
        }
    }
    
    
    func getImage1(url: URL) async throws -> Data {
        
        return try await withCheckedThrowingContinuation { continuation in
            
            URLSession.shared.dataTask(with: url) { data, response, error in
                
                if let data = data {
                    
                    continuation.resume(returning: data)
                } else if let error = error {
                    continuation.resume(throwing: error)
                } else {
                    continuation.resume(throwing: URLError.badURL as! Error)
                }
            }.resume()
        }
    }
    
    func getHeartImageFromDatabase(completionHandler: @escaping(_ image: UIImage)-> ()){
        
        DispatchQueue.global().asyncAfter(deadline: .now() + 5) {
            
            let image = UIImage(systemName: "heart.fill")
            completionHandler(image!)
        }
    }
    
    func getHearImagewithContinuation() async -> UIImage {
        
        return await withCheckedContinuation { continuation in
            
            getHeartImageFromDatabase { image in
                
                continuation.resume(returning: image)
            }
        }
    }
}

class ViewModel : ObservableObject {
    
    @Published var image : UIImage? = nil
    
    let networkManager = NetworkManager.shared
    
    func getImage() async {
        
        guard let url = URL(string: "https://picsum.photos/300") else {return}
        
        do {
            
            let data = try await networkManager.getImage1(url: url)
            
            if let _image = UIImage(data: data) {
                
                await MainActor.run {
                    
                    image = _image
                }
            }
        }catch {
            
            debugPrint(error)
        }
    }
    
    func getHeartImage() {
        
        networkManager.getHeartImageFromDatabase { [weak self] image in
            
             
                self?.image = image
        }
    }
    
    func getHeartImageWithContinuation() async {
        
        let image = await networkManager.getHearImagewithContinuation()
        self.image = image
    }
}

struct ContentView: View {
    
    @ObservedObject var viewModel = ViewModel()
    
    var body: some View {
         
        VStack {
            if let image = viewModel.image {
                
                Image(uiImage: image).frame(width: 100, height: 100)

            }
        }
        
        .task {
            
            await viewModel.getHeartImageWithContinuation()
        }
    }
        
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct NewsItem: Decodable {
    let id: Int
    let title: String
    let url: URL
}

