//
//  SpacerApp.swift
//  Spacer
//
//  Created by Venkat on 19/09/22.
//

import SwiftUI

@main
struct SpacerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
