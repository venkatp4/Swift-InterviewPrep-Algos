//
//  ContentView.swift
//  Spacer
//
//  Created by Venkat on 19/09/22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        
        
        VStack {
            
            HStack(alignment: .top) {
               
            Rectangle().fill(.red)
                .frame(width: 70, height: 70)
            
                
            Rectangle().fill(.green)
                .frame(width: 70, height: 70)
            
            Spacer()

            Rectangle().fill(.yellow)
                .frame(width: 70, height: 70)
                
            }

            
            VStack {
                
                Text("Hello World")
            }
            
            Spacer()
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .previewInterfaceOrientation(.portrait)
    }
}
