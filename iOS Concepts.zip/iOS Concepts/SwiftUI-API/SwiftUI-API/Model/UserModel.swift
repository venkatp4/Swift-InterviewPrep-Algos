//
//  UserModel.swift
//  SwiftUI-API
//
//  Created by Venkat on 15/09/22.
//

import Foundation
import Combine

struct UserModel: Decodable {
    
     var id: Int?
     var name: String?
     var email: String?
     var phone: String?
}

