//
//  ServiceManager.swift
//  SwiftUI-API
//
//  Created by Venkat on 15/09/22.
//

import Foundation
import Combine

enum ApiError : Error {
    
    case invalidResponse
    case unknownError
}

struct Response<T> {
    
    var value : T
    var response : URLResponse
}

class ServiceManager {
    
    private init() {
        
    }
    
    static let shared = ServiceManager()
    
    func call<T:Decodable>(urlRequest: URL?) -> AnyPublisher<Response<T>, Error> {
        
        return URLSession.shared.dataTaskPublisher(for: urlRequest!)
            .tryMap { (data: Data, response: URLResponse) in
                
                guard let resp = response as? HTTPURLResponse, resp.statusCode == 200 else {
                    
                    throw ApiError.invalidResponse
                }
                
                let value = try JSONDecoder().decode(T.self, from: data)
                return Response(value: value as T, response: resp)
            }.eraseToAnyPublisher()
    }
}
