//
//  UserViewModel.swift
//  SwiftUI-API
//
//  Created by Venkat on 15/09/22.
//

import Foundation
import Combine

class UserViewModel: ObservableObject {
    
    @Published var userData = [UserModel]()
    
    var cancellable = Set<AnyCancellable>()
    init() {
        
        getUserData()
    }
    func getUserData() {
        
        let _ = try? UserService.shared.getUserData()
            .receive(on: RunLoop.main)
            .sink { comp in
                
                switch comp {
                    
                case .failure(let error as NSError):
                    
                    debugPrint(error.userInfo)
                    break
                case .finished:
                    debugPrint("completed")
                    break
                }
            } receiveValue: {[weak self] user in
                
                self?.userData = user
                
                debugPrint(user)
            }
            .store(in: &cancellable)

    }
}
