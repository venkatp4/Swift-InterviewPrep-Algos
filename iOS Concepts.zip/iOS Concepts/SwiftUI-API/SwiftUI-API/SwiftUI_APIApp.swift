//
//  SwiftUI_APIApp.swift
//  SwiftUI-API
//
//  Created by Venkat on 15/09/22.
//

import SwiftUI

@main
struct SwiftUI_APIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
