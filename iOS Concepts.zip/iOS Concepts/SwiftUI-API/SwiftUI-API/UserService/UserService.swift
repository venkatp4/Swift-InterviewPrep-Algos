//
//  UserService.swift
//  SwiftUI-API
//
//  Created by Venkat on 15/09/22.
//

import Foundation
import Combine

class UserService {
    
    private init() {
        
    }
    static let shared = UserService()
    
    func getUserData() throws -> AnyPublisher<[UserModel], Error> {
        
        guard let urlRequest = URL(string: "https://jsonplaceholder.typicode.com/users") else {
            
            throw ApiError.unknownError
            
        }
            return ServiceManager.shared.call(urlRequest: urlRequest)
            .map(\.value)
            .eraseToAnyPublisher()
    }
}
