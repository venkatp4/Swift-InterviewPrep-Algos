//
//  ContentView.swift
//  SwiftUI-API
//
//  Created by Venkat on 15/09/22.
//

import SwiftUI
import Combine


struct ContentView: View {

    @ObservedObject var viewModel = UserViewModel()
        
    @State private var timeElapsed: Bool = false
    
    var body: some View {
        
        NavigationView{
            
            List(viewModel.userData, id:\.id) { row in
            
                    
                    NavigationLink( destination: DetailScreen(user: row)) {

                        VStack(alignment: .leading, spacing: 5) {

                        Text("**Name** : \(row.name ?? "")").foregroundColor(.primary)
                        Text("**Email** : \(row.email ?? "")").foregroundColor(.secondary)
                        Text("**Phone** : \(row.phone ?? "")").foregroundColor(.secondary).font(.caption)
                    }
                }
                
            }
            .navigationTitle("User Data")
            .navigationBarTitleDisplayMode(.large)
            .navigationViewStyle(.stack)
        }
    }
    
}

struct DetailScreen : View {
    
    var user : UserModel
    
    var body: some View {
        
        Text("Selected Text is \(user.name ?? "")")
    }
}
