import UIKit

//***Map***
var array = [1, 4, 6, 8 , 90, nil, nil, 17, 59, nil]

let mapArray = array.map({$0 != nil ? $0! * 2 : 0}).sorted()

mapArray

let containsMap = mapArray.map({$0 > 100})
containsMap

//***Map***

let compactMap = array.compactMap({$0})
compactMap


//***Contains***

let contains = mapArray.contains { $0 > 50 }
contains

//***ContainsWhere***

let dictionary = ["Key1": 100, "Key2": 200, "Key3": 300, "Key4": 400, "Key5": 500]
let containsWhere = dictionary.contains(where: {$0.value > 100})
containsWhere

//***Array Filter***

let filterArray = mapArray.filter({$0 > 100})
filterArray

//***Dictionary Filter***

let dictionaryfilter = ["Key1": 100, "Key2": 200, "Key3": 300, "Key4": 400, "Key5": 500]
let filterDictionary = dictionaryfilter.filter({$0.value > 200})
filterDictionary

struct User
{
    
    var name : String
    var age: Int
    var salary: Double
}

var userDictionary = [User(name: "Venkat", age: 34, salary: 45646646), User(name: "Rajesh", age: 36, salary: 4564065), User(name: "Ramesh", age: 35, salary: 568549645)]

let userDictFilter = userDictionary.filter({$0.name.prefix(1) == "V"}).first
userDictFilter

///FlatMap***
var flatDictionary = [[1, 3, 5], [2, 4, 6], [7, 8, 9]]

let flatten = flatDictionary.flatMap({$0})
flatten

///FlatMap with Nil Values***

let flatDictNilValues = [["1", "3", "5"], ["2", "4", "6", nil], ["7", "8", "9", nil]]

let resultFlatDict = flatDictNilValues.flatMap({$0}).compactMap({$0}).sorted()
resultFlatDict


///ForEach**

let forEachResult: () = array.forEach({$0?.isMultiple(of: 5)})
forEachResult

///***Map Dictionary ****

var infoDictionary: [String: String] = ["Movie": "Lord of the rings", "game": "computer game", "article" : "the mirror"]

var result_dict = infoDictionary.map {($0.key.uppercased(), $0.value.capitalized)}.sorted(by: <)

debugPrint(result_dict)

///***MapValues****

var mapValues = infoDictionary.mapValues({$0.uppercased()})
mapValues


///***Reduce***

var reduceArray = [2, 5, 9]
reduceArray.reduce(1, *)

var reduceDictionary = ["key1": -12, "key2": -12, "key3": -1]
var result_reduceDict = reduceDictionary.reduce(5, {
    
    debugPrint($0)
    return $0 - $1.value
})

result_reduceDict

///***RemoveAll***

var removeAllArray = [50, 98, 87, 6, 1, 9, 4]

removeAllArray.removeAll {$0 < 10}

removeAllArray

removeAllArray.removeAll(where: {$0 > 90})
removeAllArray


///***Sorted****

var arraySorted = [1, 3, 4,5,6,7,8,9,96,78,10]

let resultSort = arraySorted.sorted()
resultSort

let resultSort1 = arraySorted.sorted { b, a in
    
    b > a
}
resultSort1

let resultSort2 = arraySorted.sorted(by: >)
resultSort2


///Split****

var string = "How are you doing?"

let resultSplit = string.split{$0 == " "}
resultSplit

let resultSplit1 = string.split(separator: " ")
resultSplit1

let resultSplit2 = string.split(whereSeparator: {$0 == " "})
resultSplit2

var string1 = "How are          you doing?"
let resultSplit3 = string.split(separator: " ", maxSplits: 4, omittingEmptySubsequences: true)
resultSplit3
