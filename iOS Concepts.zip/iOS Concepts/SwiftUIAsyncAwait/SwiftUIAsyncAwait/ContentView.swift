//
//  ContentView.swift
//  SwiftUIAsyncAwait
//
//  Created by Venkat on 20/09/22.
//

import SwiftUI

struct ContentView: View {
    
    @State private var username = ""
    @State private var password = ""
    @State private var dynamicText: String?
    
    var body: some View {
        
        VStack {
            
            TextField("User Name", text: $username)
            TextField("User Name", text: $password)
            
            Button {
                Task {
                    await fetchData()
                }
            } label: {
                Text("Async Request")
            }

            Text(dynamicText ?? "No data received from API")
        }
    }
    
    func fetchData() async {
        
        DispatchQueue.global().asyncAfter(deadline: .now() + 5) {
            
            dynamicText = "Test Data"
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
