//
//  Network.swift
//  CombineApi
//
//  Created by Venkat on 09/09/22.
//

import Foundation
import Network

class Network {
    
    private init() {
        
    }
    
    static let shared = Network()
    
    func isConnected() -> Bool {
        
        var status : Bool = false
        let monitor = NWPathMonitor()
        monitor.pathUpdateHandler = { path in
            if path.status == .satisfied {
                
                status = true
            } else {
                
                status = false
            }
            print(path.isExpensive)
        }
        return status
    }
}
