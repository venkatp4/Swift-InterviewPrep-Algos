//
//  UserViewModel.swift
//  CombineApi
//
//  Created by Venkat on 08/09/22.
//

import Foundation
import Combine

class UserViewModel {
 
 var subscriptions = Set<AnyCancellable>()
 var arrUserData = [Todos]()
    
 var userData = PassthroughSubject<Todos, Never>()
 var errorData = PassthroughSubject<String, Never>()
    func getUserData() {
        
        let _ = try? UserService.shared.getUserData()
            .receive(on: RunLoop.main)
            .print()
            .sink { [weak self] completion in
                switch completion {
                    
                case .failure(let error as NSError):
                    self?.errorData.send(error.localizedDescription)
                    debugPrint("error, \(error)")
                    break
                    
                case .finished:
                    debugPrint("completion, \(completion)")
                    break
                }
            } receiveValue: {[weak self] (user) in
                guard let self = self else { return }
//                self.arrUserData = user
                self.userData.send(user)
            }
            .store(in: &subscriptions)
            
    }
}
