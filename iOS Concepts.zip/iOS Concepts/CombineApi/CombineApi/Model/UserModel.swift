//
//  UserModel.swift
//  CombineApi
//
//  Created by Venkat on 08/09/22.
//

import Foundation

struct UserModel: Decodable {
    
    let id: Int?
    let name: String?
    let email: String?
    let phone: String?
}
