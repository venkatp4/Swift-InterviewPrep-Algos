
import Foundation

// MARK: - Story
struct Todos: Codable {
    let code: Int
    let status: String
    let data: DataClass
}

// MARK: - DataClass
struct DataClass: Codable {
//    let pageType: [JSONAny]
//    let searchTerm: String
//    let suggestions, correctedSearchResponses: [JSONAny]
//    let ageRestricted: Bool
    let products: [Product]
}

// MARK: - Product
struct Product: Codable {
    let id, sku, merchantCode: String
    let status: Status
    let name: String
    let price: Price
    let images: [String]
    let brand: Brand
    let review: Review
    let itemCount: Int
    let defaultSku, itemSku: String
    let tags: [String]
    let formattedID, url: String
    let attributes: [Attribute]
    let productFeatures: String
    let storeClosingInfo: StoreClosingInfo
    let promoEndTime: Int
    let debugData: DebugData
    let allCategories: [String]
    let merchantVoucherCount: Int
    let expandedProducts: [ExpandedProduct]
    let location: String
    let numLocations: Int
    let badge: Badge
    let level0ID, uniqueSellingPoint: String
    let isCheap: Bool
    let merchantName: String
    let soldRangeCount: SoldRangeCount?
    let categoryIDHierarchy: [String]
    let cartLogisticOptions: [JSONAny]
    let merchantVoucherMessage: MerchantVoucherMessage
    let preorder, official: Bool

    enum CodingKeys: String, CodingKey {
        case id, sku, merchantCode, status, name, price, images, brand, review, itemCount, defaultSku, itemSku, tags
        case formattedID = "formattedId"
        case url, attributes, productFeatures, storeClosingInfo, promoEndTime, debugData, allCategories, merchantVoucherCount, expandedProducts, location, numLocations, badge
        case level0ID = "level0Id"
        case uniqueSellingPoint, isCheap, merchantName, soldRangeCount
        case categoryIDHierarchy = "categoryIdHierarchy"
        case cartLogisticOptions, merchantVoucherMessage, preorder, official
    }
}

// MARK: - Attribute
struct Attribute: Codable {
    let optionListingType: OptionListingType?
    let values: [Value]?
    let count: Int
}

enum OptionListingType: String, Codable {
    case colorPalete = "COLOR_PALETE"
}

enum Value: String, Codable {
    case multicolor = "MULTICOLOR"
}

// MARK: - Badge
struct Badge: Codable {
    let merchantBadge: MerchantBadge
    let merchantBadgeURL: String

    enum CodingKeys: String, CodingKey {
        case merchantBadge
        case merchantBadgeURL = "merchantBadgeUrl"
    }
}

enum MerchantBadge: String, Codable {
    case bronze = "Bronze"
    case diamond = "Diamond"
    case gold = "Gold"
    case none = "None"
    case silver = "Silver"
}

enum Brand: String, Codable {
    case noBrand = "no brand"
    case samsung = "Samsung"
}

// MARK: - DebugData
struct DebugData: Codable {
}

// MARK: - ExpandedProduct
struct ExpandedProduct: Codable {
    let status: Status
    let price: Price
    let images: [String]
    let review: Review
    let itemCount: Int
    let defaultSku: String
    let tags: [Tag]
    let url: String
    let promoEndTime, merchantVoucherCount, numLocations: Int
    let badge: Badge
    let cartLogisticOptions: [JSONAny]
    let merchantVoucherMessage: MerchantVoucherMessage
    let preorder, official: Bool
}

enum MerchantVoucherMessage: String, Codable {
    case noVoucherAvailable = "No voucher available"
}

// MARK: - Price
struct Price: Codable {
    let priceDisplay: String
    let strikeThroughPriceDisplay: String?
    let discount, minPrice: Int
    let offerPriceDisplay: String?
}

// MARK: - Review
struct Review: Codable {
    let rating, count: Int
    let absoluteRating: Double
}

enum Status: String, Codable {
    case available = "AVAILABLE"
}

enum Tag: String, Codable {
    case blibliShipping = "BLIBLI_SHIPPING"
    case cncAvailable = "CNC_AVAILABLE"
    case cncProduct = "CNC_PRODUCT"
    case pristine = "PRISTINE"
    case tukarTambah = "TUKAR_TAMBAH"
    case zeroPercentInstallment = "ZERO_PERCENT_INSTALLMENT"
}

// MARK: - RootCategory
//struct RootCategory: Codable {
//    let id: String
//    let name: Name
//}

enum Name: String, Codable {
    case handphoneTablet = "Handphone & Tablet"
    case peralatanElektronik = "Peralatan Elektronik"
}

// MARK: - SoldRangeCount
struct SoldRangeCount: Codable {
    let en, id: String
}

// MARK: - StoreClosingInfo
struct StoreClosingInfo: Codable {
    let storeClosed: Bool
    let endDate: Int
    let delayShipping: Bool
}

// MARK: - Encode/decode helpers

class JSONNull: Codable, Hashable {

    public static func == (lhs: JSONNull, rhs: JSONNull) -> Bool {
        return true
    }

    public var hashValue: Int {
        return 0
    }

    public init() {}

    public required init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        if !container.decodeNil() {
            throw DecodingError.typeMismatch(JSONNull.self, DecodingError.Context(codingPath: decoder.codingPath, debugDescription: "Wrong type for JSONNull"))
        }
    }

    public func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()
        try container.encodeNil()
    }
}

class JSONCodingKey: CodingKey {
    let key: String

    required init?(intValue: Int) {
        return nil
    }

    required init?(stringValue: String) {
        key = stringValue
    }

    var intValue: Int? {
        return nil
    }

    var stringValue: String {
        return key
    }
}

class JSONAny: Codable {

    let value: Any

    static func decodingError(forCodingPath codingPath: [CodingKey]) -> DecodingError {
        let context = DecodingError.Context(codingPath: codingPath, debugDescription: "Cannot decode JSONAny")
        return DecodingError.typeMismatch(JSONAny.self, context)
    }

    static func encodingError(forValue value: Any, codingPath: [CodingKey]) -> EncodingError {
        let context = EncodingError.Context(codingPath: codingPath, debugDescription: "Cannot encode JSONAny")
        return EncodingError.invalidValue(value, context)
    }

    static func decode(from container: SingleValueDecodingContainer) throws -> Any {
        if let value = try? container.decode(Bool.self) {
            return value
        }
        if let value = try? container.decode(Int64.self) {
            return value
        }
        if let value = try? container.decode(Double.self) {
            return value
        }
        if let value = try? container.decode(String.self) {
            return value
        }
        if container.decodeNil() {
            return JSONNull()
        }
        throw decodingError(forCodingPath: container.codingPath)
    }

    static func decode(from container: inout UnkeyedDecodingContainer) throws -> Any {
        if let value = try? container.decode(Bool.self) {
            return value
        }
        if let value = try? container.decode(Int64.self) {
            return value
        }
        if let value = try? container.decode(Double.self) {
            return value
        }
        if let value = try? container.decode(String.self) {
            return value
        }
        if let value = try? container.decodeNil() {
            if value {
                return JSONNull()
            }
        }
        if var container = try? container.nestedUnkeyedContainer() {
            return try decodeArray(from: &container)
        }
        if var container = try? container.nestedContainer(keyedBy: JSONCodingKey.self) {
            return try decodeDictionary(from: &container)
        }
        throw decodingError(forCodingPath: container.codingPath)
    }

    static func decode(from container: inout KeyedDecodingContainer<JSONCodingKey>, forKey key: JSONCodingKey) throws -> Any {
        if let value = try? container.decode(Bool.self, forKey: key) {
            return value
        }
        if let value = try? container.decode(Int64.self, forKey: key) {
            return value
        }
        if let value = try? container.decode(Double.self, forKey: key) {
            return value
        }
        if let value = try? container.decode(String.self, forKey: key) {
            return value
        }
        if let value = try? container.decodeNil(forKey: key) {
            if value {
                return JSONNull()
            }
        }
        if var container = try? container.nestedUnkeyedContainer(forKey: key) {
            return try decodeArray(from: &container)
        }
        if var container = try? container.nestedContainer(keyedBy: JSONCodingKey.self, forKey: key) {
            return try decodeDictionary(from: &container)
        }
        throw decodingError(forCodingPath: container.codingPath)
    }

    static func decodeArray(from container: inout UnkeyedDecodingContainer) throws -> [Any] {
        var arr: [Any] = []
        while !container.isAtEnd {
            let value = try decode(from: &container)
            arr.append(value)
        }
        return arr
    }

    static func decodeDictionary(from container: inout KeyedDecodingContainer<JSONCodingKey>) throws -> [String: Any] {
        var dict = [String: Any]()
        for key in container.allKeys {
            let value = try decode(from: &container, forKey: key)
            dict[key.stringValue] = value
        }
        return dict
    }

    static func encode(to container: inout UnkeyedEncodingContainer, array: [Any]) throws {
        for value in array {
            if let value = value as? Bool {
                try container.encode(value)
            } else if let value = value as? Int64 {
                try container.encode(value)
            } else if let value = value as? Double {
                try container.encode(value)
            } else if let value = value as? String {
                try container.encode(value)
            } else if value is JSONNull {
                try container.encodeNil()
            } else if let value = value as? [Any] {
                var container = container.nestedUnkeyedContainer()
                try encode(to: &container, array: value)
            } else if let value = value as? [String: Any] {
                var container = container.nestedContainer(keyedBy: JSONCodingKey.self)
                try encode(to: &container, dictionary: value)
            } else {
                throw encodingError(forValue: value, codingPath: container.codingPath)
            }
        }
    }

    static func encode(to container: inout KeyedEncodingContainer<JSONCodingKey>, dictionary: [String: Any]) throws {
        for (key, value) in dictionary {
            let key = JSONCodingKey(stringValue: key)!
            if let value = value as? Bool {
                try container.encode(value, forKey: key)
            } else if let value = value as? Int64 {
                try container.encode(value, forKey: key)
            } else if let value = value as? Double {
                try container.encode(value, forKey: key)
            } else if let value = value as? String {
                try container.encode(value, forKey: key)
            } else if value is JSONNull {
                try container.encodeNil(forKey: key)
            } else if let value = value as? [Any] {
                var container = container.nestedUnkeyedContainer(forKey: key)
                try encode(to: &container, array: value)
            } else if let value = value as? [String: Any] {
                var container = container.nestedContainer(keyedBy: JSONCodingKey.self, forKey: key)
                try encode(to: &container, dictionary: value)
            } else {
                throw encodingError(forValue: value, codingPath: container.codingPath)
            }
        }
    }

    static func encode(to container: inout SingleValueEncodingContainer, value: Any) throws {
        if let value = value as? Bool {
            try container.encode(value)
        } else if let value = value as? Int64 {
            try container.encode(value)
        } else if let value = value as? Double {
            try container.encode(value)
        } else if let value = value as? String {
            try container.encode(value)
        } else if value is JSONNull {
            try container.encodeNil()
        } else {
            throw encodingError(forValue: value, codingPath: container.codingPath)
        }
    }

    public required init(from decoder: Decoder) throws {
        if var arrayContainer = try? decoder.unkeyedContainer() {
            self.value = try JSONAny.decodeArray(from: &arrayContainer)
        } else if var container = try? decoder.container(keyedBy: JSONCodingKey.self) {
            self.value = try JSONAny.decodeDictionary(from: &container)
        } else {
            let container = try decoder.singleValueContainer()
            self.value = try JSONAny.decode(from: container)
        }
    }

    public func encode(to encoder: Encoder) throws {
        if let arr = self.value as? [Any] {
            var container = encoder.unkeyedContainer()
            try JSONAny.encode(to: &container, array: arr)
        } else if let dict = self.value as? [String: Any] {
            var container = encoder.container(keyedBy: JSONCodingKey.self)
            try JSONAny.encode(to: &container, dictionary: dict)
        } else {
            var container = encoder.singleValueContainer()
            try JSONAny.encode(to: &container, value: self.value)
        }
    }
}


