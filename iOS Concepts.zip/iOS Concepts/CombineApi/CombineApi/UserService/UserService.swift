//
//  UserService.swift
//  CombineApi
//
//  Created by Venkat on 08/09/22.
//

import Foundation
import Combine

class UserService {
    
    private init() {
        
        
    }
    
    static let shared = UserService()
    
    func getUserData() throws -> AnyPublisher<Todos, Error> {
        
        guard let requestUrl = URL(string: "https://www.blibli.com/backend/search/products?searchTerm=samsung&start=1&itemPerPage=24") else { throw ApiFailure.invalidError }
           
            return ServiceManager.shared.callAPI(requestUrl)
                .map(\.value)
                .eraseToAnyPublisher()

    }
}
