//
//  ViewController.swift
//  CombineApi
//
//  Created by Venkat on 08/09/22.
//

import UIKit
import Combine

class ViewController: UIViewController {

    var subscriptions = Set<AnyCancellable>()
    var subscriptions1 = Set<AnyCancellable>()

    private var userViewModel = UserViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        userViewModel.getUserData()
                        
        let _ = userViewModel.userData
        .print()
        .receive(on: RunLoop.main)
        .sink {[weak self] (user) in

            guard let self = self else {return}
            self.printable(user: user)
        }
        .store(in: &subscriptions)

        let _ = userViewModel.errorData
            .receive(on: RunLoop.main)
            .sink(receiveValue: { [weak self] error in
                guard let self = self else { return }
                self.printableError(error: error)
            })
        .store(in: &subscriptions1)
    }
    
    func printable(user: Todos) {
        
        debugPrint("user details \(user)")
    }
    
    func printableError(error: String) {
        
        debugPrint("error details \(error)")
    }
}

