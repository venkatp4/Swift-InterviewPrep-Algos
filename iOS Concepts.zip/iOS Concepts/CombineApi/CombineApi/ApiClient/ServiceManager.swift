//
//  ServiceManager.swift
//  CombineApi
//
//  Created by Venkat on 08/09/22.
//

import Foundation
import Combine

enum ApiFailure: Error {
    
    case invalidServerResponse
    case invalidError
    case noInternet
}
struct Response<T> {
    
    let value: T
    let response: URLResponse
    
}
class ServiceManager  {
    
    let network = Network.shared
    
    private init() {
        
        
    }
    
    static let shared = ServiceManager()
    
    
    func callAPI<T: Decodable>(_ url: URL?) -> AnyPublisher<Response<T>, Error> {
        
        return URLSession.shared.dataTaskPublisher(for: url!)
            .tryMap { (data: Data, response: URLResponse) in
                    
                guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
                    
                    switch (response as? HTTPURLResponse)?.statusCode {
                        
                        case 300:
                            throw ApiFailure.invalidServerResponse
                        
                        default:
                            throw ApiFailure.invalidError
                    }
                }
                
                let decoder = JSONDecoder()
                let value = try decoder.decode(T.self, from: data)
                return Response(value: value, response: response)
            }
            
            .receive(on: RunLoop.main)
            .eraseToAnyPublisher()
        
    }
}
