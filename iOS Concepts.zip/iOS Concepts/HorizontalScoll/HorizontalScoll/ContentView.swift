//
//  ContentView.swift
//  HorizontalScoll
//
//  Created by Venkat on 28/09/22.
//

import SwiftUI

extension HorizontalAlignment {
    
    enum HorizontalAlignmentGuide : AlignmentID {
        
        static func defaultValue(in context: ViewDimensions) -> CGFloat {
            
            context[.leading]
        }
    }
    static let leftAlignmentGuide = HorizontalAlignment(HorizontalAlignmentGuide.self)
}

struct ContentView: View {
    var body: some View {
        
        VStack {
            
        ScrollView(.horizontal, showsIndicators: false) {
            
            LazyHStack() {
                   
                ForEach (0...50, id: \.self) { index in
                                    
                    VStack(alignment: .leftAlignmentGuide) {

                        Image("profile")
                            .resizable().frame(width: 90, height: 90, alignment: .leading).cornerRadius(4).alignmentGuide(.leftAlignmentGuide, computeValue: { d in
                                d[HorizontalAlignment.leading]
                            })
                        .onTapGesture {
                            print("clicked index \(index)")
                        }
                        Text("Image\(index+1)")
                            .padding(EdgeInsets(top: 0, leading: 10, bottom: 0, trailing: 0))
                            .font(.footnote).background(.clear).alignmentGuide(.leftAlignmentGuide, computeValue: { d in
                            d[HorizontalAlignment.leading]
                        })
                    }
                }
                    
                }
            
        }.frame(maxWidth: .infinity, maxHeight: 120).background(.gray).padding(10)
        }
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
