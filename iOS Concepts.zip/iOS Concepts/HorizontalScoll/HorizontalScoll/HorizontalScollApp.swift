//
//  HorizontalScollApp.swift
//  HorizontalScoll
//
//  Created by Venkat on 28/09/22.
//

import SwiftUI

@main
struct HorizontalScollApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
