import UIKit

var concurrentQueue = DispatchQueue(label: "ConQueue", attributes: .concurrent)

var resultValue = 0

concurrentQueue.async(flags: .barrier) {

    for i in 0...100 {
        
        resultValue = i
        
        debugPrint("i value \(resultValue)")
    }
}

concurrentQueue.async(flags: .barrier) {

    for j in 100..<140 {
        
        resultValue = j
        debugPrint("j value \(resultValue)")
    }
}

concurrentQueue.async(flags: .barrier) {

    resultValue = 1000
    
    debugPrint("resultValue \(resultValue)")
}


