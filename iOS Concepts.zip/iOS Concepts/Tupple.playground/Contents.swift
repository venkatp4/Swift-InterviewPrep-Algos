import UIKit

var tupple = (name : "Venkat", age : "34", city : "Bangalore")

tupple.0

tupple.age

func splitName(name: String) -> (String, String) {
    
    let array = name.components(separatedBy: " ")
    return (array[0], array[1])
}

let name = splitName(name: "Venkateswarlu Phanitapu")
name.0
name.1

