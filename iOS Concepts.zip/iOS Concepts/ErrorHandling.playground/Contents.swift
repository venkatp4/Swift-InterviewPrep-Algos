import UIKit

enum NameError: Error {
    
    case TooLong
    case TooShort
    case TooFine
    case Default
    
}

func handleName(name: String)throws -> String {
    
    if(name.count > 20) {
        
        throw NameError.TooLong
    }
    else if(name.count > 10) {
        
        throw NameError.TooShort
    }
    else {
        throw NameError.Default
    }
}

do {
    
    try handleName(name: "Venkat")
} catch NameError.TooLong {
    
    debugPrint("name is too long")
} catch NameError.TooShort {
    
    debugPrint("name is too short")
} catch NameError.TooFine {
    
    debugPrint("name is too Fine")
} catch NameError.Default {
    
    debugPrint("name is too Default")
}
