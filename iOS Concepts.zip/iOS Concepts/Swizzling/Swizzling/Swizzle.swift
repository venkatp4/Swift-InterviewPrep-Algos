//
//  Swizzle.swift
//  Swizzling
//
//  Created by Venkat on 11/08/22.
//

import Foundation

class Swizzle : NSObject {
    
    
    @objc dynamic func originalMethod() -> Int {
        
        debugPrint("calling original Method")
        return 100
    }
    
    @objc dynamic func duplicateMethod() -> Int {
        
        debugPrint("calling duplicate Method")
        return 200
    }
    
}

extension Swizzle {
    
    func SwizzleProcess() {
        
        let original = class_getInstanceMethod(Swizzle.self, #selector(Swizzle.originalMethod))
        let duplicate = class_getInstanceMethod(Swizzle.self, #selector(Swizzle.duplicateMethod))
                
        method_exchangeImplementations(original!, duplicate!)
    }
}
