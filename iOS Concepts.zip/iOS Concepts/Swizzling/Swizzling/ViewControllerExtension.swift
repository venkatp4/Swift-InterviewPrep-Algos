//
//  ViewControllerExtension.swift
//  Swizzling
//
//  Created by Venkat on 11/08/22.
//

import UIKit

extension UIViewController {
    
    @objc dynamic func pre_ViewWillAppear(_ animated: Bool) {
        
        debugPrint("pre_ViewWillAppear method getting called....")
        
        self.view.backgroundColor = .red
        
        self.pre_ViewWillAppear(true)
        
    }
}
