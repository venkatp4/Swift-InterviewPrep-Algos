//
//  ViewController.swift
//  Swizzling
//
//  Created by Venkat on 11/08/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "First Controller"
        
//        let swizzleObj = Swizzle()
//        debugPrint(swizzleObj.originalMethod(), swizzleObj.duplicateMethod())
//
//        swizzleObj.SwizzleProcess()
//
//        debugPrint(swizzleObj.originalMethod(), swizzleObj.duplicateMethod())
        
    }

    override func viewWillAppear(_ animated: Bool) {
        
        super.viewWillAppear(animated)
        
        debugPrint("calling viewWillAppear")
        
        debugPrint(UIViewController.viewWillAppear(self), pre_ViewWillAppear(true))
        
        swizzleProcess()
        
        debugPrint(UIViewController.viewWillAppear(self), pre_ViewWillAppear(true))
    }
    
    func swizzleProcess() {
        
        let original = class_getInstanceMethod(ViewController.self, #selector(UIViewController.viewWillAppear(_:)))

        let duplicate = class_getInstanceMethod(ViewController.self, #selector(pre_ViewWillAppear(_:)))
        
        method_exchangeImplementations(original!, duplicate!)
        
    }
}

