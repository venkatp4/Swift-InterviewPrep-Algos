import UIKit

struct NewsStory: Identifiable, Decodable {
    let id: Int
    let title: String
    let strap: String
    let url: URL
}


struct User: Identifiable, Decodable {
    let userID, id: Int
    let title: String
    let completed: Bool
}

func loadStories() async {
    
    do {
        
        try await withThrowingTaskGroup(of: User.self, body: { group -> [User] in
            
            for i in 1...5 {
                
                let url = URL(string: "https://jsonplaceholder.typicode.com/todos/\(i)")!
                    
                let (data, _) = try await URLSession.shared.data(from: url)
                
                
                let result = try JSONDecoder().decode([User].self, from: data)
                debugPrint(result)
                return result
            }
            
            let allResult = try await group.reduce(into: [User]()) { $0 += $1 }

            return allResult.sorted{ $0.id > $1.id}
        })
        
    }catch {
        
        debugPrint("error \(error)")
    }
}

Task{
    
    await loadStories()
}
