import UIKit

//: auto closure

func autoClosure(handler: @autoclosure ()-> Void) {
    
    debugPrint("before")
    handler()
    debugPrint("after")
}

autoClosure(handler: print("autoclosure done"))


//: non escaping closure


//: escaping closure

func downloadFile(of url: URL, completionHandler:(_ success: Bool)-> Void) {

    debugPrint("before")

//    DispatchQueue.global().asyncAfter(deadline: .now() + 10) {
        
        completionHandler(true)
//    }
    
    debugPrint("after")

}
downloadFile(of: URL(string: "http://github.com")!) { success in
    
    debugPrint(success)
}
