//
//  ViewController.swift
//  Debounce(Swift)
//
//  Created by Venkat on 22/08/22.
//

import UIKit

var workItem : DispatchWorkItem?

class ViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var searchField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        searchField.delegate = self
    
    }

    func textFieldDidChangeSelection(_ textField: UITextField) {
        
        guard let searchTxt = textField.text, !searchTxt.isEmpty else { return }
                
        getApiResults(queryString: searchTxt)
    }
    
    func getApiResults(queryString: String) {
        
        workItem?.cancel()
        
        let newWorkItem = DispatchWorkItem {
            
            debugPrint("entered text is \(queryString)")
            
        }
        workItem = newWorkItem
        
        DispatchQueue.global().asyncAfter(deadline: .now() + .seconds(1), execute: workItem!)
    }
}
