//
//  CombineValidationApp.swift
//  CombineValidation
//
//  Created by Venkat on 16/09/22.
//

import SwiftUI

@main
struct CombineValidationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
