//
//  ContentView.swift
//  CombineValidation
//
//  Created by Venkat on 16/09/22.
//

import SwiftUI
import Combine

struct ContentView: View {
    
    @ObservedObject var model = ViewModel()
    
    var body: some View {
        
        VStack {
            
            Text("Field Validation").font(.headline).bold().foregroundColor(.orange)
            
            Field(placeHolder: "User Name", value: $model.username)
            
            Validator(isValid: $model.isUserValid)
            
            Field(placeHolder: "Password", value: $model.password)
            
            Validator(isValid: $model.isPwdValid)
            
            Field(placeHolder: "Password Again", value: $model.renterPassword)
            
            Validator(isValid: $model.isPwdAgainValid)
            
            SignUpButton(title: "Sign Up", model: model)
        }
        
    }
}

struct Field : View {
    
    var placeHolder: String
    
    @Binding var value: String
        
    var body: some View {
        
        TextField(placeHolder, text: $value)
            .font(.caption)
                    .padding()
                    .background(RoundedRectangle(cornerRadius: 10).fill(.gray)).opacity(0.5)
                    .foregroundColor(.black)
                    .padding()
    }
}

struct Validator : View {
    
    @Binding var isValid : Bool
    
    var body: some View {
        
        HStack {
        
            Text("Appoved").foregroundColor(isValid ? .green : .red)
        }
        
    }
}

struct SignUpButton : View {
    
    var title : String
    
    @StateObject var model: ViewModel

    var body: some View {
        
        printv("model --> \(model.isUserValid)")

        Button(title) {

        }
        .padding()
        .background(Color(red: 0, green: 0, blue: 0.5))
        .clipShape(Capsule())
        .disabled(!model.isUserValid || !model.isPwdValid || !model.isPwdAgainValid)
    }
    
    func printv( _ data : Any)-> EmptyView{
           debugPrint(data)
           return EmptyView()
    }
}
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}


