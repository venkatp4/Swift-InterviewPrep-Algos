//
//  ViewModel.swift
//  CombineValidation
//
//  Created by Venkat on 16/09/22.
//

import Foundation
import Combine

class ViewModel: ObservableObject {
    
    var cancellable = Set<AnyCancellable>()
    
    @Published var username: String = ""
    @Published var password: String = ""
    @Published var renterPassword: String = ""
    
    
    @Published var isUserValid: Bool = false
    @Published var isPwdValid: Bool = false
    @Published var isPwdAgainValid: Bool = false
    
    init() {
        
        $username
            .receive(on: RunLoop.main)
            .map { username in
                return username.count > 5
            }
            .assign(to: \.isUserValid, on: self)
            .store(in: &cancellable)
        
        $password
            .receive(on: RunLoop.main)
            .map { password in
                
                return password.count > 5
            }
            .assign(to: \.isPwdValid, on: self)
            .store(in: &cancellable)
        
        $renterPassword.combineLatest($password)
            .receive(on: RunLoop.main)
            .map { pwd, pwdAgain in
                
                return pwdAgain == pwd && pwdAgain.count > 5
            }
            .assign(to: \.isPwdAgainValid, on: self)
            .store(in: &cancellable)
        
    }
}
