import UIKit

struct Employee {
    
    var name : String
    var annualSalary : Double
    
    var monthlySalary : Double {
        
        get {
            
            debugPrint("monthlySalary")
            return annualSalary / 12
        }
        
        set {
            debugPrint("annualSalary")
            annualSalary = newValue * 12
        }
    }
}

var objEmp = Employee(name: "Venkat", annualSalary: 3500000)

debugPrint(objEmp.monthlySalary)

objEmp.monthlySalary = 700000

debugPrint(objEmp.annualSalary)


