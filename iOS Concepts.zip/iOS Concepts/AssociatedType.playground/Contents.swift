import UIKit

protocol ItemStoring {
    
    associatedtype DataType
    
    var items:[DataType] { get set }
    
     mutating func appendItem(_item: DataType) -> [DataType]
}

class StringType: ItemStoring {
    
    var items: [String] = []
    
     func appendItem(_item: String) -> [String] {
        
        items.append(_item)
        return items
    }
    
    typealias DataType = String
    
}

 var objStr = StringType()
objStr.appendItem(_item: "One")

class IntType : ItemStoring {
    var items: [Int] = []
    
    func appendItem(_item: Int) -> [Int] {
        
        items.append(_item)
        
        return items
    }
    
    typealias DataType = Int
    
}

var objInt = IntType()
objInt.appendItem(_item: 14)


enum StrType: ItemStoring {
    
    var items: [String]  {
    
        get {
            
            return self.items
        }
        set {
            
            self.items = newValue
        }
    }
    
}

extension StrType {
    
    mutating func appendItem(_item: String) -> [String] {
        
        items.append(_item)
        
        return items
    }
}

