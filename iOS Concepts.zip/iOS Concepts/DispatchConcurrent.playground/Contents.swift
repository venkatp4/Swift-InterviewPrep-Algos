import UIKit

let con1 = DispatchQueue(label: "concurrent1", attributes: .concurrent)
let con2 = DispatchQueue(label: "concurrent2", attributes: .concurrent)

con1.async {
    
    for i in 0...100 {
        
        debugPrint("i value \(i)")
    }
}

con2.async {
    
    for j in 200...300 {
        
        debugPrint("j value \(j)")
    }
}


