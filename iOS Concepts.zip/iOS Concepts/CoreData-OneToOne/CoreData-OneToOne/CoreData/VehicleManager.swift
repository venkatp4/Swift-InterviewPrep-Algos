//
//  VehicleManager.swift
//  CoreData-OneToOne
//
//  Created by Venkat on 30/08/22.
//

import Foundation
import CoreData

class VehicleManager {
    
    var context = PersistanceManager.shared.context

    private init() {
        
    }
    
    static let shared = VehicleManager()

    
    func insertRecords(vehicle: Vehicle?) -> Bool {
        
        guard let vehicle = vehicle else { return false }
        
        let personObj = CDVehicle(context: context)
        personObj.name = vehicle.name
        personObj.model = vehicle.model
        
        do {
            try context.save()
            return true
        }
        catch let err as NSError {
            
            debugPrint("error \(err.userInfo)")
            return false
        }
    }
    
    func deleteRecords() {
        
        
    }
}
