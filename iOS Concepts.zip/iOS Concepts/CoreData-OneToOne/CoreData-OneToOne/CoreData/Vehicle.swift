//
//  Vehicle.swift
//  CoreData-OneToOne
//
//  Created by Venkat on 30/08/22.
//

import Foundation

struct Vehicle {
    
    var name: String
    var model: String
    
    init(_name: String, _model: String) {
        
        self.name = _name
        self.model = _model
    }
}
