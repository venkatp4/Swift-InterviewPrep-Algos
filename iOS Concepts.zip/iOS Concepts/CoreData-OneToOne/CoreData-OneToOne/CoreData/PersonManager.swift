//
//  PersonManager.swift
//  CoreData-OneToOne
//
//  Created by Venkat on 30/08/22.
//

import Foundation
import CoreData

class PersonManager {
    
    var context = PersistanceManager.shared.context

    private init() {
        
    }
    
    static let shared = PersonManager()
    

    func insertRecords(person: Person?) -> Bool {
        
        guard let person = person else { return false }
        
        let personObj = CDPerson(context: context)
        personObj.name = person.name
        personObj.city = person.city

        if let vehicleObj = person.vehicle {
            
            let vehicle = CDVehicle(context: context)
            vehicle.name = vehicleObj.name
            vehicle.model = vehicleObj.model
        }
        do {
            try context.save()
            return true
        }
        catch let err as NSError {
            
            debugPrint("error \(err.userInfo)")
            return false
        }
    }
    
    func deleteRecords() -> Bool {
        
        
        var result : [CDPerson] = []
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "CDPerson")
        
        fetchRequest.resultType = .dictionaryResultType
        do {
            
            result = try context.fetch(fetchRequest) as? [CDPerson] ?? []
            
            for item in result {
                
                context.delete(item)
            }
            return true
            
        } catch let error as NSError {
            
            debugPrint("error \(error.userInfo)")
            return false
        }
    }
    
    func fetchRecords() -> [CDPerson] {
        
        var result : [CDPerson] = []
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "CDPerson")
        
        fetchRequest.resultType = .dictionaryResultType
        do {
            
            result = try context.fetch(fetchRequest) as? [CDPerson] ?? []
        } catch let error as NSError {
            
            debugPrint("error \(error.userInfo)")
        }
        
        return result
    }
}
