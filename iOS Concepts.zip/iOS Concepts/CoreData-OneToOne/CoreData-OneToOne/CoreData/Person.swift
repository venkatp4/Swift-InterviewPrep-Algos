//
//  Person.swift
//  CoreData-OneToOne
//
//  Created by Venkat on 30/08/22.
//

import Foundation

struct Person {
    
    var name: String
    var city: String
    var vehicle: Vehicle?
    
    init(_name: String, _city: String, _vehicle: Vehicle?) {
        
        self.name = _name
        self.city = _city
        self.vehicle = _vehicle
    }
}
