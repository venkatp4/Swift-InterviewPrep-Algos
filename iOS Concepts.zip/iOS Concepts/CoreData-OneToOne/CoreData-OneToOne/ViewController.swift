//
//  ViewController.swift
//  CoreData-OneToOne
//
//  Created by Venkat on 30/08/22.
//

import UIKit


class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
     
        
        debugPrint(NSHomeDirectory())
    }

    @IBAction func insertRecords(_ sender: Any) {
        
        let vehicleObj = Vehicle(_name: "YFAZER", _model: "2019")
        let personObj = Person(_name: "Venkat", _city: "Bangalore", _vehicle: vehicleObj)
        let result = PersonManager.shared.insertRecords(person: personObj)
        debugPrint("inserted records.... \(result)")
    }
    
    @IBAction func deleteRecords(_ sender: Any) {
        
        let result = PersonManager.shared.deleteRecords()
        debugPrint("records deleted.... \(result)")
    }
}
