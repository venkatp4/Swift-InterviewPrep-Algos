//
//  CDVehicle+CoreDataClass.swift
//  CoreData-OneToOne
//
//  Created by Venkat on 30/08/22.
//
//

import Foundation
import CoreData

@objc(CDVehicle)
public class CDVehicle: NSManagedObject {

}
