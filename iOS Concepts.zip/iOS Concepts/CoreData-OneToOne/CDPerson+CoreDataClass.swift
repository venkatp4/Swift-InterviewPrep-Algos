//
//  CDPerson+CoreDataClass.swift
//  CoreData-OneToOne
//
//  Created by Venkat on 30/08/22.
//
//

import Foundation
import CoreData

@objc(CDPerson)
public class CDPerson: NSManagedObject {

}
