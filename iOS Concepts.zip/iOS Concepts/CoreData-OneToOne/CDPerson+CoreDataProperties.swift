//
//  CDPerson+CoreDataProperties.swift
//  CoreData-OneToOne
//
//  Created by Venkat on 30/08/22.
//
//

import Foundation
import CoreData


extension CDPerson {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<CDPerson> {
        return NSFetchRequest<CDPerson>(entityName: "CDPerson")
    }

    @NSManaged public var name: String?
    @NSManaged public var city: String?
    @NSManaged public var toVehicle: CDVehicle?

}

extension CDPerson : Identifiable {

}
