import UIKit
enum CardType {
    
    case gold
    case platinum
}

protocol Card {
    
    associatedtype CardNumber
    var limit: Double { get set }
    var type: CardType {get set }
    var number: CardNumber {get set }
    
    func validateCard(number: String)
}

struct DebitCard : Card {
    typealias CardNumber = String
    var limit: Double = 1900000
    var type: CardType = .gold
    var number: CardNumber = "1122 3344 5566 7788"
    
    func validateCard(number: String) {
        
        
    }
}

struct CreditCard: Card {
    typealias CardNumber = String
    var limit: Double = 200000
    var type: CardType = .platinum
    var number: String = "2233 5566 7788 9900"
    
    func validateCard(number: String) {
        
        
    }
    
}

func getLoanEligibility() -> Bool {
    
    if(getCreditDetails().limit < getDebitDetails().limit) {
        
       return true
    } else {
        
       return false
    }
}

func getCreditDetails() -> some Card {
    
    CreditCard()
}

func getDebitDetails() -> some Card {
    
    DebitCard()
}
getLoanEligibility()
