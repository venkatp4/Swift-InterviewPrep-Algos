//
//  Product+CoreDataProperties.swift
//  Coredata-Aggregations
//
//  Created by Venkat on 30/08/22.
//
//

import Foundation
import CoreData


extension Product {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Product> {
        return NSFetchRequest<Product>(entityName: "Product")
    }

    @NSManaged public var name: String?
    @NSManaged public var price: Double
    @NSManaged public var returned: Double
    @NSManaged public var sold: Double

}

extension Product : Identifiable {

}
