//
//  Product+CoreDataClass.swift
//  Coredata-Aggregations
//
//  Created by Venkat on 30/08/22.
//
//

import Foundation
import CoreData

@objc(Product)
public class Product: NSManagedObject {

}
