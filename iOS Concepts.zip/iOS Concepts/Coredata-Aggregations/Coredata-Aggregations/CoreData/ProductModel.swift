//
//  ProductModel.swift
//  Coredata-Aggregations
//
//  Created by Venkat on 30/08/22.
//

import Foundation

struct ProductModel {
    
    var name: String
    var price, returned, sold: Double
    
    init(_name: String, _price: Double, _returnd: Double, _sold: Double) {
        
        self.name = _name
        self.price = _price
        self.returned = _returnd
        self.sold = _sold
    }
}
