//
//  ProductManager.swift
//  Coredata-Aggregations
//
//  Created by Venkat on 30/08/22.
//

import Foundation
import CoreData

let context = PersistanceManager.shared.context

struct ProductManager {
    
    private init() {
        
    }
    
    static let shared = ProductManager()
    
    func insert(product: ProductModel?) -> Bool {
        
        guard let product = product else { return false }
        
        let productModel = Product(context: context)
        productModel.name = product.name
        productModel.price = product.price
        productModel.returned = product.returned
        productModel.sold = product.sold
        
        do {
            
            try context.save()
            return true
            
        } catch let error as NSError {
            
            debugPrint(error.userInfo)
            return false
        }
        
    }
    
    func fetchRecords(context: NSManagedObjectContext) -> [[String: Any]] {
        
        var result: [[String: Any]]?
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Product")
        fetchRequest.resultType = .dictionaryResultType
//        fetchRequest.propertiesToGroupBy = ["name"]
    
        do {
        
            result = try context.fetch(fetchRequest) as? [[String: Any]]
        }
        catch let error as NSError {
            
            debugPrint("error \(error.userInfo)")
        }
        return result ?? []
    }
    
    func fetchRecordsUsingAggregateFunctions(context: NSManagedObjectContext) -> [[String: Any]] {
        
        var result : [[String: Any]]?
        
        var expressionDescriptions = [Any]()
        
        expressionDescriptions.append("name")
        
        var expressionDescription = NSExpressionDescription()
        expressionDescription.name = "Price Total"
        expressionDescription.resultType = .double
        expressionDescription.expression = NSExpression(format: "@sum.price")
        expressionDescriptions.append(expressionDescription)

        expressionDescription = NSExpressionDescription()
        expressionDescription.name = "Return"
        expressionDescription.resultType = .double
        expressionDescription.expression = NSExpression(format: "@sum.returned")
        expressionDescriptions.append(expressionDescription)

        expressionDescription = NSExpressionDescription()
        expressionDescription.name = "Sold"
        expressionDescription.resultType = .double
        expressionDescription.expression = NSExpression(format: "@sum.sold")
        expressionDescriptions.append(expressionDescription)

        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Product")
        fetchRequest.resultType = .dictionaryResultType
        fetchRequest.sortDescriptors = [NSSortDescriptor(key: "name", ascending: true)]
        fetchRequest.propertiesToGroupBy = ["name"]
        fetchRequest.propertiesToFetch = expressionDescriptions
     
        do {
            
            result = try context.fetch(fetchRequest) as? [[String: Any]]
        } catch let error as NSError {
            
            debugPrint("error \(error.userInfo)")
        }
        return result ?? []
    }
}
