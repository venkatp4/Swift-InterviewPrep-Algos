//
//  ViewController.swift
//  Coredata-Aggregations
//
//  Created by Venkat on 30/08/22.
//

import UIKit
import CoreData

class ViewController: UIViewController {
    
    var context = PersistanceManager.shared.context
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        debugPrint(NSHomeDirectory())
    }

    @IBAction func insertRecordsToDB(_ sender: Any) {
        
        let product1 = ProductModel(_name: "MacBook", _price: 167700.90, _returnd: 45, _sold: 23)
        let result1 = ProductManager.shared.insert(product: product1)
        
        let product3 = ProductModel(_name: "MacBook", _price: 164700.90, _returnd: 45, _sold: 23)
        _ = ProductManager.shared.insert(product: product3)
        
        debugPrint("result1 \(result1)")
        
        let product2 = ProductModel(_name: "iPhone", _price: 57700.90, _returnd: 10, _sold: 5)
        let result2 = ProductManager.shared.insert(product: product2)
        
        let product4 = ProductModel(_name: "iPhone", _price: 5450.90, _returnd: 10, _sold: 5)
        _ = ProductManager.shared.insert(product: product4)

        debugPrint("result2 \(result2)")
    }
    
    @IBAction func fetchRecordsFromDB(_ sender: Any) {
        
        let result = ProductManager.shared.fetchRecordsUsingAggregateFunctions(context: context)
        debugPrint("result \(result[0] as Dictionary)")
    
    }
}

