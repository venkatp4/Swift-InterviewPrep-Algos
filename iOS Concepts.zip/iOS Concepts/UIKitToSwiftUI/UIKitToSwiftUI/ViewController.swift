//
//  ViewController.swift
//  UIKitToSwiftUI
//
//  Created by Venkat on 19/09/22.
//

import UIKit
import SwiftUI

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }

    @IBAction func buttonClicked(_ sender: Any) {
    
        let swiftUIView = HomeView()
        
        addSubSwiftUIView(swiftUIView, to: view)
    }
    
}

