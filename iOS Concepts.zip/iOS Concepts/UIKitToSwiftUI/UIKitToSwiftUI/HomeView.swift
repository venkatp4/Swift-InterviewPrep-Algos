//
//  HomeView.swift
//  UIKitToSwiftUI
//
//  Created by Venkat on 19/09/22.
//

import SwiftUI

struct HomeView: View {
    
    @State var bindingVar :Int?

    var body: some View {
        NavigationView {
            
            ZStack {
                Color(UIColor.green).ignoresSafeArea()
                
                VStack {
                    
               
                Text("Hello, World!, This is a home view")
            
                    NavigationLink(destination: DetailView(), tag: 0, selection: $bindingVar){
                    Button(action: {
                        
                        bindingVar = 0
                        
                    }, label: {
                        Text("Push")
                    })
                    }
                .navigationTitle("HomeView")
                .navigationBarTitleDisplayMode(.large)
                .navigationViewStyle(.stack)
                }
                .background(.red)
            }
            
        }
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
