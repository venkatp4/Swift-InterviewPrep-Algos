//
//  DetailView.swift
//  UIKitToSwiftUI
//
//  Created by Venkat on 19/09/22.
//

import SwiftUI

struct DetailView: View {
    var body: some View {
        
        Text("Hello, World!, Detail View")
    }
}

struct DetailView_Previews: PreviewProvider {
    static var previews: some View {
        DetailView()
    }
}
