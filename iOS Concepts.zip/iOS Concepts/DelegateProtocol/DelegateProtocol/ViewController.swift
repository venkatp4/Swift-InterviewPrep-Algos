//
//  ViewController.swift
//  DelegateProtocol
//
//  Created by Venkat on 12/09/22.
//

import UIKit


class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }

    @IBAction func navigateToAnotherController(_ sender: Any) {
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "SecondViewController") as! SecondViewController
        vc.delegate = self
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
}

extension ViewController: DeveloperProtocol {
    
    func developerProgram(text: String) {
            
        debugPrint("Text received \(text)")
    }
    
    
    
}

