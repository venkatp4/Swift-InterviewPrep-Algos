//
//  SecondViewController.swift
//  DelegateProtocol
//
//  Created by Venkat on 12/09/22.
//

import UIKit

protocol DeveloperProtocol: AnyObject {
    
    func developerProgram(text: String)
}

class SecondViewController: UIViewController {

    weak var delegate: DeveloperProtocol?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func pushBackToController(_ sender: Any) {
        
        self.delegate?.developerProgram(text: "Pushed text to FirstViewController")
    }
    
}
