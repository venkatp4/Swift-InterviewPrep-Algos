//
//  ViewController.swift
//  CombineSwitchToLatest
//
//  Created by Venkat on 08/09/22.
//

import UIKit
import Combine

enum NetworkError : Error {
    
    case invalidImage
}
class ViewController: UIViewController {

    typealias Image = Int

    override func viewDidLoad() {
        super.viewDidLoad()
        
       
    }
    
    func convertImageToVideo(_ image: Image) -> AnyPublisher<Image, NetworkError> {
        
        return Future { promise in
            
                
                if image == 20 {
                    
                    promise(.failure(.invalidImage))
                } else {
                    
                    promise(.success(image))
                }
        }
        .eraseToAnyPublisher()
    }

    @IBAction func buttonTap(_ sender: Any) {
        
        var subscriptions = Set<AnyCancellable>()
        let image = PassthroughSubject<Image, NetworkError>()
        
        image
            .map({ img in
              
                self.convertImageToVideo(img)
            })
            .switchToLatest()
            .print()
                .sink { completion in
                    if case let .failure(error) = completion {
                        print("Receive error: \(error)")
                    }
                } receiveValue: { video in
                    print("Receive new video: \(video)")
                }
                .store(in: &subscriptions)
        
            image.send(0)
            image.send(50)
            image.send(250)
            image.send(20)

    }
}

