//
//  WebService.swift
//  CombineSwitchToLatest
//
//  Created by Venkat on 08/09/22.
//

import Foundation
import Combine
import UIKit
import Combine

class WebService {
    
    let images = ["lemon.jpg", "pineapple.jpg", "strawberry.jpg"]
    var index = 0

    func fetch(request: Int) -> AnyPublisher<Post, Never> {
        
        let url = URL(string: "https://jsonplaceholder.typicode.com/posts")
       
        return URLSession.shared.dataTaskPublisher(for: url!)
            .delay(for: .seconds(2), scheduler: RunLoop.main)
            .map({$0.data})
            .decode(type: Post.self, decoder: JSONDecoder())
            .replaceError(with: [])
            .handleEvents(receiveOutput: { _ in
                print("This is response from request n° \(request)")
            })
            .eraseToAnyPublisher()
    }
    
    
    func getImage() -> AnyPublisher<UIImage?, Never> {
        
        return Future<UIImage?, Never> { promise in
            
            // Simulate Delay for download
            
            DispatchQueue.global().asyncAfter(deadline: .now() + 3) { [weak self] in
                
                promise(.success(UIImage(named: self!.images[self!.index])))
            }
            
        }
        .print().map({$0})
        .receive(on: RunLoop.main)
        .eraseToAnyPublisher()
    }
}
