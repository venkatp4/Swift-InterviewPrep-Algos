import UIKit

struct Engineer<empId> : Equatable {
    
    let deptId: Int
    let name: String
}

struct Programmer {
    
    var id : Engineer<Self>
    
}

struct SalesPerson {
    
    var id : Engineer<Self>
}

let programmer = Programmer(id: Engineer<Programmer>(deptId: 1234, name: "Venkat"))
let salesPerson = SalesPerson(id: Engineer<SalesPerson>(deptId: 1234, name: "Venkat"))

if programmer.id == salesPerson.id {
    
    true
} else {
    
    false
}
