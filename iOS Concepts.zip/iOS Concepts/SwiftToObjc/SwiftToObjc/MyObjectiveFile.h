//
//  MyObjectiveFile.h
//  SwiftToObjc
//
//  Created by Venkat on 29/10/22.
//

#ifndef MyObjectiveFile_h
#define MyObjectiveFile_h


#endif /* MyObjectiveFile_h */
#import <UIKit/UIKit.h>

@interface MyObjectiveFile : NSObject
- (NSString*) sayGoodnightGracie:(NSString *)text;
@end

