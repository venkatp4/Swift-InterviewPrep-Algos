//
//  ViewController.swift
//  SwiftToObjc
//
//  Created by Venkat on 29/10/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let myObjc = MyObjectiveFile()
        print(myObjc.sayGoodnightGracie("Good Morning...,")!)
    }

}

