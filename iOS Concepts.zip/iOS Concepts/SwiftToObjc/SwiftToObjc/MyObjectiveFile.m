//
//  MyObjectiveFile.m
//  SwiftToObjc
//
//  Created by Venkat on 29/10/22.
//

#import "MyObjectiveFile.h"
#import "SwiftToObjc-Bridging-Header.h"

@implementation MyObjectiveFile {

}
- (NSString*) sayGoodnightGracie:(NSString *)text {
    NSString* str = [NSString stringWithFormat:@"%@ Gracie", text];
    
    
    return  str;
}

@end
