//
//  MySwiftFile.swift
//  SwiftToObjc
//
//  Created by Venkat on 29/10/22.
//

import Foundation

@objc class MySwiftFile: NSObject {
    
    
    @objc func swiftCallfromObjc(value: String) {
        
        print(value)
    }
    
}
