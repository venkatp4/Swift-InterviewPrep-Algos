//
//  ContentView.swift
//  LabelImageOnSameRow
//
//  Created by Venkat on 28/09/22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        
        NavigationView {
            
            GeometryReader {geometry in
           
                VStack() {
                    List((0...10), id:\.self) { row in
                
                        CardView().frame(width: geometry.size.width - 70).padding(EdgeInsets.init(top: 0, leading: 5, bottom: 0, trailing: 20))
                    }
                }
            }
        .navigationTitle("ListView")
        .navigationBarTitleDisplayMode(.large)
        .navigationViewStyle(.stack)
        }
        
    }
}
struct CardView: View {
    @Environment(\.horizontalSizeClass) var sizeClass

    var body: some View {
        
        VStack (alignment: .leading){
            VStack(alignment: .center) {
                
                Text("Apps often need to display data in similarly styled containers. These containers are often used in lists to hold each item's information. The system provides the CardView API as an easy way for you to show information inside cards that have a consistent look across the platform. These cards have a default elevation above their containing view group, so the system draws shadows below them. Cards provide an easy way to contain a group of views while providing a consistent style for the container").frame(maxWidth: .infinity, maxHeight: 200).background(.clear).padding(5)
                Divider()
                BottomView().frame(maxWidth: .infinity, maxHeight: 20, alignment: .center).padding(5)
                
            }
        }.background(.gray).cornerRadius(20)
    }
}
struct BottomView: View {
    
    var body: some View {
        
        HStack {
                HStack {
                    
                    Image(systemName: "star")
                    Image(systemName: "star")
                }.scenePadding()
            Spacer()
                HStack {
                    Image(systemName: "star")
                    Image(systemName: "star")
                }.scenePadding()
            Spacer()
                HStack {
                    Image(systemName: "star")
                    Image(systemName: "star")
                }.scenePadding()
            }
    }
}
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
