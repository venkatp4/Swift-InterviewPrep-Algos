//
//  LabelImageOnSameRowApp.swift
//  LabelImageOnSameRow
//
//  Created by Venkat on 28/09/22.
//

import SwiftUI

@main
struct LabelImageOnSameRowApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
