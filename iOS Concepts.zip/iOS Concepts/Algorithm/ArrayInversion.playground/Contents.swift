import UIKit

extension Array {
    
    var powerset: [[Element]] {
        
        if count == 0 {
            
            return [self]
        }
        else {
            
            let tail = Array(self[1..<endIndex])
            let head = self[0]
            
            let withoutHead = tail.powerset
            let withHead = withoutHead.map { $0 + [head] }
            
            return withHead + withoutHead
        }
    }
}
func arrayInversion(array: inout [Int]) {
    
    let result = array.powerset.filter({$0.count == 2})
    
    for i in result where i[0] < i[1] {
        
        print(i)
    }
}

var temp = [1, 20, 6, 4, 5]
arrayInversion(array: &temp)
