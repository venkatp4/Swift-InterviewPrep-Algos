import UIKit

class Node<T> {
    
    var data: T
    var next : Node<T>?
    
    init(_data: T, _next: Node<T>? = nil) {
        
        self.data = _data
        self.next = _next
    }
}

struct SingleLinkedList<T> {
    
    var head: Node<T>?
    var count: Int = 0
    
    func isEmpty() -> Bool {
        
        return count == 0
    }
    
    func size() -> Int {
        
        return count
    }
    
    mutating func add(element: T) {
        
        let node = Node(_data: element)
        node.next = head
        self.head = node
        count += 1
    }
    
    mutating func remove() -> T? {
        
        if isEmpty() {
            
            return nil
        }
        
        let data = self.head?.data
        
        head = self.head?.next
        count -= 1
        
        return data
    }
    
}

extension SingleLinkedList : CustomStringConvertible {
    
    var description: String {
        
        var string = ""
        
        var node = head
        
        while let n = node {
            
            string += "=> \(n.data)"
            node = node?.next
        }
        return string
    }
    
    mutating func reverse() {
        
        var previousNode : Node<T>? = nil
        var currentNode = head
        var nextNode = currentNode?.next
        
        while nextNode != nil {
                
            currentNode?.next = previousNode
            previousNode = currentNode
            currentNode = nextNode
            nextNode = currentNode?.next
        }
        
        currentNode?.next = previousNode
        self.head = currentNode
    }
}
var singleList = SingleLinkedList<Int>()

singleList.add(element: 11)
singleList.add(element: 22)
singleList.add(element: 33)
singleList.add(element: 44)
singleList.add(element: 55)
singleList.add(element: 66)

print(singleList)

singleList.reverse()

print(singleList)
