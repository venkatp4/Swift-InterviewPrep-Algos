import UIKit

func interSection(of array1: [Int], and array2:[Int]) -> [Int] {
    
    var tempArray:[Int] = []
    
    for i in array1 {
        
        for j in array2 where i == j {
                    
            tempArray.append(i)
        }
    }
    return tempArray
}

interSection(of: [1, 6, 8, 9, 78, 56], and : [2, 4, 99, 77, 56, 78])
