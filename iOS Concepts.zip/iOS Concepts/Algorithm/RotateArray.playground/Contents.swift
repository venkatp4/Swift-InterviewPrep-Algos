import UIKit

func rotateArray(array : inout [Int], degree: Int) -> [Int] {
    
    let arraySize = degree % array.count
    print(arraySize)
        let slice1 = array[..<arraySize]
        let slice2 = array[arraySize...]
        return Array(slice2 + slice1)
}

var tempArray = [1, 2, 3, 4, 5, 6, 7, 8, 9]
rotateArray(array: &tempArray, degree: 20)
