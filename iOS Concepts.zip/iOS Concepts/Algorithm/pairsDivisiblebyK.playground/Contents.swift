import UIKit

extension Array {
    
    var powerSet: [[Element]] {
        
        if count == 0 {
            
            return [self]
        } else {
            
            let tail = Array(self[1..<endIndex])
            let head = self[0]
            
            let withoutHead = tail.powerSet
            let withHead = withoutHead.map({$0 + [head]})
            
            return withHead + withoutHead
        }
    }
}

func _reduce(values:[Int], closure:(Int, Int)-> Int) -> Int {
    
    var result = values[0]
    
    for next in values[1...] {
        
        result = closure(result, next)
    }
    return result
}

func findPairsDivisibleBy(number: Int, of array:[Int]) {
    
    let temp = array.powerSet.filter({$0.count == 2})
    
    for i in temp where (_reduce(values: i, closure: {$0 + $1}) % number == 0){
       
        print(i)
    }
}

let temp = [2, 2, 1, 7, 5, 3]
var k = 4
findPairsDivisibleBy(number: k, of: temp)
