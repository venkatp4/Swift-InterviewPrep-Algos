import UIKit

func findMissElement(array : [Int]) -> Int {
    
    let array = array
    
    let size = array.count + 1
    
    let sum = array.reduce(0, +)
    
    print(size, sum)
    
    let result = size * (size + 1) / 2 - sum
    
    return result
}

var tempArray = [1, 3, 4, 5, 6, 2, 8]

findMissElement(array: tempArray)
