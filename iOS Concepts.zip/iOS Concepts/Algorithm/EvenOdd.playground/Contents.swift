import UIKit
import Foundation


func oddOrEven(array: inout [Int]) -> [Int] {
        
    for i in stride(from: 0, to: array.count, by: 2) where array[i] % 2 != 0 && array[i+1] % 2 == 0 {
        
        array.swapAt(i, i+1)
    }
    return array
}

var tempArray = [3, 6, 12, 1, 5, 8, 7, 10]

oddOrEven(array: &tempArray)


/***sum of two unsorted arrays, find all pairs from both arrays whose sum is x ***/

func findSumofPairs(of array1: [Int], array2: [Int], sum: Int?) -> [(Int, Int)] {
    
    var tupple : [(Int, Int)]? = []
    
    for i in (0..<array1.count) {
        
        for j in (0..<array2.count) {
            
            
            if array1[i] + array2[j] == sum {
                
                tupple?.append((array1[i], array2[j]))
                
                do {
                    
                    print(tupple)
                }
            }
        }
    }
    return tupple ?? [(0, 0)]
}

var result = findSumofPairs(of: [1, 2, 4, 5, 7], array2: [5, 6, 3, 4, 8], sum: 9)
print(result)


/*******Triplet Sum in Array*****/

extension Array {
    var powerset: [[Element]] {
        if count == 0 {
            return [self]
        }
        else {
            let tail = Array(self[1..<endIndex])
            let head = self[0]
            let withoutHead = tail.powerset
            let withHead = withoutHead.map { $0 + [head] }
            return withHead + withoutHead
        }
    }
}

var array = [1, 4, 45, 6, 10, 8]

for i in array.powerset where i.count == 3 && i.reduce(0, +) == 13 {
    
   print(i)
}
