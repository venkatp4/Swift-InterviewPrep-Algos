import UIKit

func sortArrayByAnotherArray(unsortedArray:inout [Int], sequenceArray:[Int]) {
    
    
//    for i in (1..<unsortedArray.count).reversed() {
        
    for j in 0..<unsortedArray.count where unsortedArray[j] != unsortedArray[j+1] {
        
            unsortedArray.swapAt(j, j+1)
        }
//    }
    
}

var unsorted = [2, 1, 2, 5, 7, 1, 9, 3, 6, 8, 8]
var sequenceArray = [2, 1, 8, 3]
sortArrayByAnotherArray(unsortedArray: &unsorted, sequenceArray: sequenceArray)
