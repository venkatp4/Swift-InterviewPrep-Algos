//: A UIKit based Playground for presenting user interface
  
import UIKit
import Foundation

func sort<T: Comparable>(array: inout [T])-> [T] {
    
    guard array == array else {return []}
    
    for i in (1..<array.count).reversed() {
       
        for j in 0..<i where array[j] > array[j+1] {
            
            array.swapAt(j+1, j)
            
            do {
                
                print(array)
            }
        }
    }
    return array
}

var unsortedIntArray: [Int] = [ -1, 2, -3, 4, 5, 6, -7, 8, 9 ]

sort(array: &unsortedIntArray)

var unsortedStringArray: [String] = ["Venkatesh", "Vijay", "Rajesh", "Santosh"]

sort(array: &unsortedStringArray)


func sortNegativeandPositive<T: BinaryInteger>(array: inout [T])-> [T] {
    
    guard array == array else {return []}
    
    for i in (1..<array.count).reversed() {
       
        for j in 0..<i where Int(array[j]) > 0 && Int(array[j+1]) < 0 {
            
            array.swapAt(j+1, j)
            
            do {
                
                print(array)
            }
        }
    }
    return array
}

var tempArray: [Int] = [ -1, 2, -3, 4, 5, 6, -7, 8, 9 ]

sortNegativeandPositive(array: &tempArray)
