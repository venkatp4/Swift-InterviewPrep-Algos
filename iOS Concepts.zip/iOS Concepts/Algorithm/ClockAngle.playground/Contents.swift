import UIKit

func angleBetweenTwoHands(hours: Int, minutes: Int) -> Int {
    
    let hours = Double(hours == 12 ? 0 : hours)
    
    let minutes = Double(minutes)
    
    let fullCycleInDg: Double = 360
    
    let minuteAngle_MinutesHand: Double = fullCycleInDg/60
    
    let hourAngle_HoursHand: Double = (fullCycleInDg/12)

    let minuteAngle_HoursHand: Double = (fullCycleInDg/12) / 60
    
    let hoursAngle = (hours * hourAngle_HoursHand) + (minutes * minuteAngle_HoursHand)
    let minuteAngle = (minutes * minuteAngle_MinutesHand)
        
    let finalResult =  hoursAngle - minuteAngle

    return Int(abs(finalResult))
}

angleBetweenTwoHands(hours: 12, minutes: 16)

