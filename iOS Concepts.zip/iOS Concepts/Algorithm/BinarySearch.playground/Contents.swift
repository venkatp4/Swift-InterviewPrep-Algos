import UIKit
import Darwin

func binarySearch(of array:[Int], searchItem: Int) -> Int? {
    
    var startIndex = 0
    
    var endIndex = array.count - 1
    
    while true {
        
        let currentIndex = (startIndex + endIndex) / 2
print(currentIndex)
        if array[currentIndex] == searchItem {
            
            return currentIndex
        } else if startIndex > endIndex {
            
            return nil
        } else {
            
            if array[currentIndex] > searchItem {
                
                endIndex = currentIndex - 1
            } else {
                
                startIndex = currentIndex + 1
            }
        }
    }
}

let tempArray = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12]

binarySearch(of: tempArray, searchItem: 1)
