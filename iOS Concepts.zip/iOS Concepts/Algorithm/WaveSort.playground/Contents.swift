import UIKit

func waveSort(values: inout [Int]) -> [Int] {
            
    for j in stride(from: 2, to: values.count, by: 2) where values[j] < values[j-1] {
            
            print(j)
            values.swapAt(j, j-1)
        }
    return values
}
var temp = [20, 10, 8, 6, 4, 2]
waveSort(values: &temp)
