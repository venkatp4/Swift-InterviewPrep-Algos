import UIKit
import CoreFoundation
import Darwin

class TreeNode<T> {
    
    var data: T
    var leftNode: TreeNode<T>?
    var rightNode: TreeNode<T>?
    
    init(_data: T, _leftNode: TreeNode<T>? = nil, _rightNode: TreeNode<T>? = nil) {
        
        self.data = _data
        self.leftNode = _leftNode
        self.rightNode = _rightNode
    }
}

struct BinaryTree<T: Comparable & CustomStringConvertible> {
    
    var rootNode: TreeNode<T>?
    
    mutating func insert(element: T) {
        
       let node = TreeNode(_data: element)
        
        if let rootNode = self.rootNode {
            
            self.insert(rootNode, node)
        } else {
            
            self.rootNode = node
        }
    }
    
    mutating func insert(_ rootNode: TreeNode<T>, _ node: TreeNode<T>) {
        
        if rootNode.data > node.data {
            
            if let leftNode = rootNode.leftNode {
                
                self.insert(leftNode, node)
            } else {
                
                rootNode.leftNode = node
            }
        } else {
            
            if let rightNode = rootNode.rightNode {
                
                self.insert(rightNode, node)
            } else {
                
                rootNode.rightNode = node
            }
        }
    }
}

extension BinaryTree {
    
    func traverse() {
        print("\n Pre Order Traversal")
        self.preorder(self.rootNode)
        print("\n Post Order Traversal")
        self.postorder(self.rootNode)
        print("\n In Order Traversal")
        self.inorder(self.rootNode)
    }
    
    func preorder(_ rootNode: TreeNode<T>?) {
        
        guard let rootNode = rootNode else {
            return
        }

        print("\(rootNode.data)", terminator: " ")
        self.preorder(rootNode.leftNode)
        self.preorder(rootNode.rightNode)
    }
    
    func postorder(_ rootNode: TreeNode<T>?) {
        
        guard let rootNode = rootNode else {
            return
        }
        
        self.postorder(rootNode.leftNode)
        self.postorder(rootNode.rightNode)
        print("\(rootNode.data)", terminator: " ")
    }
    
    func inorder(_ rootNode: TreeNode<T>?) {
        
        guard let rootNode = rootNode else {
            return
        }
        
        self.inorder(rootNode.leftNode)
        print("\(rootNode.data)", terminator: " ")
        self.inorder(rootNode.rightNode)
    }
}

extension BinaryTree {
    
    func search(element: T) {
        
        self.search(self.rootNode, element)
    }
    
    private func search(_ rootNode: TreeNode<T>?, _ element: T) {
        
        guard let rootNode = rootNode else {
            
            print("Invalid Node....\(element)")
            return
        }
        
        if element > rootNode.data {
            
            self.search(rootNode.rightNode, element)
        } else if element < rootNode.data {
            
            self.search(rootNode.leftNode, element)
        } else {
            
            print("\n element found...!\(rootNode.data)")
        }
    }
}
var tree = BinaryTree<String>()
tree.insert(element: "F")
tree.insert(element: "G")
tree.insert(element: "A")
tree.insert(element: "B")
tree.insert(element: "D")
tree.insert(element: "E")
tree.insert(element: "N")
tree.insert(element: "T")
tree.insert(element: "H")

tree.traverse()

tree.search(element: "E")
tree.search(element: "H")
