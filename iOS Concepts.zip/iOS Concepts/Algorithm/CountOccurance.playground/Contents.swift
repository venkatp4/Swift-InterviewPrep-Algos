import UIKit

func countOccurrences<T: Comparable>(of key: T, in array: [T]) -> Int {
 
    var leftBoundary : Int {
        
        var low = 0
        var high = array.count
        
        while low < high {
            
            let currentIndex = low + (high - low)/2
            
            if array[currentIndex] < key {
                
                low = currentIndex + 1
            } else {
                
                high = currentIndex
            }
        }
        return low
    }
    
    var rightBoundary : Int {
        
        var low = 0
        var high = array.count
        
        while low < high {
            
            let currentIndex = low + (high - low)/2
            
            if array[currentIndex] > key {
                
                high = currentIndex
            } else {
                
                low = currentIndex + 1
            }
        }
        return low
    }

  return rightBoundary - leftBoundary
}

let array = [1, 3, 3, 4, 4, 4, 5, 5, 6, 7, 7, 7, 7]

countOccurrences(of: 7, in: array)


//:- Max occurances in Array

let myArray = [4, 4, 4, 3, 3, 3, 4, 6, 6, 5, 5, 5, 5, 5, 5, 2]

let counts = myArray.reduce(into: [:], {
    
    $0[$1, default: 0] += 1
})

if let(value, count) = counts.max(by: {$0.1 < $1.1}) {
        
    print(value, count)
}
