import UIKit

func sort(values:inout [Int]) -> [Int] {
    
    
    for i in (1..<values.count).reversed() {
        
        for j in 0..<i where values[j] > values[j + 1] {
 
            values.swapAt(j, j+1)
        }
    }
    
    return values
}
var array = [0, 2, 1, 2, 0]

sort(values: &array)
