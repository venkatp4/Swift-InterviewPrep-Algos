import UIKit

extension Array where Element: Equatable {
    
    func reorder(by preferredOrder:[Element])-> [Element] {
        
        self.sorted { a, b in
            
            guard let first = preferredOrder.firstIndex(of: a) else {return false}
                
            guard let second = preferredOrder.firstIndex(of: b) else {return true}
            
            do {
                print(self)
            }
            
            return first < second
        }
        
    }
}

let currentPosition = [4, 6, 7, 78, 4, 9, 80, 89, 78]
let preferredOrder = [4, 78]
let sorted = currentPosition.reorder(by: preferredOrder)
print(sorted)
