import UIKit
import Darwin

class TreeNode<T> {
    
    var data: T
    var previous : TreeNode<T>?
    var next : TreeNode<T>?
    
    init(_ data: T, _ previous: TreeNode<T>? = nil, _ next: TreeNode<T>? = nil) {
        
        self.data = data
        self.previous = previous
        self.next = next
    }
}

struct DoubleLinkedList<T: Comparable> {
    
    var head: TreeNode<T>?
    var tail: TreeNode<T>?
    
    var count: Int = 0
    
    mutating func prepend(element: T) {
        
        let node = TreeNode(element)
        guard self.head != nil else {
            
            self.head = node
            self.tail = node
            count += 1
            return
        }
        
        self.head?.previous = node
        node.next = self.head
        self.head = node
        count += 1
    }
    
    mutating func append(element: T) {
        
        let node = TreeNode(element)
        guard self.head != nil else {
            
            self.head = node
            self.tail = node
            count += 1
            return
        }
        
        self.tail?.next = node
        node.previous = self.tail
        self.tail = node
        count += 1
    }
    
    func allItems() ->[T?] {
        
        guard self.head != nil  else {
            return []
        }
        var items:[T] = []
        var currentNode = self.head
        
        while currentNode != nil {
            
            items.append(currentNode as! T)
            currentNode = currentNode?.next
        }
        return items
    }

    mutating func insert(_ value: T, _ atIndex: Int) {
        
        guard atIndex > 0 && atIndex <= self.count  else {
            
            print("Invalid item \(value) at Index \(atIndex)")
            return
        }
        
        if atIndex == 0 {
            
            self.prepend(element: value)
        }
        else if atIndex == self.count {
            
            self.append(element: value)
        }else {
            
            var currentNode = self.head
            for _ in 0..<atIndex {
                
                currentNode = currentNode?.next
            }
            
            let node = TreeNode(value)
            
            currentNode?.previous?.next = node
            node.previous = currentNode?.previous
            currentNode?.previous = node
            node.next = currentNode
            count += 1
        }
    }
}

extension DoubleLinkedList: CustomStringConvertible {
    
    var description: String  {
        
        var string = ""
        var currentNode = self.head
        
        while let n = currentNode {
            
            string += "\(n.data)<=>"
            currentNode = currentNode?.next
        }
        return string
    }
}

var doubleLinkedList = DoubleLinkedList<String>()
doubleLinkedList.append(element: "One")
doubleLinkedList.append(element: "Two")
doubleLinkedList.append(element: "Three")
doubleLinkedList.append(element: "Four")
doubleLinkedList.append(element: "Five")
doubleLinkedList.prepend(element: "Six")
print(doubleLinkedList)
doubleLinkedList.insert("Ten", 4)
print(doubleLinkedList)

