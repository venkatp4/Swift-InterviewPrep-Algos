//
//  DynamicHeight.swift
//  SwiftUI-Basic
//
//  Created by Venkat on 13/09/22.
//

import SwiftUI

struct DynamicHeight: View {
    var body: some View {
        
        
        GeometryReader {geo in
        
            VStack {
            
                
                HStack {
                    
                    Text("Dynamic Height safdsffsfsfsfasfsf").frame(width: 100, height: nil, alignment: .leading).padding(10)
                    Spacer()
                    Text("Dynamic Height asdfklsfahskflahsfhasfahsjfahlsjkfalksfahksj alskdfhkfhalskfhlkf flaskfhklfhalsfhalflaksfhalskfhaslkfhaklfhalsfhasjk")
                 
                }
                .fixedSize(horizontal: false, vertical: true)
                .padding(10).background(.yellow).font(.headline)
                
                Text("SwiftUI ").foregroundColor(.blue)
                + Text("is ").foregroundColor(.orange).fontWeight(.black)
                + Text("awesome language").foregroundColor(.green)

            
                HStack {
                    Text("This is a short string.")
                        .padding()
                        .frame(maxHeight: .infinity)
                        .background(.brown)

                    Text("This is a very long string with lots and lots of text that will definitely run across multiple lines because it's just so long.")
                        .padding()
                        .frame(maxHeight: .infinity)
                        .background(.green)
                }
                .fixedSize(horizontal: false, vertical: true)
                .frame(maxHeight: 200)
                
                Button("Click me asdlffsfhflskhfalkahslkfhaklfahsfkahskfhafahjs") {
                    // Perform action here
                }
                .frame(width: 100, height: .infinity)
                .background(Color.yellow)
                
        }.frame(width: UIScreen.main.bounds.width, height: geo.size.height, alignment: .top).background(.red)
        
            
    }
    }
}

struct DynamicHeight_Previews: PreviewProvider {
    static var previews: some View {
        DynamicHeight()
    }
}
