//
//  SwiftUI_BasicApp.swift
//  SwiftUI-Basic
//
//  Created by Venkat on 12/09/22.
//

import SwiftUI

@main
struct SwiftUI_BasicApp: App {
    var body: some Scene {
        WindowGroup {
            
//            BasicView()
//            State_Bind()
//              Navigation()
//            Environments()
//                StackView()
//            DynamicHeight()
//            CustomButton()
//            StateObject_ObservableObject()
//            ListView()
//            SectionListView()
//            CustomView()
            CustomView1()
//              CustomView2()
                Spacer()
        }
    }
}
