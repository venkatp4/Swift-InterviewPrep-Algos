//
//  ContentView.swift
//  SwiftUI-Basic
//
//  Created by Venkat on 12/09/22.
//

import SwiftUI
import Combine

struct BasicView: View {
    
    @State private var name = ""
    var body: some View {
        
        Form {
        
            TextField("Enter Your Name", text: $name)
            Text("Your changes to TextField is \(name)")
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        BasicView()
    }
}
