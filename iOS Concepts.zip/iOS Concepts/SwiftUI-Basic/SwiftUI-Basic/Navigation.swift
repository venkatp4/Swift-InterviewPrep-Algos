//
//  Navigation.swift
//  SwiftUI-Basic
//
//  Created by Venkat on 13/09/22.
//

import SwiftUI

struct Navigation: View {
    
    var body: some View {
        
    NavigationView {
            
        VStack(spacing: 30) {
            
            NavigationLink(destination: SecondPage(dynamicStr: "First String")) {
            
                    Text("Hello, World!")
            }
                
            NavigationLink(destination: SecondPage(dynamicStr: "Second String")) {
                        
                    Text("Sample Label 2")
            }
                
            .navigationTitle(Text("First Screen"))
            .navigationBarTitleDisplayMode(.automatic)
            
        }
        
    }
    }
}

struct SecondPage: View {
    
    var dynamicStr: String
    
    @Environment (\.dismiss) var disconnect
    
    var body: some View {
        
        Button {
            
            disconnect()
            
        } label: {
            
            Text(dynamicStr)
        }

    }
    
}
struct Navigation_Previews: PreviewProvider {
    static var previews: some View {
        Navigation()
    }
}
