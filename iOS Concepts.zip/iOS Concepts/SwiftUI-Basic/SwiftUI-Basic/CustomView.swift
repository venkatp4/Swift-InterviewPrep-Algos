//
//  CustomView.swift
//  SwiftUI-Basic
//
//  Created by Venkat on 14/09/22.
//

import SwiftUI

struct CustomView: View {
   
    @State private var searchText: String = ""
        
    @Environment(\.horizontalSizeClass) var hSizeClass
    @Environment(\.verticalSizeClass) var vSizeClass
    
    var body: some View {
    
        
        NavigationView {
            
//            if hSizeClass == .compact && vSizeClass == .regular {
            ZStack {
                Color.orange.opacity(0.5).ignoresSafeArea()
                VStack {
                    VStack(alignment: .leading) {
                        
                        Text("Creative Mints")
                            .foregroundColor(.secondary).font(.system(size: 20.0).bold()).padding()
                        
                        .searchable(text: $searchText)
                        
                        
                    }.frame(width: UIScreen.main.bounds.size.width-40, height: 40, alignment: .leading)
                        .padding()
                    
                    HStack {

                        BoxShaped(data: Data(image: "cloud.rain", color: .green, backgroudImage: "", heading: "Credit Cards", caption: "3 cards"))
                        BoxShaped(data: Data(image: "cloud.sun.rain", color: .red, backgroudImage: "", heading: "Transactions", caption: "3 payments"))
                    }
                    HStack {
                        
                        BoxShaped(data: Data(image: "cloud.rain", color: .brown, backgroudImage: "", heading: "Credit Cards", caption: "3 cards"))
                        BoxShaped(data: Data(image: "cloud.sun.rain", color: .blue, backgroudImage: "", heading: "Transactions", caption: "3 payments"))
                    }
                    Spacer()
                }
        }
                .navigationTitle(Text("Welcome Back"))
                .navigationBarTitleDisplayMode(.large).foregroundColor(.primary)

//            } else {
//
//                VStack {
//
//                    Text("app does not support in Landscape mode")
//                }
//            }
        } .navigationViewStyle(.stack)
    }
}

struct Data {
    
    var image: String
    var color: Color
    var backgroudImage : String
    var heading: String
    var caption: String
    
}
struct BoxShaped: View {
    
    let screenWidth = UIScreen.main.bounds.size.width
    let screenHeight = UIScreen.main.bounds.size.height
    
    var data: Data
    
    var body: some View {
        
        ZStack {
            
            VStack (alignment: .leading, spacing: 10){

                Image(systemName: data.image)
                    .resizable()
                    .frame(width: 25, height: 25)
                    .clipShape(Circle())
                    .padding()
                    
                Text("\(data.heading)")
                    .font(.custom("Helvetica", size: 14.0))
                    .fixedSize(horizontal: true, vertical: false)
                    .padding(.leading)
                
                Text("\(data.caption)")
                    .font(.custom("Helvetica", size: 10.0))
                    .fixedSize(horizontal: true, vertical: false)
                    .padding(.leading)
                    .padding(.bottom)
            }
            
            .frame(width: screenWidth/2-15, height: screenWidth/2, alignment: .bottomLeading)
           
        }
        .frame(width: screenWidth/2-15, height: screenWidth/2, alignment: .bottomLeading)
        .background(data.color)
        .cornerRadius(7.0)
        
    }
}

struct CustomView_Previews: PreviewProvider {
    static var previews: some View {
        CustomView()
            .previewInterfaceOrientation(.portraitUpsideDown)
    }
}
