//
//  State:Bind.swift
//  SwiftUI-Basic
//
//  Created by Venkat on 13/09/22.
//

import SwiftUI


struct CounterButton: View {
    
    @Binding var count: Int
    
    var body: some View {
     
        Button(" clicked \(count) times ") {
            
            count += 1
        }

    }
}
struct State_Bind: View {
    
    @State private var counter: Int = 0
    
    var body: some View {
        
        Text("Counter Example with State/Bind....")
        
        CounterButton(count: $counter)
    }
}

struct State_Bind_Previews: PreviewProvider {
    static var previews: some View {
        State_Bind()
    }
}
