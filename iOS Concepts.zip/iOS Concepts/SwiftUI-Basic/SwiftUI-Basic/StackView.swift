//
//  StackView.swift
//  SwiftUI-Basic
//
//  Created by Venkat on 13/09/22.
//

import SwiftUI

struct StackView: View {
    var body: some View {
       
    VStack (alignment: .center) {
        
            Text("Hello, World1")
            Text("Hello, World2")
            Text("Hello, World3")
            Text("Hello, World4")
    }
        .frame(
              minWidth: 0,
              maxWidth: .infinity,
              minHeight: 0,
              maxHeight: 100,
              alignment: .topLeading
            )
        .background(Color.red)
        
        VStack {
            
            Text("Hello, World5")
        }
        ScrollView (showsIndicators: false) {
           
            GeometryReader { geometry in

            VStack {
            
            Button {
                
            } label: {
                Text("Login").fontWeight(.bold).foregroundColor(Color.green).font(.caption)
            }
            .padding(10)
            
            Button {
                
            } label: {
                Text("Remember Me").fontWeight(.bold).foregroundColor(Color.green).font(.largeTitle)
            }
            .padding(10)
            
            Button {
                
            } label: {
                Text("Remember Me").fontWeight(.bold).foregroundColor(Color.green).font(.largeTitle)
            }
            .padding(10)
            
            Button {
                
            } label: {
                Text("Remember Me").fontWeight(.bold).foregroundColor(Color.green).font(.largeTitle)
            }
            .padding(10)
            
            Button {
                
            } label: {
                Text("Remember Me").fontWeight(.bold).foregroundColor(Color.green).font(.largeTitle)
            }
            .padding(10)
            
            Button {
                
            } label: {
                Text("Remember Me").fontWeight(.bold).foregroundColor(Color.green).font(.largeTitle)
            }
            .padding(10)
            
            
            Button {
                
            } label: {
                Text("Remember Me").fontWeight(.bold).foregroundColor(Color.green).font(.largeTitle)
            }
            .padding(10)
            
            Button {
                
            } label: {
                Text("Remember Me").fontWeight(.bold).foregroundColor(Color.green).font(.largeTitle)
            }
            .padding(10)
            
            Button {
                
            } label: {
                Text("Remember Me").fontWeight(.bold).foregroundColor(Color.green).font(.largeTitle)
            }
            .padding(10)
            
            Button {
                
            } label: {
                Text("Remember Me").fontWeight(.bold).foregroundColor(Color.green).font(.largeTitle)
            }
            .padding(10)

        }
            .frame(width: geometry.size.width, height: geometry.size.height, alignment: .topLeading).background(Color.brown)
        }
        
        Spacer()
        
        }

    }
    }

struct StackView_Previews: PreviewProvider {
    static var previews: some View {
        StackView()
    }
}
