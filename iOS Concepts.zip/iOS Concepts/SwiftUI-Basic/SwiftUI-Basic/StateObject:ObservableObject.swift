//
//  StateObject:ObservableObject.swift
//  SwiftUI-Basic
//
//  Created by Venkat on 14/09/22.
//

import SwiftUI

class Employee : ObservableObject {
    
    @Published var name = "Venkat"
    var email = "panidapu.mca@gmail.com"
}

struct StateObject_ObservableObject: View {
    
    @StateObject var emp = Employee()
    @State var selection: Int?
    var body: some View {
        
        VStack {

        NavigationView {

            NavigationLink(destination: DetailsView(emp: emp), tag: 1, selection: $selection) {
               
              Text("Push to Another Controller \(emp.name)")
                }
            .navigationTitle(Text("StateObject/ObservableObject"))
            .navigationBarTitleDisplayMode(.large)
            }
            
            Button {
                print("login tapped")
                self.selection = 1
                
            } label: {
                Text("Push to Another Controller")
            }
            
        }
        .frame(width: .infinity, height: .infinity, alignment: .top)
    }
}

struct DetailsView: View {
    
    @ObservedObject var emp : Employee
    
    var body: some View {
        
        Text("Details Page \(emp.name)")
    }
}

struct StateObject_ObservableObject_Previews: PreviewProvider {
    static var previews: some View {
        StateObject_ObservableObject()
            .previewInterfaceOrientation(.portrait)
    }
}
