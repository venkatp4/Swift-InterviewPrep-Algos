//
//  Environment.swift
//  SwiftUI-Basic
//
//  Created by Venkat on 13/09/22.
//

import SwiftUI

class User: ObservableObject {
    
   @Published var count = 0
}

struct Environments: View {
    
    @StateObject var user = User()
    
    var body: some View {
        
        NavigationView {
           
            VStack(spacing: 30) {
            
                NavigationLink(destination: ChangeView()) {
                
                Text("user Count \(user.count)")
                
                    .navigationTitle("HomePage")
                    .navigationBarTitleDisplayMode(.large)
                    .statusBar(hidden: true)
                    .navigationBarItems(
                            leading:
                                Button("Subtract 1") {
                                    user.count -= 1
                                },
                            trailing:
                                Button("Add 1") {
                                    user.count += 1
                                }
                        )
                }
            .environmentObject(user)
        }
    }
        .navigationViewStyle(.stack)
    }
}
struct ChangeView: View {
   
    @EnvironmentObject var user: User
    
    var body: some View {
        
            
                Text("Hello, World!, This is Environment \n and count is \(user.count)")
                Button {
                    user.count += 1
                } label: {
                   
                    Text("Count Increment")
                }
    }
}

