//
//  CustomView2.swift
//  SwiftUI-Basic
//
//  Created by Venkat on 15/09/22.
//

import SwiftUI

struct CustomView2: View {
    var body: some View {
        
        
        ZStack {
            
            VStack {
                
                Rectangle()
                    .frame(width: 100, height: 100, alignment: .center)
            }
            .offset(x: 200, y: 0)
            
            VStack {
                
                Rectangle()
                    .frame(width: 100, height: 100, alignment: .center)
            }
            .position(x: 200, y: 0)
        }
        .frame(width: 200, height: 200, alignment: .center)
        .background(.red)
    }
}

struct CustomView2_Previews: PreviewProvider {
    static var previews: some View {
        CustomView2()
    }
}
