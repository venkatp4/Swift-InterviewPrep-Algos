//
//  CustomView1.swift
//  SwiftUI-Basic
//
//  Created by Venkat on 15/09/22.
//

import SwiftUI

struct CustomView1: View {
    
    @State private var userName : String = ""
    @State private var password : String = ""
    
    var body: some View {
      
        ZStack {
            
            Color.purple.opacity(0.07).ignoresSafeArea()
            
            VStack {
                
                
                Text("SignUp").foregroundColor(.orange).font(.title).bold()
                    .frame(maxWidth: .infinity, maxHeight: 50, alignment: .center)
                    .padding(10)
                
                
                Text("UserName").font(.headline)
                    .frame(maxWidth: .infinity, maxHeight: 50, alignment: .leading)
                    .padding(.leading, 10)
                
                TextField("Enter UserName", text: $userName)
                    .frame(maxWidth: .infinity, maxHeight: 50, alignment: .leading)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding(.leading, 10)
                    .padding(.trailing, 10)
                
                Text("Password").font(.headline)
                    .frame(maxWidth: .infinity, maxHeight: 40, alignment: .leading)
                .padding(.leading, 10)
                
                SecureField("Enter Password", text: $password)
                    .frame(maxWidth: .infinity, maxHeight: 40, alignment: .leading)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding(.leading, 10)
                    .padding(.trailing, 10)

                Button {
                    
                } label: {
                    
                    Text("Confirm").foregroundColor(.white).font(.headline)
                        .frame(maxWidth: .infinity, maxHeight: 40)
                        .background(.brown)
                        .clipShape(RoundedRectangle(cornerRadius: 5))
                        .padding(.leading, 10)
                        .padding(.trailing, 10)
                        .padding(.top, 10)

                }
                
                Button {
                    
                } label: {
                    
                    Text("Sign In").foregroundColor(.white).font(.headline)
                        .frame(maxWidth: .infinity, maxHeight: 40)
                        .background(.brown)
                        .clipShape(RoundedRectangle(cornerRadius: 5))
                        .padding(.leading, 10)
                        .padding(.trailing, 10)
                        .padding(.top, 10)

                }.disabled(isUserNameValid() || isPasswordValid())
            
            }
            
            HStack {
                Spacer()
                Text("Forgot Password ?").font(.system(size: 12.0)).foregroundColor(.red)
                    .frame(maxWidth: 150, maxHeight: .infinity, alignment: .bottomTrailing)
                 .padding(.trailing, 10)
            }
        }
    }
    
    func isUserNameValid() -> Bool {
        
        return userName.count < 5
    }
    
    func isPasswordValid() -> Bool {
            
        return password.count < 5
    }
}

struct CustomView1_Previews: PreviewProvider {
    static var previews: some View {
        CustomView1()
    }
}
