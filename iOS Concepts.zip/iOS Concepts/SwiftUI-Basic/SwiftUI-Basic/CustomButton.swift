//
//  CustomButton.swift
//  SwiftUI-Basic
//
//  Created by Venkat on 13/09/22.
//

import SwiftUI
import UIKit

struct BigButtonStyle: ButtonStyle {
    
    var color: Color = .indigo   //default color if not initialized
    
    func makeBody(configuration: Configuration) -> some View {
            configuration.label
            .font(.title.bold())
            .padding()
            .frame(maxWidth: .infinity)
            .foregroundColor(.white)
            .background(color)
            .cornerRadius(12)
    }
}

struct CustomButton: View {
    
    var body: some View {
        
            
        Button {
            
        } label: {
            Text("Custom Button with Custom Style")
            
        }
        .buttonStyle(BigButtonStyle(color: .green))

    }
}
