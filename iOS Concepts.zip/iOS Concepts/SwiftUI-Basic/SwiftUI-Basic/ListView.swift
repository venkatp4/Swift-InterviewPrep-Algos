//
//  ListView.swift
//  SwiftUI-Basic
//
//  Created by Venkat on 14/09/22.
//

import SwiftUI
import UIKit

struct Weather: Identifiable {
    var id = UUID()
    var image: String
    var temp: Int
    var city: String
}

struct ListView: View {
   
    
        let weather : [Weather] =
        [ Weather(image: "cloud.rain", temp: 30, city: "Bangalore"),
          Weather(image: "cloud.sun.rain", temp: 20, city: "Mumbai"),
          Weather(image: "cloud.sun", temp: 19, city: "Hyderabad")
        ]
    
    var body: some View {

        
        NavigationView {
            
            List(weather) { item in
            
                NavigationLink(destination: DetailView(details: item)){
                    
                HStack {
                
                    Image(systemName: item.image).frame(width: 50, height: 10, alignment: .leading)
                    Text("\(item.temp)°").frame(width: 50, height: 10, alignment: .leading)
                    VStack {
                        Text("\(item.city)")
                    }
                }.font(.custom("HelveticNue", size: 16))
                
                }
                
            }.listStyle(.automatic)
                
            .navigationTitle("World Weather")
            .navigationBarTitleDisplayMode(.automatic)
        }
    }
}

struct DetailView: View {
    
    var details: Weather
    
    var body: some View {
        
        HStack {
            Image(systemName: details.image)
            Text("\(details.temp)")
            Text(details.city)
        }
    }
}
struct ListView_Previews: PreviewProvider {
    static var previews: some View {
        ListView()
    }
}
