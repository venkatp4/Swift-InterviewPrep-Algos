//
//  SectionListView.swift
//  SwiftUI-Basic
//
//  Created by Venkat on 14/09/22.
//

import SwiftUI

struct Item : Hashable{

    let header : String
    let footer : String
    let data: [String]
}


struct SectionListView: View {
    
    var item : [Item] = [
        Item(header: "Vegetables", footer: "", data: ["Drumstick", "Tomato", "Carrot"]),
        Item(header: "Fruits", footer: "", data: ["Apple", "Banana", "Orange"])
    ]
    
    var body: some View {
       
        List {
            ForEach(item, id:\.self) { row in
        
                Section(header: Text(row.header)){
                
                    ForEach(row.data, id:\.self) { section in
                        
                        Text("\(section)").font(.body)
                    }
                }
            }
        }.listStyle(InsetGroupedListStyle())
    }
}

struct SectionListView_Previews: PreviewProvider {
    static var previews: some View {
        SectionListView()
    }
}
