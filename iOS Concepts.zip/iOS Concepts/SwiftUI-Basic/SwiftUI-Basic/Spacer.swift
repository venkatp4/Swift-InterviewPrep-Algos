//
//  Spacer.swift
//  SwiftUI-Basic
//
//  Created by Venkat on 19/09/22.
//

import SwiftUI

struct Spacer: View {
    var body: some View {
       
        HStack {
            
            Rectangle()
                .fill(.red)
                .frame(width: 70, height: 70)
            
            Spacer()
            
            Rectangle()
                .fill(.green)
                .frame(width: 70, height: 70)
         
            Spacer()
            
            Rectangle()
                .fill(.green)
                .frame(width: 70, height: 70)
                
        }
    }
}

struct Spacer_Previews: PreviewProvider {
    static var previews: some View {
        Spacer()
    }
}
