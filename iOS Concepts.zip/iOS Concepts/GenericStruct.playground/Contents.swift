import UIKit

struct Engineer<Department>: Equatable {
    
    var id : Int
}


struct Programmer {
    
    var name : String
    var salary: Double
}

struct SalesManager {
    
    var name : String
    var salary: Double
}

let programmer = Programmer(name: "Venkat", salary: 50000000)
let sales = Programmer(name: "Rajesh", salary: 40000000)

var enginner_programmer = Engineer<Programmer>(id: 12345)
var enginner_programmer1 = Engineer<SalesManager>(id: 12345)

if(enginner_programmer == enginner_programmer1) {
    
    true
}else {
    
    false
}



struct Stack<Element: Equatable>: Equatable {
    static func == (lhs: Stack<Element>, rhs: Stack<Element>) -> Bool {
        if(lhs.items == rhs.items){
           return true
        }
            return false
    }
    
    var items: [Element] = []

    mutating func push(_ item: Element) {
        items.append(item)
    }

    mutating func pop() -> Element {
        return items.removeLast()
    }
}

var objStack = Stack<Int>(items: [1, 3, 5, 7])
objStack.push(8)

var objStack1 = Stack<String>(items: ["1", "3", "5", "7"])
objStack1.push("8")

var objStack2 = Stack<Int>(items: [1, 3, 5, 7])
objStack2.push(8)

if(objStack == objStack2) {
    true
} else
{
    false
}
