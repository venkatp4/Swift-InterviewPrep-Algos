import UIKit

protocol InOutProtocol {
    
    func inOutMethod(_value: inout Int) -> Int
}

class InOutClass : InOutProtocol {
    
    
    func inOutMethod(_value: inout Int) -> Int {
        
        return _value * 130
        
    }
    
}

let objInout = InOutClass()
var param = 15
objInout.inOutMethod(_value: &param)
