import UIKit
import Combine


protocol Subject {
    
    func sendValuesViaCombine(val1: Int, val2: Int)
}

class PassThroughSubject: Subject {

    var result: Int = 0 {
        
        didSet {
            
            debugPrint("result from PTS \(result)")
        }
    }
    func sendValuesViaCombine(val1: Int, val2: Int) {
        
        let _result = val1 + val2
        let _publisher = [_result].publisher
        
        _publisher.assign(to: \.result, on: self)
    }
    
}

class PassThroughSubject1: Subject {

    var result: Int = 0 {
        
        didSet {
            
            debugPrint("result from PTS1 \(result)")
        }
    }
    
    func sendValuesViaCombine(val1: Int, val2: Int) {
        
        let _result = val1 * val2
        let _publisher = [_result].publisher
        
        _publisher.assign(to: \.result, on: self)
    }
    
}

class Main {
    
    func sendNotification() {
        
        let obj: [Subject] = [PassThroughSubject(), PassThroughSubject1()]
        
        obj.forEach { subject in
            
            subject.sendValuesViaCombine(val1: 10495, val2: 49586346)
        }
    }
}

var obj = Main()
obj.sendNotification()
