import UIKit

var colors = ["green", "yellow", "red", "blue"]

let index = colors.firstIndex(where: {$0.elementsEqual("green1")})

debugPrint(index)

if(index == nil) {
    
    debugPrint("color not available")
} else {
    
    debugPrint("color is available")
}

if let index1 = colors.firstIndex(where: {$0.elementsEqual("yellow")}) {
    
    debugPrint("color is available \(index1)")
} else {
    
    debugPrint("color is not available")
}


