//
//  ViewController.swift
//  LocalNotifications
//
//  Created by Venkat on 28/10/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func setReminder(_ sender: Any) {
        
        let center = UNUserNotificationCenter.current()
        let content = UNMutableNotificationContent()
        content.title = "Title"
        content.body = "Body"
        content.sound = .default
        content.userInfo = ["value": "Data with Local Notification"]
        let fireDate = Calendar.current.dateComponents([.day, .month, .year,.hour, .month, .second], from: Date().addingTimeInterval(20))
        let trigger = UNCalendarNotificationTrigger(dateMatching: fireDate, repeats: true)
        let request = UNNotificationRequest(identifier: "com.cnx", content: content, trigger: trigger)
        
        center.add(request) {error in
            
            if error != nil {
                            print("Error = \(error?.localizedDescription ?? "error local notification")")
                        }
        }
        
    }
}

