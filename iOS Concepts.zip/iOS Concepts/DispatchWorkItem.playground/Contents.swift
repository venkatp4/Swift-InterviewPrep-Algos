import UIKit

var workItem : DispatchWorkItem?

var workItem1 : DispatchWorkItem?

workItem = DispatchWorkItem {
    
    
    for i in 0...1000 {
        guard let workItem = workItem, !workItem.isCancelled else {
        
            debugPrint("WorkItem task have been cancelled")
            break
            
        }
        debugPrint("i value is \(i)")
        sleep(1)
    }
}


workItem1 = DispatchWorkItem {
    
    for j in 1001...2000 {
        
        debugPrint("j value is \(j)")
        sleep(1)
    }
}

DispatchQueue.global().async(execute: workItem!)

DispatchQueue.global().asyncAfter(deadline: .now() + 5) {
    workItem?.cancel()
}
workItem?.notify(queue: .main, execute: {
    
    debugPrint("workItem task has been completed...!")
    workItem1?.perform()
})

workItem1?.notify(queue: .main, execute: {
    
    debugPrint("workItem1 task has been completed...!")
})
