//
//  CombineTestTests.swift
//  CombineTestTests
//
//  Created by Venkat on 26/10/22.
//

import XCTest
import Combine
import Swift

@testable import CombineTest


protocol UserServiceProtocol: AnyObject {
    
    func fetchUsers() -> AnyPublisher<[User], Error>
    func fetchUsersById(id: Int) -> AnyPublisher<[UserDetails], Error>
    func fetchUserDetails(id: Int) -> AnyPublisher<[UserDetails], Error>
}

final class UserServiceMock: UserServiceProtocol {
    
    
    var users :[User] = [User(id: 11), User(id: 12)]

    var userDetails: [UserDetails] = [UserDetails(id: 11, name: "Venkat", email: "panidapu.mca@gmail.com"), UserDetails(id: 12, name: "Venkat", email: "panidapu.mca@gmail.com")]
    
    func fetchUsers() -> AnyPublisher<[User], Error> {
        
        Just(users)
                .setFailureType(to: Error.self)
                .eraseToAnyPublisher()
    }
    
    func fetchUsersById(id: Int) -> AnyPublisher<[UserDetails], Error> {
        
        Just(userDetails.filter({$0.id == id}))
                .setFailureType(to: Error.self)
                .eraseToAnyPublisher()
    }
    
    func fetchUserDetails(id: Int) -> AnyPublisher<[UserDetails], Error> {
            
        fetchUsers().flatMap { [self] user in
            
            self.fetchUsersById(id: (user.first?.id)!)
        }.eraseToAnyPublisher()
    }
    
}
    
struct User: Decodable {

    var id: Int?
}
struct UserDetails {
    
    var id: Int?
    var name: String?
    var email: String?
}


struct ViewModel {
 
    private var currentValuePublisher = CurrentValueSubject<Int, Never>(0)
    
    var resultPublisher : AnyPublisher<String, Never> {
        
        currentValuePublisher.map { val in
            
            return "\(val)"
        }
        .eraseToAnyPublisher()
    }
    
    func send(val: Int) {
        
        currentValuePublisher.send(val)
    }
}
class CombineTestTests: XCTestCase {
    
    func testApiCall() {
        
        let viewModel = ViewModel()
        
        let spy = Spy(viewModel.resultPublisher)
        
        viewModel.send(val: 10)
        
        XCTAssertEqual(spy.result, ["0", "10"])
        
        viewModel.send(val: 20)
        
        XCTAssertEqual(spy.result, ["0", "10", "20"])
    }
}

class Spy {
    
    var result:[String] = []
    var subscription = Set<AnyCancellable>()
    
    init(_ publisher: AnyPublisher<String, Never>) {
        
        publisher.sink { error in
            debugPrint(error)
        } receiveValue: { [weak self] val in
            
            guard let self = self else {return}
            self.result.append(val)
        }
        .store(in: &subscription)
    }
}
