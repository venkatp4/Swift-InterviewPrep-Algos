//
//  CombineTestApp.swift
//  CombineTest
//
//  Created by Venkat on 26/10/22.
//

import SwiftUI

@main
struct CombineTestApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
