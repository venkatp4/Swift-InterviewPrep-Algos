import UIKit

struct Album {
    
    func getAricleName(byYear: Int) -> String? {
        
        switch byYear {
    
        case 1900:
            return nil
        case 1950:
            return "English Movie"
        case 2000:
            return "Hindi Movie"
        default:
            return nil
        }
    }
}
let objAlbum = Album()
objAlbum.getAricleName(byYear: 1900)?.uppercased() ?? ""
