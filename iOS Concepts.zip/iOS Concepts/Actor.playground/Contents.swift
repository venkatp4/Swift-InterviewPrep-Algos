import UIKit

actor BankAccount {
    
    var balnceAmount: Double = 2000.0
    
    func withdrawal(of amount: Double?) async {
        
        
        guard let amount = amount, amount < balnceAmount else {
          
            return
        }

        balnceAmount -= amount
        
        printBalance(amount: amount, balance: balnceAmount)
    }
    
    func printBalance(amount: Double, balance: Double) {
        
        debugPrint("withdrawal amount is \(amount) and account balance is \(balnceAmount)")

    }
}

actor Loan {
    
    func withdrawal() async {
    
        let obj = BankAccount()
        
        await obj.withdrawal(of: 100)
        await obj.withdrawal(of: 100)
        await obj.withdrawal(of: 10)
        await obj.withdrawal(of: 20)
        await obj.withdrawal(of:80)
        await obj.withdrawal(of: 60)
        await obj.withdrawal(of: 100)
        
    }
}

Task {
    
    let obj = Loan()
    await obj.withdrawal()
}
