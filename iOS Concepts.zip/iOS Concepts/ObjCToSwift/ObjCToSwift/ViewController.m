//
//  ViewController.m
//  ObjCToSwift
//
//  Created by Venkat on 29/10/22.
//

#import "ViewController.h"
#import "ObjCToSwift-Swift.h"


@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    MySwiftFile * file = [[MySwiftFile alloc]init];
    NSString* returnValue = [file greetWithValue:@"Venkat"];
    
    NSLog(@"%@", returnValue);
}


@end
