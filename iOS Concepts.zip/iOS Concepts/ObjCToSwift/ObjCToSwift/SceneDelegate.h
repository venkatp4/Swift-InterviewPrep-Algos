//
//  SceneDelegate.h
//  ObjCToSwift
//
//  Created by Venkat on 29/10/22.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

