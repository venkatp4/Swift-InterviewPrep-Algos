//
//  MySwiftFile.swift
//  ObjCToSwift
//
//  Created by Venkat on 29/10/22.
//

import Foundation

class MySwiftFile: NSObject {
    
    @objc func greet(value: String) -> String {
        
        return "Good Morning..., \(value)"
    }
}
