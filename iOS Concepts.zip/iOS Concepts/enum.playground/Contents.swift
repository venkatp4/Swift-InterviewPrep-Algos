import UIKit

enum Enumeration: Int, CaseIterable {
    
    case One = 100
    case Two = 200
    case Three = 300
}

let enumeration = Enumeration.self

for val in enumeration.allCases {
    
    debugPrint(val.rawValue)
}

enum Enumeration1: String {
    
    case One = "One"
    case Two = "Two"
    case Three = "Three"
    
    func getErrorMessage() -> String {
        
        switch self {

        case .One:
            return Enumeration1.One.rawValue
        case .Two:
            return Enumeration1.Two.rawValue
        case .Three:
            return Enumeration1.Three.rawValue
        }
    }
}
let objE1 = Enumeration1.self
objE1.One.getErrorMessage()

enum Enumeration2: String {
    
    case One = "One"
    case Two = "Two"
    case Three = "Three"
    
    func getMessage() -> String {
        
        return self.rawValue
    }
}
let objE2 = Enumeration2.self
objE2.One.getMessage()


enum Enumeration3: String {
    
    case One = "One"
    case Two = "Two"
    case Three = "Three"
    
    var getMessage: String {
        
        get {
            return self.rawValue
        }
    }
}
let objE3 = Enumeration3.self
objE3.Three.getMessage

struct Constant {
    
    static let Base_url = "https://github.com/seucreKeys/k1l/"
}
enum Enumeration4 {
    
    case movieList(String)
    case movieDetails(Int)
    
    var urlEndPoint: String {
        
        switch self {
            
        case .movieList(let genre):
            return Constant.Base_url + genre
        
        case .movieDetails(let id):
            return Constant.Base_url + String(id)
        }
    }
}

let objE4 = Enumeration4.self
objE4.movieList("genre").urlEndPoint


enum Enumeration5 : String {
    
    case One = "One"
    case Two = "Two"
    case Three = "Three"
       
    var getString : String {
        
        return self.rawValue
    }
    
    init(type: Int) {
        
        switch(type) {
            
        case 11 :
            self = .One
        case 22:
            self = .Two
        default:
            self = Enumeration5.Three
        }
        
    }
}
let objE5 = Enumeration5(type: 22).getString


enum Enumeration6: String {
    
    case One = "One"
    case Two = "Two"
    case Three = "Three"
    
    var computedVal : String {
        
        return self.rawValue
    }
    
    init(_type: Int) {
        
        switch(_type) {
            
        case 11:
            self = .One
        case 22:
            self = .Two
        case 33:
            self = .Three
        default:
            self = .Three
        }
    }
}

var objE6 = Enumeration6(_type: 22).computedVal

