//: A MapKit based Playground

import Foundation
import Combine

struct User {
    
    let id : Int
    let name: String
    let email: String
    
    init(_id: Int, _name: String, _email: String) {
        
        self.id = _id
        self.name = _name
        self.email = _email
    }
}


struct Employee: Codable {
    
    var id : Int
    var name: String
    var email: String
    var designation: String
}


protocol DataSource {
    
    func getResults() -> [User]
}

class ApiClient : DataSource {
    
    func getResults() -> [User] {
        
        return [User(_id: 1, _name: "Venkat", _email: "panidapu.mca@gmail.com")]
                     
    }
}

class ApiClient1 : ApiClient {
    
    override func getResults() -> [User] {
        
        print("useful content....")
        
        return [User(_id: 1, _name: "Venkat", _email: "panidapu.mca@gmail.com")]
                     
    }
}


protocol ReposityInterface {
        
    func getResults() -> [User]
}

struct ReposityImplmentation : ReposityInterface {
    
    var dataSource: DataSource
    
    func getResults() -> [User] {
        
        return dataSource.getResults()
    }
}

protocol UsecaseProtocol {
        
    func getResults() -> [User]
}

struct UseCase : UsecaseProtocol {
    
    var repo: ReposityInterface
    
    func getResults() -> [User] {
        
        return repo.getResults()
    }
}

class ViewModel {
    
    var useCase = UseCase(repo: ReposityImplmentation(dataSource: ApiClient1()))
    
    func getResults() -> [User] {

        return useCase.getResults()
    }
}

var obj = ViewModel()

obj.getResults()
