import UIKit
import Combine

func intPublisher() -> AnyPublisher<Int, Error>{
    
    return [1383955, 34535, 44].publisher
        .tryMap({ $0 })
        .eraseToAnyPublisher()
}

func stringPublisher(val: Int) -> AnyPublisher<String, Error>{
    
    return [val].publisher
        .tryMap ({ val in
            
            return "\(val)"
        })
        .eraseToAnyPublisher()
}

func getFinalPublisher() -> AnyPublisher<String, Error> {
    
    intPublisher()
        .flatMap { val in
        
            return stringPublisher(val: val)
        }
        .eraseToAnyPublisher()
}

getFinalPublisher().sink { completion in
    debugPrint(completion)
} receiveValue: { val in
    debugPrint(val)
}

