//
//  User.swift
//  SwiftUILoadMore
//
//  Created by Venkat on 11/10/22.
//

import Foundation

struct User: Decodable {
 
    let id: Int
    let name: String
    let avatarUrl: String
    
    enum CodingKeys: String, CodingKey {
           case id
           case name = "login"
           case avatarUrl = "avatar_url"
   }
}
