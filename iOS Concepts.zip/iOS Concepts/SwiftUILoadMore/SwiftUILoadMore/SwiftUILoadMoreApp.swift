//
//  SwiftUILoadMoreApp.swift
//  SwiftUILoadMore
//
//  Created by Venkat on 11/10/22.
//

import SwiftUI

@main
struct SwiftUILoadMoreApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
