//
//  UserViewModel.swift
//  SwiftUILoadMore
//
//  Created by Venkat on 11/10/22.
//

import Foundation
import Combine
 
class UserViewModel : ObservableObject {
    
    @Published var users :[User] = []
    
    @Published var isRequestFailed: Bool = false
    
    private let perPageLimit = 25
    
    private var currentLastId: Int? = nil
    
    private var subscriptions = Set<AnyCancellable>()
    
    
    func getUsers() {
      
        try? ApiService.shared.getUsers(url: Constant.BaseUrl, perPage: perPageLimit, sinceId: currentLastId)
            .receive(on: DispatchQueue.main)
            .sink { completion in
                switch completion {
                case .finished:
                    debugPrint("finished")
                case .failure(let error):
                    self.isRequestFailed = true
                    debugPrint(error)
                }
            } receiveValue: { user in
                
                self.users.append(contentsOf: user)
                self.currentLastId = user.last?.id
            }
            .store(in: &subscriptions)
    }
    
}
