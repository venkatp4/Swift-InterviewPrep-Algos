//
//  ApiService.swift
//  SwiftUILoadMore
//
//  Created by Venkat on 11/10/22.
//

import Foundation
import Combine

enum ApiFailure: Error {
    
    case internetError
    case invalidUrl
}
class ApiService {
    
    private init() {
        
    }
    
    static let shared = ApiService()
    
    func getUsers(url: String, perPage: Int = 30, sinceId:Int? = nil) throws -> AnyPublisher<[User], Error> {
        
        var components = URLComponents(string: url)
        
        components?.queryItems = [
            URLQueryItem(name: "per_page", value: "\(perPage)"),
            URLQueryItem(name: "since", value: String(sinceId ?? 0))
        ]
        guard let url = components?.url else { throw ApiFailure.invalidUrl }
        
        let _urlRequest = URLRequest(url: url, timeoutInterval: 10)
        
        return URLSession.shared.dataTaskPublisher(for: _urlRequest)
            .tryMap({$0.data})
            .decode(type: [User].self, decoder: JSONDecoder())
            .subscribe(on: DispatchQueue.global())
            .eraseToAnyPublisher()
    }
}
