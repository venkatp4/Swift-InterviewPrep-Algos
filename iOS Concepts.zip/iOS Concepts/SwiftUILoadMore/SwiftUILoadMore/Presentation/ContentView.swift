//
//  ContentView.swift
//  SwiftUILoadMore
//
//  Created by Venkat on 11/10/22.
//

import SwiftUI

struct ContentView: View {
    
    @ObservedObject private var viewModel = UserViewModel()
    
    var body: some View {
       
        NavigationView {
            
            List {
                
                ForEach(viewModel.users, id:\.id) { user in

                    RowItem(user: user)
                }
                
               
                LoaderView(isFailed: viewModel.isRequestFailed)
                    .onAppear(perform: fetchData)
                    .onTapGesture(perform: onTapLoadView)
            }
            
            .navigationTitle("Github Users..")
            .navigationBarTitleDisplayMode(.large)
        }
    }
    
    func fetchData() {
        
        viewModel.getUsers()
    }
    
    func onTapLoadView() {
        
        if viewModel.isRequestFailed {
            
            viewModel.isRequestFailed = false
            fetchData()
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
