//
//  RowItem.swift
//  SwiftUILoadMore
//
//  Created by Venkat on 11/10/22.
//

import SwiftUI

struct RowItem: View {
    
    var user: User
    
    var body: some View {
        
        HStack {
            
            CustomImageView(urlString: user.avatarUrl)
            Text(user.name).font(.subheadline).padding(EdgeInsets(top: 0, leading: 10, bottom: 0, trailing: 0))
        }
    }
}

struct CustomImageView: View {
    var urlString: String
    @ObservedObject var imageLoader = ImageLoaderService()
    @State var image: UIImage = UIImage()
    
    var body: some View {
        Image(uiImage: image)
            .resizable()
            .aspectRatio(contentMode: .fit)
            .frame(width:50, height:50)
            .onReceive(imageLoader.$image) { image in
                self.image = image
            }
            .cornerRadius(25)
            .onAppear {
                imageLoader.loadImage(for: urlString)
            }
    }
}

class ImageLoaderService: ObservableObject {
    @Published var image: UIImage = UIImage()
    
    func loadImage(for urlString: String) {
        guard let url = URL(string: urlString) else { return }
        
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            guard let data = data else { return }
            DispatchQueue.main.async {
                self.image = UIImage(data: data) ?? UIImage()
            }
        }
        task.resume()
    }
    
}

//struct RowItem_Previews: PreviewProvider {
//    var user: User
//    static var previews: some View {
//
//        RowItem(user: user)
//    }
//}
