//
//  Constant.swift
//  SwiftUILoadMore
//
//  Created by Venkat on 11/10/22.
//

import Foundation

struct Constant {
    
    static let BaseUrl = "https://api.github.com/users"
}
