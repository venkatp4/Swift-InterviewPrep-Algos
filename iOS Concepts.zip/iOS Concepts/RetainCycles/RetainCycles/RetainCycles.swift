//
//  RetainCycles.swift
//  RetainCycles
//
//  Created by Venkat on 03/11/22.
//

import Foundation

class Person {
    
    var name: String
    weak var asset: MacBook?
    
    init(_ name: String, _ asset: MacBook?) {
        
        self.name = name
        self.asset = asset
    }
    
    deinit {
        
        print("deinitialized")
    }
}

class MacBook {
    
    var name : String
    var owner: Person?
    
    init(_ name: String, _ owner: Person?) {
        
        self.name = name
        self.owner = owner
    }
    
    deinit {
        
        print("deinitialized")
    }
}
