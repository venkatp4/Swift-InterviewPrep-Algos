//
//  ViewController.swift
//  RetainCycles
//
//  Created by Venkat on 03/11/22.
//

import UIKit

class ViewController: UIViewController {

    var person: Person?
    var asset: MacBook?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        createObjects()
        assignProperties()
    }
    
    func createObjects() {
        
        person = Person("Venkat", nil)
        asset = MacBook("Mac Book 11 Pro", nil)
    }

    func assignProperties() {
        
        person?.asset = asset
        asset?.owner = person
        print(CFGetRetainCount(person))
        print(CFGetRetainCount(asset))
        person = nil
        asset = nil
    }
}

