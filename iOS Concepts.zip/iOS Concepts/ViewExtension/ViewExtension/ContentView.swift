//
//  ContentView.swift
//  ViewExtension
//
//  Created by Venkat on 08/10/22.
//

import SwiftUI

struct ContentView: View {
    
    var body: some View {
        VStack {
            
            styledGradientButton
                
//            normalStyledButton("Buy me a Coffee")
                
//            CustomButton {
//
//                print("Tapped")
//            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
