//
//  ViewExtensionApp.swift
//  ViewExtension
//
//  Created by Venkat on 08/10/22.
//

import SwiftUI

@main
struct ViewExtensionApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
