//
//  Extensions.swift
//  ViewExtension
//
//  Created by Venkat on 08/10/22.
//

import SwiftUI

extension View {
    
    var styledGradientButton : some View {
        
        VStack {
            
            Button(action: {}) {
                Text("Buy me a coffee")
            }
            .padding()
            .foregroundColor(.white)
            .background(Color.purple)
            .clipShape(RoundedRectangle(cornerRadius: 5))
            LinearGradient(colors: [.red, .blue, .green], startPoint: .leading, endPoint: .trailing)
        }
    }
    
    func normalStyledButton(_ title: String) -> some View {
        
        VStack {
            
            Button(action: {}) {
                Text(title)
            }
            .padding()
            .foregroundColor(.white)
            .background(Color.black)
            .clipShape(RoundedRectangle(cornerRadius: 5))
        }
    }
}


struct CustomButton : View {
    
    var action:(()-> Void)
    
    var body: some View {
        
        VStack {
            
            Button(action: action) {
                Text("Custom Button")
                
            }.padding()
                .foregroundColor(.red)
                .background(.black)
                .clipShape(RoundedRectangle(cornerRadius: 7))
            
        }
    }
}
