import UIKit
import Combine

public func example(of description: String,
                    action: () -> Void) {
  print("\n——— Example of:", description, "———")
  action()
}

example(of: "Publisher") {
    
    // :- Notification from NotificationCenter
    
    let notification = NSNotification.Name("MyNotification")
    
    let center = NotificationCenter.default
    
    let observer = center.addObserver(forName: notification, object: nil, queue: nil) { notification in
        
        debugPrint("notification received from NotificationCenter")
    }
    
    center.post(name: notification, object: nil)
    
    center.removeObserver(observer)
   
    // :- Notification from PubSub
    
    let _notification = NSNotification.Name("PubSubNotification")
        
    let _center = NotificationCenter.default
    
    let publisher = _center.publisher(for: _notification, object: nil)
    
    let subscription = publisher.sink { completion in
    
        debugPrint("completion")
        
    } receiveValue: { notification in
        
        debugPrint("Notification received from PubSub")
    }
    
    _center.post(name: _notification, object: nil)

    subscription.cancel()
}
// : - Just Publisher

example(of: "Just") {
    
    let publisher = Just("HelloWorld")
    
    let subscriber1 = publisher.sink { completion in
        
        debugPrint("completion \(completion)")
        
    } receiveValue: { value in
        
        debugPrint("received value \(value)")
    }
    
    let subscriber2 = publisher.sink { completion in
        
        debugPrint("completion another \(completion)")
        
    } receiveValue: { value in
        
        debugPrint("received another value \(value)")
    }
}


example(of: "assign(:to, : on)") {
    
    var cancellable = Set<AnyCancellable>()
    
    class ABC {
        
        var value: String = "" {
            
            didSet {
                
                debugPrint("received value fom didSet \(value)")
            }
        }
    }
    
    let publisher = ["Hello", "World"].publisher
    let obj = ABC()
    
    publisher.assign(to: \.value, on: obj)
    .store(in: &cancellable)
}

example(of: "Republishing with assign(:to, : &)") {
    
    class ABC {
        
        @Published var value = 90
    }
    
    let obj = ABC()
    obj.$value
        .sink { value in
        
        debugPrint("received value \(value)")
    }
    
    (0...100).publisher.assign(to: &obj.$value)
}


example(of: "Custom Subscriber") {

    final class IntSubscriber: Subscriber {
        
        func receive(subscription: Subscription) {
            
            subscription.request(.unlimited)
        }
        
        func receive(_ input: Int) -> Subscribers.Demand {
            
            debugPrint("value received in Custom Subscriber \(input)")
            return .none
        }
        
        func receive(completion: Subscribers.Completion<Never>) {
            
            debugPrint("completion received in Custom Subscriber \(completion)")
        }
        
        
        typealias Input = Int
        
        typealias Failure = Never

    }
    
    let subscriber = IntSubscriber()
    let publisher = (0...10).publisher
    publisher.subscribe(subscriber)
}
example(of: "Future") {
    
    func futureIncrement(value: Int, delay: TimeInterval) -> Future<Int, Never> {
    
        Future<Int, Never> { promise in
            
            print("Original")

          DispatchQueue.global().asyncAfter(deadline: .now() + delay) {
            promise(.success(value + 1))
          }
        }

    }
    
    // 1
    let future = futureIncrement(value: 1, delay: 3)
    var subscriptions = Set<AnyCancellable>()
    // 2
    future
      .sink(receiveCompletion: { print($0) },
            receiveValue: { print($0) })
      .store(in: &subscriptions)
}

example(of: "Custom String Subscriber") {
    
    enum MyError : Error
    {
        
        case err
    }
    final class StringSubscriber : Subscriber {
        
        func receive(subscription: Subscription) {
            
            subscription.request(.max(5))
        }
        
        func receive(_ input: String) -> Subscribers.Demand {
            
            debugPrint("Subscriber value received in string format \(input)")
            return .none
        }
        
        func receive(completion: Subscribers.Completion<MyError>) {
            
            debugPrint("Completion of Subscriber String")
        }
        
        
        typealias Input = String
        
        typealias Failure = MyError
    }
    
    let subscriber = StringSubscriber()
    
    let publisher = PassthroughSubject<String, MyError>()
    
    publisher.subscribe(subscriber)
    
    let subscription = publisher.sink { completion in
        
        debugPrint("completion \(completion)")
    } receiveValue: { value in
        
        debugPrint("value received \(value)")
    }
    
    publisher.send("Hello PassThrough Subject")
    
    publisher.send(completion: .failure(.err))
    
    publisher.send("Another Hello PassThrough Subject")

}

example(of: "Dynamically adjusting Demand") {
  final class IntSubscriber: Subscriber {
    typealias Input = Int
    typealias Failure = Never
    
    func receive(subscription: Subscription) {
      subscription.request(.max(2))
    }
    
    func receive(_ input: Int) -> Subscribers.Demand {
      print("Received value", input)
    
      switch input {
      case 1:
        return .max(2) // 1
      case 3:
        return .max(1) // 2
      default:
        return .none // 3
      }
    }
    
    func receive(completion: Subscribers.Completion<Never>) {
      print("Received completion", completion)
    }
  }
  
  let subscriber = IntSubscriber()
  
  let subject = PassthroughSubject<Int, Never>()
  
  subject.subscribe(subscriber)
  
  subject.send(1)
  subject.send(2)
  subject.send(3)
  subject.send(4)
  subject.send(5)
  subject.send(6)
}

example(of: "Type Erasure") {
    
    let subject = PassthroughSubject<Int, Never>()
    
    let publisher = subject.eraseToAnyPublisher()
    
    publisher.sink { value in
        debugPrint("value received from Type Erasure \(value)")
    }
    
    subject.send(100)
}


example(of: "debounce") {
   
    let values = "abcdefghijklmnopqrstuvwxyz"

    let publisher = PassthroughSubject<Character, Never>()
    var subscriptions = Set<AnyCancellable>()
    publisher
        .debounce(for: .seconds(0.5), scheduler: RunLoop.main)
        .sink(receiveCompletion: { completion in
            debugPrint(completion)
        }, receiveValue: { val in
            debugPrint(val)
        })
        
        .store(in: &subscriptions)
        
    for(i, val) in values.enumerated() {
            
        let delay = TimeInterval(i)/10.0
            
        DispatchQueue.global().asyncAfter(deadline: .now() + 1.0) {

            publisher.send(val)
        }
        
        }
}
