//
//  ViewController.swift
//  KVO
//
//  Created by Venkat on 28/10/22.
//

import UIKit

class ViewController: UIViewController {
    
    var viewModel = ViewModel()
    
    @IBOutlet weak var displayLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        let _ = viewModel.observe(\.displayName, options: [.old, .new]) { ViewModel, value in
            
            print(value.newValue as? String ?? "")
        }
    }

    @IBAction func apiCall(_ sender: Any) {
        
        viewModel.getApiData()
    }
    
}
