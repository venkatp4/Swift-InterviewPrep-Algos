//
//  Person.swift
//  KVO
//
//  Created by Venkat on 28/10/22.
//

import Foundation

@objc class ViewModel: NSObject {
    
    @objc dynamic var displayName: String?
    
    func getApiData() {
        
        displayName = "Venkateswarlu Phanitapu"
    }
}

