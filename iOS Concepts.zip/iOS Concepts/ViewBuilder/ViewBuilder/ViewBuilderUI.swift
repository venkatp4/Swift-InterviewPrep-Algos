//
//  ViewBuilderUI.swift
//  ViewBuilder
//
//  Created by Venkat on 08/10/22.
//

import SwiftUI

struct VerticalBuilderUI<Content:View> : View {
    
    let content: Content
    let title: String?
    let bodyTitle: String?
    
    init(_ title: String, _ bodyTitle: String, @ViewBuilder content:()->Content) {
        
        self.title = title
        self.bodyTitle = bodyTitle
        self.content = content()
    }
    var body: some View {
        
        VStack {
        
            Text(title ?? "").font(.largeTitle)
            content
            Text(bodyTitle ?? "").font(.title)
        }
    }
}

struct HorizontalBuilderUI<Content:View> : View {
    
    let content: Content
    let title: String?
    let bodyTitle: String?
    
    init(_ title: String, _ bodyTitle: String, @ViewBuilder content: () -> Content) {
        
        self.title = title
        self.bodyTitle = bodyTitle
        self.content = content()
    }
    var body: some View {
        
        HStack {
            
            Text(title ?? "").font(.largeTitle)
            content
            Text(bodyTitle ?? "").font(.title)
        }
    }
}

struct BuilderInjector: View {
    
    enum ViewType {
        
        case primary, secondary
        
    }
    
    var viewType: ViewType
    
    var body: some View {
        
        switch viewType {
        case .primary:
            
            VerticalBuilderUI("View Build Title", "View Build Body") {
                
                Image(systemName: "heart.fill")
                Text("Body Title")
                Text("Body Description")
            }
        case .secondary:
            
            HorizontalBuilderUI("List Build Title", "List Build Body") {
                
                Image(systemName: "wifi.exclamationmark")
                Text("Body Title")
                Image(systemName: "bubble.left.and.exclamationmark.bubble.right")

            }
        }
        
    }
   
}
