//
//  AlertViewBuilder.swift
//  ViewBuilder
//
//  Created by Venkat on 08/10/22.
//

import SwiftUI


struct VStackView<Content: View> : View {
    
    private let content: Content
    let name: String?
    
    init(_ name: String, _ content:() -> Content) {
        
        self.name = name
        self.content = content()
    }
    
    var body: some View {
        
        VStack {
            
            Text("Dummy Text")
            content
            Text("Dummy Text")
        }
    }
}

struct HStackView<Content: View> : View {
    
    private let content: Content
    let name: String?
    
    init(_ name: String, _ content:() -> Content) {
        
        self.name = name
        self.content = content()
    }
    
    var body: some View {
        
        HStack {
            
            Text("Dummy Text")
            content
            Text("Dummy Text")
        }
    }
}

struct ViewInjector: View {
    enum ViewType {
        
        case primary
        case secondary
    }
    var viewType: ViewType
    var body: some View {
        
        switch viewType {
        case .primary:
            VStackView("Text") {
                
                Image(systemName: "")
            }
        case .secondary:
            HStackView("String") {
                
                Text("Dummy Text")
            }
        }
    }
}
