//
//  ContentView.swift
//  ViewBuilder
//
//  Created by Venkat on 08/10/22.
//

import SwiftUI

struct ContentView: View {
    
    var body: some View {
        
        BuilderInjector(viewType: .primary)
    }

}

