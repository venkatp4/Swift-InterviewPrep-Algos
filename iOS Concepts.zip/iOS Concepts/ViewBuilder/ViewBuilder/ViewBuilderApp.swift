//
//  ViewBuilderApp.swift
//  ViewBuilder
//
//  Created by Venkat on 08/10/22.
//

import SwiftUI

@main
struct ViewBuilderApp: App {
    var body: some Scene {
        WindowGroup {

            ContentView()
        }
    }
}
